import * as THREE from 'three';
import type { CharacterRig } from './createCharacterPieces';
import type { MoveAnimationPayload, PieceColor, PieceType } from '../types/chess';

export type CombatSoundCue =
  | 'swing'
  | 'swingFast'
  | 'metal'
  | 'metalHeavy'
  | 'shield'
  | 'magicCharge'
  | 'magicImpact'
  | 'gallop'
  | 'defeat';

const _tmpA = new THREE.Vector3();
const _tmpB = new THREE.Vector3();
const _tmpC = new THREE.Vector3();

function clamp01(v: number): number {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

function seg(p: number, start: number, end: number): number {
  return clamp01((p - start) / (end - start));
}

function easeOutCubic(t: number): number {
  return 1 - Math.pow(1 - t, 3);
}

function easeInOutQuad(t: number): number {
  return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
}

export function shortestAngleLerp(current: number, target: number, t: number): number {
  let diff = ((target - current + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (diff < -Math.PI) diff += Math.PI * 2;
  return current + diff * t;
}

export function getCombatDuration(type: PieceType): number {
  switch (type) {
    case 'k':
      return 3.15;
    case 'q':
      return 2.95;
    case 'r':
      return 3.25;
    case 'b':
      return 3.05;
    case 'n':
      return 3.3;
    case 'p':
      return 2.75;
  }
}

interface SwingTrailEffect {
  mesh: THREE.Mesh;
  mat: THREE.MeshBasicMaterial;
  age: number;
  maxAge: number;
}

interface SparkParticle {
  mesh: THREE.Mesh;
  mat: THREE.MeshBasicMaterial;
  vel: THREE.Vector3;
  age: number;
  maxAge: number;
}

interface ShockwaveEffect {
  mesh: THREE.Mesh;
  mat: THREE.MeshBasicMaterial;
  age: number;
  maxAge: number;
  maxScale: number;
}

interface ProjectileEffect {
  group: THREE.Group;
  coreMat: THREE.MeshBasicMaterial;
  ringMat: THREE.MeshBasicMaterial;
  start: THREE.Vector3;
  end: THREE.Vector3;
  age: number;
  duration: number;
}

interface DustParticle {
  mesh: THREE.Mesh;
  mat: THREE.MeshBasicMaterial;
  vel: THREE.Vector3;
  age: number;
  maxAge: number;
}

export class CombatEffectsManager {
  private group: THREE.Group;
  private trailGeo: THREE.RingGeometry;
  private sparkGeo: THREE.OctahedronGeometry;
  private shockGeo: THREE.RingGeometry;
  private orbGeo: THREE.SphereGeometry;
  private auraGeo: THREE.TorusGeometry;
  private dustGeo: THREE.DodecahedronGeometry;

  private trails: SwingTrailEffect[] = [];
  private sparks: SparkParticle[] = [];
  private shockwaves: ShockwaveEffect[] = [];
  private projectiles: ProjectileEffect[] = [];
  private dust: DustParticle[] = [];

  constructor(parent: THREE.Group) {
    this.group = parent;
    this.trailGeo = new THREE.RingGeometry(0.42, 0.62, 18, 1, -Math.PI * 0.42, Math.PI * 0.84);
    this.sparkGeo = new THREE.OctahedronGeometry(0.035, 0);
    this.shockGeo = new THREE.RingGeometry(0.14, 0.28, 24);
    this.orbGeo = new THREE.SphereGeometry(0.1, 12, 10);
    this.auraGeo = new THREE.TorusGeometry(0.16, 0.02, 6, 18);
    this.dustGeo = new THREE.DodecahedronGeometry(0.11, 0);
  }

  public spawnSwingTrail(
    origin: THREE.Vector3,
    facingY: number,
    color: PieceColor,
    options: {
      tiltX?: number;
      tiltZ?: number;
      scale?: number;
      fullSpin?: boolean;
      height?: number;
    } = {}
  ) {
    const mat = new THREE.MeshBasicMaterial({
      color: color === 'w' ? 0x93c5fd : 0xfb7185,
      transparent: true,
      opacity: 0.72,
      side: THREE.DoubleSide,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    const mesh = new THREE.Mesh(this.trailGeo, mat);
    mesh.position.set(origin.x, options.height ?? 0.92, origin.z);
    mesh.rotation.order = 'YXZ';
    mesh.rotation.y = facingY;
    mesh.rotation.x = Math.PI / 2 + (options.tiltX ?? 0);
    mesh.rotation.z = options.tiltZ ?? 0;
    const sc = options.scale ?? 1.0;
    mesh.scale.set(sc, sc, sc);
    this.group.add(mesh);

    this.trails.push({
      mesh,
      mat,
      age: 0,
      maxAge: options.fullSpin ? 0.34 : 0.24,
    });
  }

  public spawnSparks(pos: THREE.Vector3, colorHex: number, count = 10) {
    for (let i = 0; i < count; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: colorHex,
        transparent: true,
        opacity: 0.95,
        depthWrite: false,
        blending: THREE.AdditiveBlending,
      });
      const mesh = new THREE.Mesh(this.sparkGeo, mat);
      mesh.position.copy(pos);
      const speed = 1.6 + Math.random() * 2.4;
      const angle = Math.random() * Math.PI * 2;
      const vel = new THREE.Vector3(
        Math.cos(angle) * speed,
        0.9 + Math.random() * 2.2,
        Math.sin(angle) * speed
      );
      this.group.add(mesh);
      this.sparks.push({
        mesh,
        mat,
        vel,
        age: 0,
        maxAge: 0.28 + Math.random() * 0.16,
      });
    }
  }

  public spawnShockwave(pos: THREE.Vector3, colorHex: number, maxScale = 3.2, height = 0.12) {
    const mat = new THREE.MeshBasicMaterial({
      color: colorHex,
      transparent: true,
      opacity: 0.85,
      side: THREE.DoubleSide,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    const mesh = new THREE.Mesh(this.shockGeo, mat);
    mesh.position.set(pos.x, height, pos.z);
    mesh.rotation.x = -Math.PI / 2;
    this.group.add(mesh);
    this.shockwaves.push({
      mesh,
      mat,
      age: 0,
      maxAge: 0.38,
      maxScale,
    });
  }

  public spawnDust(pos: THREE.Vector3, count = 6) {
    for (let i = 0; i < count; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0x9aa6b8,
        transparent: true,
        opacity: 0.42,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(this.dustGeo, mat);
      const ang = Math.random() * Math.PI * 2;
      mesh.position.set(pos.x + Math.cos(ang) * 0.14, 0.08, pos.z + Math.sin(ang) * 0.14);
      const speed = 0.7 + Math.random() * 1.1;
      const vel = new THREE.Vector3(Math.cos(ang) * speed, 0.35 + Math.random() * 0.55, Math.sin(ang) * speed);
      this.group.add(mesh);
      this.dust.push({
        mesh,
        mat,
        vel,
        age: 0,
        maxAge: 0.48 + Math.random() * 0.2,
      });
    }
  }

  public spawnMagicProjectile(
    start: THREE.Vector3,
    end: THREE.Vector3,
    color: PieceColor,
    duration = 0.26
  ) {
    const group = new THREE.Group();
    group.position.copy(start);

    const coreMat = new THREE.MeshBasicMaterial({
      color: color === 'w' ? 0x93c5fd : 0xf43f5e,
      transparent: true,
      opacity: 0.95,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });
    const ringMat = new THREE.MeshBasicMaterial({
      color: color === 'w' ? 0xe0f2fe : 0xfda4af,
      transparent: true,
      opacity: 0.8,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
    });

    const core = new THREE.Mesh(this.orbGeo, coreMat);
    const ring = new THREE.Mesh(this.auraGeo, ringMat);
    group.add(core);
    group.add(ring);
    this.group.add(group);

    this.projectiles.push({
      group,
      coreMat,
      ringMat,
      start: start.clone(),
      end: end.clone(),
      age: 0,
      duration,
    });
  }

  public update(dt: number) {
    for (let i = this.trails.length - 1; i >= 0; i--) {
      const t = this.trails[i];
      t.age += dt;
      const p = t.age / t.maxAge;
      if (p >= 1) {
        this.group.remove(t.mesh);
        t.mat.dispose();
        this.trails.splice(i, 1);
      } else {
        t.mesh.rotation.z += dt * 7.5;
        t.mat.opacity = (1 - p) * 0.72;
      }
    }

    for (let i = this.sparks.length - 1; i >= 0; i--) {
      const s = this.sparks[i];
      s.age += dt;
      const p = s.age / s.maxAge;
      if (p >= 1) {
        this.group.remove(s.mesh);
        s.mat.dispose();
        this.sparks.splice(i, 1);
      } else {
        s.vel.y -= 6.5 * dt;
        s.mesh.position.addScaledVector(s.vel, dt);
        s.mesh.scale.setScalar(1 - p);
        s.mat.opacity = 1 - p;
      }
    }

    for (let i = this.shockwaves.length - 1; i >= 0; i--) {
      const sw = this.shockwaves[i];
      sw.age += dt;
      const p = sw.age / sw.maxAge;
      if (p >= 1) {
        this.group.remove(sw.mesh);
        sw.mat.dispose();
        this.shockwaves.splice(i, 1);
      } else {
        const s = 1 + easeOutCubic(p) * sw.maxScale;
        sw.mesh.scale.set(s, s, 1);
        sw.mat.opacity = (1 - p) * 0.85;
      }
    }

    for (let i = this.projectiles.length - 1; i >= 0; i--) {
      const pr = this.projectiles[i];
      pr.age += dt;
      const p = pr.age / pr.duration;
      if (p >= 1) {
        this.group.remove(pr.group);
        pr.coreMat.dispose();
        pr.ringMat.dispose();
        this.projectiles.splice(i, 1);
      } else {
        pr.group.position.lerpVectors(pr.start, pr.end, p);
        pr.group.rotation.y += dt * 14;
        pr.group.rotation.x += dt * 9;
      }
    }

    for (let i = this.dust.length - 1; i >= 0; i--) {
      const d = this.dust[i];
      d.age += dt;
      const p = d.age / d.maxAge;
      if (p >= 1) {
        this.group.remove(d.mesh);
        d.mat.dispose();
        this.dust.splice(i, 1);
      } else {
        d.mesh.position.addScaledVector(d.vel, dt);
        d.vel.multiplyScalar(Math.exp(-3.2 * dt));
        const sc = 0.85 + p * 1.75;
        d.mesh.scale.setScalar(sc);
        d.mat.opacity = (1 - p) * 0.42;
      }
    }
  }

  public dispose() {
    this.trails.forEach((t) => {
      this.group.remove(t.mesh);
      t.mat.dispose();
    });
    this.sparks.forEach((s) => {
      this.group.remove(s.mesh);
      s.mat.dispose();
    });
    this.shockwaves.forEach((sw) => {
      this.group.remove(sw.mesh);
      sw.mat.dispose();
    });
    this.projectiles.forEach((pr) => {
      this.group.remove(pr.group);
      pr.coreMat.dispose();
      pr.ringMat.dispose();
    });
    this.dust.forEach((d) => {
      this.group.remove(d.mesh);
      d.mat.dispose();
    });
    this.trails = [];
    this.sparks = [];
    this.shockwaves = [];
    this.projectiles = [];
    this.dust = [];
    this.trailGeo.dispose();
    this.sparkGeo.dispose();
    this.shockGeo.dispose();
    this.orbGeo.dispose();
    this.auraGeo.dispose();
    this.dustGeo.dispose();
  }
}

export interface CombatDuelContext {
  payload: MoveAnimationPayload;
  attacker: CharacterRig;
  defender: CharacterRig;
  fromPos: THREE.Vector3;
  toPos: THREE.Vector3;
  duelSpot: THREE.Vector3;
  normDir: THREE.Vector3;
  sidePerp: THREE.Vector3;
  travelAngle: number;
  homeAngle: number;
  firedCues: Set<string>;
  shakeIntensity: number;
  savedCamPos: THREE.Vector3;
  savedTarget: THREE.Vector3;
  claimStartPos?: THREE.Vector3;
}

function triggerOnce(ctx: CombatDuelContext, id: string, fn: () => void) {
  if (!ctx.firedCues.has(id)) {
    ctx.firedCues.add(id);
    fn();
  }
}

function applyDefenderFall(
  defender: CharacterRig,
  pFall: number,
  pFade: number,
  ctx: CombatDuelContext,
  playSound: (cue: CombatSoundCue) => void
) {
  defender.body.rotation.order = 'YXZ';
  const fallEase = easeInOutQuad(pFall);
  defender.body.rotation.x = -fallEase * Math.PI * 0.48;
  defender.body.position.y = THREE.MathUtils.lerp(defender.baseY, 0.13, fallEase);
  defender.torso.rotation.x = -fallEase * 0.2;
  defender.rightArm.rotation.z = -fallEase * 0.7;
  defender.leftArm.rotation.z = fallEase * 0.7;

  if (pFall > 0.25) {
    triggerOnce(ctx, 'defeat_sound', () => playSound('defeat'));
  }

  if (pFade > 0) {
    const scaleFade = THREE.MathUtils.lerp(1, 0.02, Math.pow(pFade, 1.4));
    defender.root.scale.setScalar(scaleFade);
    defender.root.position.y = pFade * 0.14;
  }
}

function animateWalkStride(rig: CharacterRig, phase: number, amp = 0.45) {
  rig.legs.forEach((leg, idx) => {
    leg.rotation.x = Math.sin(phase + idx * Math.PI) * amp;
  });
  if (rig.horse) {
    rig.horse.legs.forEach((leg, idx) => {
      const offset = idx === 0 || idx === 3 ? 0 : Math.PI;
      leg.rotation.x = Math.sin(phase + offset) * (amp * 1.15);
    });
    rig.horse.neck.rotation.x = Math.sin(phase) * 0.12;
  }
}

function resetLimbsNeutral(rig: CharacterRig) {
  rig.legs.forEach((l) => (l.rotation.x = 0));
  if (rig.horse) {
    rig.horse.legs.forEach((l) => (l.rotation.x = 0));
    rig.horse.neck.rotation.x = 0;
  }
}

export function updateCombatDuel(
  ctx: CombatDuelContext,
  p: number,
  dt: number,
  effects: CombatEffectsManager,
  camera: THREE.PerspectiveCamera,
  targetOut: THREE.Vector3,
  playSound: (cue: CombatSoundCue) => void
) {
  const { attacker, defender, fromPos, toPos, duelSpot, normDir, sidePerp, travelAngle, homeAngle } = ctx;
  const type = ctx.payload.piece;
  const sparkColor = ctx.payload.color === 'w' ? 0x93c5fd : 0xfbbf24;
  const magicColor = ctx.payload.color === 'w' ? 0x60a5fa : 0xf43f5e;
  const defenderFaceAngle = travelAngle + Math.PI;

  defender.body.rotation.order = 'YXZ';
  attacker.body.rotation.order = 'YXZ';

  // Common Approach (0.00 -> 0.18) with anticipation windup (0.14 -> 0.18)
  if (p < 0.18) {
    const t = easeOutCubic(seg(p, 0, 0.18));
    attacker.root.position.lerpVectors(fromPos, duelSpot, t);
    attacker.body.rotation.y = shortestAngleLerp(attacker.body.rotation.y, travelAngle, 0.3);
    defender.body.rotation.y = shortestAngleLerp(defender.body.rotation.y, defenderFaceAngle, 0.3);

    if (type === 'n') {
      triggerOnce(ctx, 'gallop1', () => {
        playSound('gallop');
        effects.spawnDust(fromPos, 5);
      });
      animateWalkStride(attacker, t * Math.PI * 3.5, 0.52);
      attacker.root.position.y = Math.abs(Math.sin(t * Math.PI * 2)) * 0.14;
    } else {
      animateWalkStride(attacker, t * Math.PI * 3, 0.42);
      attacker.root.position.y = Math.abs(Math.sin(t * Math.PI * 3)) * 0.05;
    }

    // Enter combat guard stance + brief windup crouch at end of approach
    const windup = seg(p, 0.14, 0.18);
    attacker.torso.rotation.x = windup * 0.12;
    attacker.rightArm.rotation.x = THREE.MathUtils.lerp(-0.28, -0.75, t);
    attacker.leftArm.rotation.x = THREE.MathUtils.lerp(-0.25, -0.55, t);
    defender.leftArm.rotation.x = THREE.MathUtils.lerp(-0.25, -0.82, t);
    defender.rightArm.rotation.x = THREE.MathUtils.lerp(-0.28, -0.65, t);
    defender.torso.rotation.x = THREE.MathUtils.lerp(0, 0.08, t);
  } else if (p < 0.88) {
    // Character-specific combat combos (0.18 -> 0.88)
    resetLimbsNeutral(attacker);
    attacker.root.position.y = 0;

    if (type === 'k') {
      // KING: Royal Swordsman — Draw/Raise -> Slash (Blocked) -> Backhand Cleave (Stagger) -> Overhead Strike (Defeat)
      if (p < 0.36) {
        // Beat 1: Horizontal Slash & Shield Block
        const b = seg(p, 0.18, 0.36);
        const swing = easeInOutQuad(clamp01((b - 0.15) / 0.55));
        attacker.root.position.lerpVectors(duelSpot, _tmpA.copy(duelSpot).addScaledVector(normDir, 0.16), Math.sin(b * Math.PI));
        attacker.rightArm.rotation.set(
          THREE.MathUtils.lerp(-0.75, -0.25, swing),
          THREE.MathUtils.lerp(-0.9, 0.9, swing),
          -0.85
        );
        attacker.torso.rotation.y = THREE.MathUtils.lerp(-0.4, 0.45, swing);

        if (b > 0.25) {
          triggerOnce(ctx, 'k_sw1', () => {
            playSound('swing');
            effects.spawnSwingTrail(attacker.root.position, travelAngle, ctx.payload.color, { tiltZ: 0.2, height: 1.02 });
          });
        }
        if (b > 0.58) {
          triggerOnce(ctx, 'k_hit1', () => {
            playSound('shield');
            effects.spawnSparks(_tmpB.copy(toPos).setY(1.02), 0xfde68a, 10);
          });
          defender.leftArm.rotation.x = -1.25;
          defender.torso.rotation.x = -0.14;
        }
      } else if (p < 0.54) {
        // Beat 2: Backhand Royal Cleave -> Defender Staggers
        const b = seg(p, 0.36, 0.54);
        const swing = easeOutCubic(clamp01((b - 0.1) / 0.55));
        attacker.rightArm.rotation.set(
          THREE.MathUtils.lerp(-0.3, -0.55, swing),
          THREE.MathUtils.lerp(0.9, -0.85, swing),
          -0.45
        );
        attacker.torso.rotation.y = THREE.MathUtils.lerp(0.45, -0.42, swing);
        if (b > 0.18) {
          triggerOnce(ctx, 'k_sw2', () => {
            playSound('swing');
            effects.spawnSwingTrail(attacker.root.position, travelAngle, ctx.payload.color, { tiltZ: -0.35, height: 1.0 });
          });
        }
        if (b > 0.52) {
          triggerOnce(ctx, 'k_hit2', () => {
            playSound('metal');
            effects.spawnSparks(_tmpB.copy(toPos).setY(0.98), sparkColor, 12);
          });
          const stag = seg(b, 0.52, 1.0);
          defender.torso.rotation.x = -Math.sin(stag * Math.PI) * 0.36;
          defender.torso.rotation.y = Math.sin(stag * Math.PI) * 0.45;
          defender.root.position.lerpVectors(toPos, _tmpA.copy(toPos).addScaledVector(normDir, 0.18), Math.sin(stag * Math.PI));
        }
      } else if (p < 0.74) {
        // Beat 3: Final Overhead Royal Strike
        const b = seg(p, 0.54, 0.74);
        if (b < 0.42) {
          const raise = easeOutCubic(b / 0.42);
          attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-0.55, -2.35, raise), 0, -0.15);
          attacker.torso.rotation.y = THREE.MathUtils.lerp(-0.42, 0, raise);
          attacker.torso.rotation.x = -0.18 * raise;
          attacker.root.position.y = Math.sin(raise * Math.PI * 0.5) * 0.22;
        } else {
          const strike = easeOutCubic((b - 0.42) / 0.38);
          attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-2.35, 0.55, strike), 0, -0.12);
          attacker.torso.rotation.x = THREE.MathUtils.lerp(-0.18, 0.32, strike);
          attacker.root.position.y = THREE.MathUtils.lerp(0.22, 0, strike);
          attacker.root.position.lerpVectors(duelSpot, _tmpA.copy(duelSpot).addScaledVector(normDir, 0.24), strike);
          if (b > 0.45) {
            triggerOnce(ctx, 'k_sw3', () => {
              playSound('swing');
              effects.spawnSwingTrail(attacker.root.position, travelAngle, ctx.payload.color, {
                tiltX: Math.PI * 0.45,
                scale: 1.25,
                height: 1.1,
              });
            });
          }
          if (b > 0.68) {
            triggerOnce(ctx, 'k_fin', () => {
              playSound('metalHeavy');
              ctx.shakeIntensity = 0.055;
              effects.spawnShockwave(toPos, 0xfbbf24, 3.4);
              effects.spawnSparks(_tmpB.copy(toPos).setY(0.95), 0xfde68a, 16);
              effects.spawnDust(toPos, 6);
            });
          }
        }
      } else {
        // Defender Fall + King Royal Victory Pose
        const f = seg(p, 0.74, 0.88);
        applyDefenderFall(defender, clamp01(f / 0.65), seg(f, 0.72, 1.0), ctx, playSound);
        attacker.rightArm.rotation.set(THREE.MathUtils.lerp(0.55, -0.95, f), 0, -0.15);
        attacker.torso.rotation.set(THREE.MathUtils.lerp(0.32, 0, f), 0, 0);
      }
    } else if (type === 'q') {
      // QUEEN: Agile Dodge -> 360 Spin Halberd Attack -> Quick Dash & Radiant Finishing Strike
      if (p < 0.34) {
        // Beat 1: Defender swings, Queen executes fast lateral side-step dodge
        const b = seg(p, 0.18, 0.34);
        defender.rightArm.rotation.set(THREE.MathUtils.lerp(-0.65, 0.4, Math.sin(b * Math.PI)), 0.3, -0.3);
        if (b > 0.2) {
          triggerOnce(ctx, 'q_def_sw', () => playSound('swingFast'));
        }
        const dodgeArc = Math.sin(b * Math.PI);
        attacker.root.position.copy(duelSpot).addScaledVector(sidePerp, dodgeArc * 0.56);
        attacker.torso.rotation.z = dodgeArc * 0.25;
      } else if (p < 0.54) {
        // Beat 2: Rapid 360° Spin Attack
        const b = seg(p, 0.34, 0.54);
        attacker.root.position.lerpVectors(
          _tmpA.copy(duelSpot).addScaledVector(sidePerp, 0.15),
          _tmpB.copy(duelSpot).addScaledVector(normDir, 0.18),
          b
        );
        attacker.body.rotation.y = travelAngle + easeInOutQuad(b) * Math.PI * 2;
        attacker.rightArm.rotation.set(-0.35, 0.4, -1.15);
        attacker.torso.rotation.z = 0;

        if (b > 0.2) {
          triggerOnce(ctx, 'q_spin', () => {
            playSound('swingFast');
            effects.spawnSwingTrail(attacker.root.position, travelAngle, ctx.payload.color, {
              scale: 1.35,
              fullSpin: true,
              height: 0.98,
            });
          });
        }
        if (b > 0.58) {
          triggerOnce(ctx, 'q_hit1', () => {
            playSound('metal');
            effects.spawnSparks(_tmpB.copy(toPos).setY(1.0), magicColor, 14);
          });
          defender.torso.rotation.y = -0.45 * Math.sin((b - 0.58) * Math.PI * 2);
          defender.torso.rotation.x = -0.25;
        }
      } else if (p < 0.73) {
        // Beat 3: Quick Dash & Radiant Finishing Strike
        const b = seg(p, 0.54, 0.73);
        const dash = easeOutCubic(clamp01(b / 0.55));
        attacker.body.rotation.y = travelAngle;
        attacker.root.position.lerpVectors(duelSpot, _tmpA.copy(duelSpot).addScaledVector(normDir, 0.32), dash);
        attacker.root.position.y = Math.sin(dash * Math.PI) * 0.28;
        attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-1.9, 0.55, dash), 0, -0.2);
        attacker.torso.rotation.x = THREE.MathUtils.lerp(-0.15, 0.25, dash);

        if (b > 0.25) {
          triggerOnce(ctx, 'q_sw2', () => playSound('swingFast'));
        }
        if (b > 0.55) {
          triggerOnce(ctx, 'q_fin', () => {
            playSound('magicImpact');
            playSound('metalHeavy');
            ctx.shakeIntensity = 0.05;
            effects.spawnShockwave(toPos, magicColor, 3.6, 0.85);
            effects.spawnSparks(_tmpB.copy(toPos).setY(1.05), magicColor, 18);
          });
        }
      } else {
        const f = seg(p, 0.73, 0.88);
        applyDefenderFall(defender, clamp01(f / 0.65), seg(f, 0.72, 1.0), ctx, playSound);
        attacker.torso.rotation.set(THREE.MathUtils.lerp(0.25, 0, f), 0, 0);
        attacker.rightArm.rotation.set(THREE.MathUtils.lerp(0.55, -0.45, f), 0, -0.15);
      }
    } else if (type === 'r') {
      // ROOK: Heavy Warrior — Shield Bash -> Slow Heavy Battleaxe Strike -> Crushing Finishing Slam
      if (p < 0.38) {
        // Beat 1: Heavy Tower Shield Bash
        const b = seg(p, 0.18, 0.38);
        const lunge = Math.sin(b * Math.PI);
        attacker.root.position.copy(duelSpot).addScaledVector(normDir, lunge * 0.34);
        attacker.leftArm.rotation.set(THREE.MathUtils.lerp(-0.55, -1.35, lunge), 0.35, 0.2);
        attacker.torso.rotation.y = lunge * 0.48;

        if (b > 0.42) {
          triggerOnce(ctx, 'r_bash', () => {
            playSound('shield');
            ctx.shakeIntensity = 0.04;
            effects.spawnShockwave(_tmpB.copy(toPos).setY(0.95), 0xfbbf24, 2.2, 0.95);
            effects.spawnSparks(_tmpB.copy(toPos).setY(0.95), 0xfbbf24, 12);
          });
          const stag = seg(b, 0.42, 1.0);
          defender.root.position.copy(toPos).addScaledVector(normDir, Math.sin(stag * Math.PI) * 0.26);
          defender.torso.rotation.x = -Math.sin(stag * Math.PI) * 0.38;
        }
      } else if (p < 0.57) {
        // Beat 2: Slow Heavy Battleaxe Cleave
        const b = seg(p, 0.38, 0.57);
        if (b < 0.4) {
          const wind = easeOutCubic(b / 0.4);
          attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-0.3, -1.5, wind), -1.0, -0.5);
          attacker.torso.rotation.y = THREE.MathUtils.lerp(0.2, -0.55, wind);
        } else {
          const cleave = easeOutCubic((b - 0.4) / 0.45);
          attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-1.5, 0.2, cleave), THREE.MathUtils.lerp(-1.0, 0.9, cleave), -0.65);
          attacker.torso.rotation.y = THREE.MathUtils.lerp(-0.55, 0.5, cleave);
          if (b > 0.44) {
            triggerOnce(ctx, 'r_sw1', () => {
              playSound('swing');
              effects.spawnSwingTrail(attacker.root.position, travelAngle, ctx.payload.color, {
                tiltZ: 0.25,
                scale: 1.2,
                height: 0.95,
              });
            });
          }
          if (b > 0.68) {
            triggerOnce(ctx, 'r_hit1', () => {
              playSound('metal');
              effects.spawnSparks(_tmpB.copy(toPos).setY(0.95), sparkColor, 14);
            });
            defender.leftArm.rotation.x = -1.2;
            defender.torso.rotation.y = 0.35;
          }
        }
      } else if (p < 0.75) {
        // Beat 3: Crushing Downward Finishing Axe Slam
        const b = seg(p, 0.57, 0.75);
        if (b < 0.45) {
          const lift = easeOutCubic(b / 0.45);
          attacker.rightArm.rotation.set(THREE.MathUtils.lerp(0.2, -2.55, lift), 0, -0.1);
          attacker.torso.rotation.set(-0.22 * lift, THREE.MathUtils.lerp(0.5, 0, lift), 0);
        } else {
          const slam = easeOutCubic((b - 0.45) / 0.35);
          attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-2.55, 0.65, slam), 0, -0.1);
          attacker.torso.rotation.x = THREE.MathUtils.lerp(-0.22, 0.38, slam);
          if (b > 0.48) {
            triggerOnce(ctx, 'r_sw2', () => playSound('swing'));
          }
          if (b > 0.7) {
            triggerOnce(ctx, 'r_fin', () => {
              playSound('metalHeavy');
              ctx.shakeIntensity = 0.068;
              effects.spawnShockwave(toPos, 0xf97316, 4.0, 0.14);
              effects.spawnSparks(_tmpB.copy(toPos).setY(0.9), 0xfbbf24, 18);
              effects.spawnDust(toPos, 8);
            });
          }
        }
      } else {
        const f = seg(p, 0.75, 0.88);
        applyDefenderFall(defender, clamp01(f / 0.65), seg(f, 0.72, 1.0), ctx, playSound);
        attacker.torso.rotation.set(THREE.MathUtils.lerp(0.38, 0, f), 0, 0);
        attacker.rightArm.rotation.set(THREE.MathUtils.lerp(0.65, -0.32, f), 0, -0.14);
        attacker.leftArm.rotation.set(-0.35, 0, 0.08);
      }
    } else if (type === 'b') {
      // BISHOP: Mage/Priest — Staff Raise & Energy Gather -> Arcane Bolt Projectile -> Finishing Surge
      // Keep slightly wider casting distance
      const castSpot = _tmpA.copy(toPos).addScaledVector(normDir, -1.28);
      attacker.root.position.lerp(castSpot, 0.18);

      if (p < 0.38) {
        // Beat 1: Staff Movement & Magical Energy Gathering
        const b = seg(p, 0.18, 0.38);
        attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-0.75, -1.35, b), 0, -0.2);
        attacker.leftArm.rotation.set(-0.65, 0.25, 0.2);
        attacker.torso.rotation.x = -0.1 * b;
        if (attacker.crystal) {
          attacker.crystal.rotation.y += dt * 12;
          attacker.crystal.scale.setScalar(0.92 + Math.sin(b * Math.PI * 3) * 0.25);
        }
        triggerOnce(ctx, 'b_charge', () => {
          playSound('magicCharge');
          effects.spawnShockwave(_tmpB.copy(attacker.root.position).setY(1.45), magicColor, 1.6, 1.45);
        });
      } else if (p < 0.57) {
        // Beat 2: Cast Glowing Projectile 1 -> Defender Magic Impact Reaction
        const b = seg(p, 0.38, 0.57);
        const cast = easeOutCubic(clamp01(b / 0.38));
        attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-1.35, -0.25, cast), 0, -0.1);
        attacker.torso.rotation.x = THREE.MathUtils.lerp(-0.1, 0.18, cast);

        if (b > 0.18) {
          triggerOnce(ctx, 'b_proj1', () => {
            const start = attacker.root.position.clone().add(new THREE.Vector3(0, 1.42, 0));
            const end = toPos.clone().add(new THREE.Vector3(0, 0.95, 0));
            effects.spawnMagicProjectile(start, end, ctx.payload.color, 0.24);
          });
        }
        if (b > 0.62) {
          triggerOnce(ctx, 'b_imp1', () => {
            playSound('magicImpact');
            effects.spawnShockwave(toPos, magicColor, 2.6, 0.95);
            effects.spawnSparks(_tmpB.copy(toPos).setY(0.95), magicColor, 14);
          });
          const recoil = seg(b, 0.62, 1.0);
          defender.leftArm.rotation.set(-1.35, 0.4, 0.1); // Shielding face from spell
          defender.torso.rotation.x = -Math.sin(recoil * Math.PI) * 0.32;
        }
      } else if (p < 0.75) {
        // Beat 3: Arcane Staff Sweep & Finishing Spell Burst
        const b = seg(p, 0.57, 0.75);
        if (b < 0.4) {
          const wind = easeOutCubic(b / 0.4);
          attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-0.25, -1.75, wind), -0.35, -0.15);
          attacker.torso.rotation.y = -0.35 * wind;
        } else {
          const release = easeOutCubic((b - 0.4) / 0.4);
          attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-1.75, -0.4, release), 0.25, -0.1);
          attacker.torso.rotation.y = THREE.MathUtils.lerp(-0.35, 0.2, release);
          if (b > 0.44) {
            triggerOnce(ctx, 'b_proj2', () => {
              const start = attacker.root.position.clone().add(new THREE.Vector3(0, 1.46, 0));
              const end = toPos.clone().add(new THREE.Vector3(0, 0.95, 0));
              effects.spawnMagicProjectile(start, end, ctx.payload.color, 0.18);
            });
          }
          if (b > 0.68) {
            triggerOnce(ctx, 'b_fin', () => {
              playSound('magicImpact');
              ctx.shakeIntensity = 0.048;
              effects.spawnShockwave(toPos, magicColor, 3.8, 0.85);
              effects.spawnSparks(_tmpB.copy(toPos).setY(0.95), magicColor, 20);
            });
          }
        }
      } else {
        const f = seg(p, 0.75, 0.88);
        applyDefenderFall(defender, clamp01(f / 0.65), seg(f, 0.72, 1.0), ctx, playSound);
        if (attacker.crystal) attacker.crystal.scale.setScalar(0.92);
        attacker.rightArm.rotation.set(-0.22, 0, -0.1);
        attacker.torso.rotation.set(0, 0, 0);
      }
    } else if (type === 'n') {
      // KNIGHT: Cavalry Charge — Pass & Mounted Swing -> Horse Turns Around -> Final Charge Strike
      const passStart = duelSpot;
      const passMid = _tmpA.copy(toPos).addScaledVector(sidePerp, 0.75);
      const passEnd = _tmpB.copy(toPos).addScaledVector(normDir, 1.05).addScaledVector(sidePerp, 0.35);

      if (p < 0.4) {
        // Beat 1: Horse charges past defender & Knight swings lance/weapon
        const b = seg(p, 0.18, 0.4);
        // Quadratic Bezier curve past defender
        const inv = 1 - b;
        attacker.root.position.set(
          inv * inv * passStart.x + 2 * inv * b * passMid.x + b * b * passEnd.x,
          Math.abs(Math.sin(b * Math.PI * 3)) * 0.12,
          inv * inv * passStart.z + 2 * inv * b * passMid.z + b * b * passEnd.z
        );
        animateWalkStride(attacker, b * Math.PI * 5, 0.62);

        // Face tangent of curve
        const tanX = 2 * inv * (passMid.x - passStart.x) + 2 * b * (passEnd.x - passMid.x);
        const tanZ = 2 * inv * (passMid.z - passStart.z) + 2 * b * (passEnd.z - passMid.z);
        attacker.body.rotation.y = shortestAngleLerp(attacker.body.rotation.y, Math.atan2(tanX, tanZ), 0.35);

        // Mounted weapon swing while passing
        const sw = Math.sin(clamp01((b - 0.25) / 0.5) * Math.PI);
        attacker.rightArm.rotation.set(-0.45 - sw * 0.7, sw * 0.9, -0.35);

        if (b > 0.32) {
          triggerOnce(ctx, 'n_sw1', () => {
            playSound('swing');
            effects.spawnSwingTrail(toPos, travelAngle, ctx.payload.color, { tiltZ: 0.25, scale: 1.25, height: 1.0 });
          });
        }
        if (b > 0.52) {
          triggerOnce(ctx, 'n_hit1', () => {
            playSound('metal');
            effects.spawnSparks(_tmpC.copy(toPos).setY(1.0), sparkColor, 14);
          });
          defender.torso.rotation.y = -0.5 * Math.sin((b - 0.52) * Math.PI * 2);
          defender.leftArm.rotation.x = -1.1;
        }
      } else if (p < 0.58) {
        // Beat 2: Horse turns around 180° cleanly to line up final charge
        const b = seg(p, 0.4, 0.58);
        triggerOnce(ctx, 'gallop2', () => playSound('gallop'));
        const turnArc = _tmpC.copy(toPos).addScaledVector(normDir, 1.15);
        attacker.root.position.lerpVectors(passEnd, turnArc, easeInOutQuad(b));
        animateWalkStride(attacker, b * Math.PI * 3, 0.45);
        attacker.body.rotation.y = shortestAngleLerp(attacker.body.rotation.y, travelAngle + Math.PI, 0.28);
        defender.body.rotation.y = shortestAngleLerp(defender.body.rotation.y, travelAngle, 0.25);
        attacker.rightArm.rotation.set(-1.1, 0, -0.15);
      } else if (p < 0.76) {
        // Beat 3: Final Mounted Charge Strike straight into defender!
        const b = seg(p, 0.58, 0.76);
        const startCharge = _tmpC.copy(toPos).addScaledVector(normDir, 1.15);
        const endCharge = _tmpA.copy(toPos).addScaledVector(normDir, 0.42);
        attacker.root.position.lerpVectors(startCharge, endCharge, easeOutCubic(b));
        attacker.root.position.y = Math.sin(b * Math.PI) * 0.16;
        animateWalkStride(attacker, b * Math.PI * 4, 0.58);
        attacker.body.rotation.y = travelAngle + Math.PI;
        attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-1.1, 0.35, b), 0, -0.15);

        if (b > 0.3) {
          triggerOnce(ctx, 'n_sw2', () => playSound('swingFast'));
        }
        if (b > 0.65) {
          triggerOnce(ctx, 'n_fin', () => {
            playSound('metalHeavy');
            ctx.shakeIntensity = 0.062;
            effects.spawnShockwave(toPos, 0xfbbf24, 3.6, 0.14);
            effects.spawnSparks(_tmpB.copy(toPos).setY(1.02), 0xfde68a, 16);
            effects.spawnDust(toPos, 7);
          });
        }
      } else {
        const f = seg(p, 0.76, 0.88);
        applyDefenderFall(defender, clamp01(f / 0.65), seg(f, 0.72, 1.0), ctx, playSound);
        attacker.rightArm.rotation.set(-0.25, 0, -0.1);
      }
    } else {
      // PAWN: Trained Foot Soldier — Sword Slash (Blocked) -> Defender Counter (Pawn Shield Block) -> Final Strike
      if (p < 0.37) {
        // Beat 1: Pawn sword slash -> Defender blocks
        const b = seg(p, 0.18, 0.37);
        const swing = easeInOutQuad(clamp01(b / 0.7));
        attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-0.85, 0.35, swing), THREE.MathUtils.lerp(-0.4, 0.6, swing), -0.35);
        attacker.torso.rotation.y = THREE.MathUtils.lerp(-0.25, 0.32, swing);
        if (b > 0.22) {
          triggerOnce(ctx, 'p_sw1', () => {
            playSound('swingFast');
            effects.spawnSwingTrail(attacker.root.position, travelAngle, ctx.payload.color, { scale: 0.9, height: 0.78 });
          });
        }
        if (b > 0.55) {
          triggerOnce(ctx, 'p_hit1', () => {
            playSound('shield');
            effects.spawnSparks(_tmpB.copy(toPos).setY(0.82), 0xfde68a, 8);
          });
          defender.leftArm.rotation.x = -1.15;
        }
      } else if (p < 0.57) {
        // Beat 2: Defender counter-attacks -> Pawn blocks with shield!
        const b = seg(p, 0.37, 0.57);
        const counter = Math.sin(b * Math.PI);
        defender.rightArm.rotation.set(THREE.MathUtils.lerp(-0.65, 0.45, counter), counter * 0.5, -0.35);
        defender.torso.rotation.y = counter * 0.35;
        attacker.leftArm.rotation.set(-1.2, 0.35, 0.15); // Raise shield!
        attacker.torso.rotation.y = -0.25 * counter;

        if (b > 0.2) {
          triggerOnce(ctx, 'p_def_sw', () => playSound('swingFast'));
        }
        if (b > 0.48) {
          triggerOnce(ctx, 'p_blk', () => {
            playSound('shield');
            effects.spawnSparks(_tmpB.copy(attacker.root.position).addScaledVector(normDir, 0.25).setY(0.84), 0x93c5fd, 10);
          });
        }
      } else if (p < 0.74) {
        // Beat 3: Final Soldier Strike
        const b = seg(p, 0.57, 0.74);
        const strike = easeOutCubic(clamp01(b / 0.65));
        attacker.root.position.lerpVectors(duelSpot, _tmpA.copy(duelSpot).addScaledVector(normDir, 0.24), strike);
        attacker.rightArm.rotation.set(THREE.MathUtils.lerp(-1.25, 0.45, strike), 0, -0.15);
        attacker.leftArm.rotation.set(-0.3, 0, 0.1);
        attacker.torso.rotation.set(THREE.MathUtils.lerp(-0.1, 0.24, strike), 0, 0);

        if (b > 0.2) {
          triggerOnce(ctx, 'p_sw2', () => {
            playSound('swingFast');
            effects.spawnSwingTrail(attacker.root.position, travelAngle, ctx.payload.color, {
              tiltX: 0.6,
              scale: 0.95,
              height: 0.8,
            });
          });
        }
        if (b > 0.58) {
          triggerOnce(ctx, 'p_fin', () => {
            playSound('metalHeavy');
            ctx.shakeIntensity = 0.038;
            effects.spawnShockwave(toPos, sparkColor, 2.4, 0.14);
            effects.spawnSparks(_tmpB.copy(toPos).setY(0.82), sparkColor, 12);
          });
        }
      } else {
        const f = seg(p, 0.74, 0.88);
        applyDefenderFall(defender, clamp01(f / 0.65), seg(f, 0.72, 1.0), ctx, playSound);
        attacker.torso.rotation.set(THREE.MathUtils.lerp(0.24, 0, f), 0, 0);
        attacker.rightArm.rotation.set(THREE.MathUtils.lerp(0.45, -0.22, f), 0, -0.12);
      }
    }
  } else {
    // 0.88 -> 1.00: Claim defeated square & face enemy kingdom cleanly
    const t = easeOutCubic(seg(p, 0.88, 1.0));
    if (!ctx.claimStartPos) {
      ctx.claimStartPos = attacker.root.position.clone();
    }
    defender.root.visible = false;
    attacker.root.position.lerpVectors(ctx.claimStartPos, toPos, t);
    attacker.root.position.y = Math.sin(t * Math.PI) * 0.08;
    animateWalkStride(attacker, t * Math.PI * 2, 0.3);
    attacker.body.rotation.y = shortestAngleLerp(attacker.body.rotation.y, homeAngle, 0.24);
    attacker.torso.rotation.set(0, 0, 0);
    attacker.rightArm.rotation.set(-0.28, 0, -0.12);
    attacker.leftArm.rotation.set(-0.25, 0, 0.12);
  }

  // Camera Choreography: Zoom in, slowly orbit around duelists, subtle impact shake, return smoothly!
  const mid = _tmpA.lerpVectors(duelSpot, toPos, 0.52);
  if (p < 0.84) {
    const orbitAngle = (p - 0.18) * 0.65; // Gentle ~24 degree cinematic orbit around battle
    const cosA = Math.cos(orbitAngle);
    const sinA = Math.sin(orbitAngle);
    const baseOffsetX = sidePerp.x * 2.35 - normDir.x * 0.95;
    const baseOffsetZ = sidePerp.z * 2.35 - normDir.z * 0.95;

    const rotX = baseOffsetX * cosA - baseOffsetZ * sinA;
    const rotZ = baseOffsetX * sinA + baseOffsetZ * cosA;

    const camGoal = _tmpB.set(mid.x + rotX, 1.48, mid.z + rotZ);
    const targetGoal = _tmpC.set(mid.x, 0.96, mid.z);

    const camAlpha = 1 - Math.exp(-7.5 * dt);
    camera.position.lerp(camGoal, camAlpha);
    targetOut.lerp(targetGoal, camAlpha);

    // Subtle damped micro-shake on heavy impacts
    if (ctx.shakeIntensity > 0.001) {
      camera.position.x += (Math.random() - 0.5) * ctx.shakeIntensity;
      camera.position.y += (Math.random() - 0.5) * ctx.shakeIntensity * 0.7;
      ctx.shakeIntensity *= Math.exp(-16 * dt);
    }
  } else {
    const retAlpha = 1 - Math.exp(-7.0 * dt);
    camera.position.lerp(ctx.savedCamPos, retAlpha);
    targetOut.lerp(ctx.savedTarget, retAlpha);
  }
}
