import * as THREE from 'three';
import type { PieceColor } from '../types/chess';

export interface KingdomMaterials {
  armorPrimary: THREE.MeshPhysicalMaterial;
  armorDarkSteel: THREE.MeshPhysicalMaterial;
  armorSecondary: THREE.MeshStandardMaterial;
  armorTrim: THREE.MeshPhysicalMaterial;
  chainmail: THREE.MeshStandardMaterial;
  cloth: THREE.MeshPhysicalMaterial;
  tabard: THREE.MeshPhysicalMaterial;
  royalTabard: THREE.MeshPhysicalMaterial;
  pawnCoat: THREE.MeshPhysicalMaterial;
  crimsonAccent: THREE.MeshPhysicalMaterial;
  cape: THREE.MeshPhysicalMaterial;
  gown: THREE.MeshPhysicalMaterial;
  queenGown: THREE.MeshPhysicalMaterial;
  crownVelvet: THREE.MeshPhysicalMaterial;
  furTrim: THREE.MeshStandardMaterial;
  shieldFace: THREE.MeshPhysicalMaterial;
  skin: THREE.MeshPhysicalMaterial;
  skinFemale: THREE.MeshPhysicalMaterial;
  skinWarrior: THREE.MeshPhysicalMaterial;
  skinMage: THREE.MeshPhysicalMaterial;
  skinYoung: THREE.MeshPhysicalMaterial;
  skinBody: THREE.MeshPhysicalMaterial;
  lips: THREE.MeshStandardMaterial;
  sclera: THREE.MeshPhysicalMaterial;
  iris: THREE.MeshStandardMaterial;
  cornea: THREE.MeshPhysicalMaterial;
  lashLine: THREE.MeshStandardMaterial;
  eyebrow: THREE.MeshStandardMaterial;
  leather: THREE.MeshStandardMaterial;
  trousers: THREE.MeshStandardMaterial;
  wood: THREE.MeshStandardMaterial;
  weaponBlade: THREE.MeshPhysicalMaterial;
  gem: THREE.MeshStandardMaterial;
  horseCoat: THREE.MeshStandardMaterial;
  horseMane: THREE.MeshStandardMaterial;
  horseCaparison: THREE.MeshPhysicalMaterial;
  hair: THREE.MeshStandardMaterial;
  hairAuburn: THREE.MeshStandardMaterial;
  hairSilver: THREE.MeshStandardMaterial;
}

export interface SceneMaterialBank {
  white: KingdomMaterials;
  black: KingdomMaterials;
  lightTile: THREE.MeshStandardMaterial;
  darkTile: THREE.MeshStandardMaterial;
  stoneApron: THREE.MeshStandardMaterial;
  boardFrame: THREE.MeshStandardMaterial;
  boardGoldTrim: THREE.MeshPhysicalMaterial;
  waterMoat: THREE.MeshPhysicalMaterial;
  waterNormalMap: THREE.CanvasTexture;
  citadelGround: THREE.MeshStandardMaterial;
  ruinStone: THREE.MeshStandardMaterial;
  brazierIron: THREE.MeshStandardMaterial;
  brazierEmber: THREE.MeshStandardMaterial;
  brazierFlame: THREE.MeshBasicMaterial;
  contactShadowMat: THREE.MeshBasicMaterial;
  emberTexture: THREE.CanvasTexture;
  coordTextures: {
    files: THREE.CanvasTexture[];
    ranks: THREE.CanvasTexture[];
  };
  dispose: () => void;
}

function createNormalMapFromHeightCanvas(
  heightCanvas: HTMLCanvasElement,
  strength: number,
  maxAnisotropy: number,
  repeat = 1
): THREE.CanvasTexture {
  const w = heightCanvas.width;
  const h = heightCanvas.height;
  const srcCtx = heightCanvas.getContext('2d')!;
  const src = srcCtx.getImageData(0, 0, w, h).data;

  const outCanvas = document.createElement('canvas');
  outCanvas.width = w;
  outCanvas.height = h;
  const outCtx = outCanvas.getContext('2d')!;
  const outImg = outCtx.createImageData(w, h);
  const dst = outImg.data;

  const sample = (x: number, y: number): number => {
    const wx = ((x % w) + w) % w;
    const wy = ((y % h) + h) % h;
    return src[(wy * w + wx) * 4] / 255;
  };

  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const tl = sample(x - 1, y - 1);
      const t = sample(x, y - 1);
      const tr = sample(x + 1, y - 1);
      const l = sample(x - 1, y);
      const r = sample(x + 1, y);
      const bl = sample(x - 1, y + 1);
      const b = sample(x, y + 1);
      const br = sample(x + 1, y + 1);

      const dx = tr + 2 * r + br - (tl + 2 * l + bl);
      const dy = bl + 2 * b + br - (tl + 2 * t + tr);

      let nx = -dx * strength;
      let ny = -dy * strength;
      let nz = 1.0;
      const invLen = 1 / Math.hypot(nx, ny, nz);
      nx *= invLen;
      ny *= invLen;
      nz *= invLen;

      const idx = (y * w + x) * 4;
      dst[idx] = Math.round((nx * 0.5 + 0.5) * 255);
      dst[idx + 1] = Math.round((ny * 0.5 + 0.5) * 255);
      dst[idx + 2] = Math.round((nz * 0.5 + 0.5) * 255);
      dst[idx + 3] = 255;
    }
  }

  outCtx.putImageData(outImg, 0, 0);
  const tex = new THREE.CanvasTexture(outCanvas);
  tex.anisotropy = maxAnisotropy;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(repeat, repeat);
  return tex;
}

function createMarbleTexture(
  baseHex: string,
  veinHex: string,
  accentHex: string,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, size, size);

  for (let i = 0; i < 650; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const r = 0.6 + Math.random() * 2.0;
    ctx.fillStyle = i % 3 === 0 ? accentHex : veinHex;
    ctx.globalAlpha = 0.05 + Math.random() * 0.07;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  ctx.globalAlpha = 0.2;
  ctx.strokeStyle = veinHex;
  for (let v = 0; v < 5; v++) {
    ctx.lineWidth = 0.8 + Math.random() * 1.8;
    ctx.beginPath();
    let x = Math.random() * size;
    let y = 0;
    ctx.moveTo(x, y);
    for (let step = 1; step <= 8; step++) {
      x += (Math.random() - 0.5) * 44;
      y = (step / 8) * size;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
  }

  ctx.globalAlpha = 0.14;
  ctx.strokeStyle = accentHex;
  ctx.lineWidth = 3;
  ctx.strokeRect(2, 2, size - 4, size - 4);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

/**
 * Carved Dark Citadel Basalt/Granite Stone Paving Apron Texture + Normal Map
 */
function createDarkCitadelStoneMaps(maxAnisotropy: number, repeat = 5): {
  map: THREE.CanvasTexture;
  normalMap: THREE.CanvasTexture;
} {
  const size = 256;
  const aCanvas = document.createElement('canvas');
  aCanvas.width = size;
  aCanvas.height = size;
  const aCtx = aCanvas.getContext('2d')!;

  const hCanvas = document.createElement('canvas');
  hCanvas.width = size;
  hCanvas.height = size;
  const hCtx = hCanvas.getContext('2d')!;

  aCtx.fillStyle = '#2d3442';
  aCtx.fillRect(0, 0, size, size);
  hCtx.fillStyle = '#929292';
  hCtx.fillRect(0, 0, size, size);

  const cells = 2;
  const cell = size / cells;
  for (let row = 0; row < cells; row++) {
    for (let col = 0; col < cells; col++) {
      const x = col * cell;
      const y = row * cell;
      const tint = (row + col) % 2 === 0 ? '#363f4f' : '#2a313e';
      aCtx.fillStyle = tint;
      aCtx.fillRect(x + 3, y + 3, cell - 6, cell - 6);

      // Subtle inner carved bevel groove
      aCtx.strokeStyle = 'rgba(130, 148, 178, 0.14)';
      aCtx.lineWidth = 1.5;
      aCtx.strokeRect(x + 9, y + 9, cell - 18, cell - 18);

      // Deep dark mortar seam
      aCtx.strokeStyle = '#151922';
      aCtx.lineWidth = 4;
      aCtx.strokeRect(x + 1, y + 1, cell - 2, cell - 2);

      hCtx.strokeStyle = '#262626';
      hCtx.lineWidth = 5;
      hCtx.strokeRect(x + 1, y + 1, cell - 2, cell - 2);

      hCtx.strokeStyle = '#5c5c5c';
      hCtx.lineWidth = 2;
      hCtx.strokeRect(x + 9, y + 9, cell - 18, cell - 18);
    }
  }

  // Granite mineral speckles & weathered pitting
  for (let i = 0; i < 1100; i++) {
    const px = Math.random() * size;
    const py = Math.random() * size;
    aCtx.fillStyle = i % 3 === 0 ? 'rgba(155,175,205,0.09)' : 'rgba(12,15,22,0.16)';
    aCtx.fillRect(px, py, 2, 1.5);
    hCtx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.11)' : 'rgba(0,0,0,0.12)';
    hCtx.fillRect(px, py, 2, 2);
  }

  const map = new THREE.CanvasTexture(aCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = maxAnisotropy;
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(repeat, repeat);

  const normalMap = createNormalMapFromHeightCanvas(hCanvas, 2.2, maxAnisotropy, repeat);
  return { map, normalMap };
}

/**
 * Stitched Pebbled Leather Texture + Normal Map
 */
function createLeatherMaps(
  baseHex: string,
  grainHex: string,
  stitchHex: string,
  maxAnisotropy: number
): {
  map: THREE.CanvasTexture;
  normalMap: THREE.CanvasTexture;
} {
  const size = 256;
  const aCanvas = document.createElement('canvas');
  aCanvas.width = size;
  aCanvas.height = size;
  const aCtx = aCanvas.getContext('2d')!;

  const hCanvas = document.createElement('canvas');
  hCanvas.width = size;
  hCanvas.height = size;
  const hCtx = hCanvas.getContext('2d')!;

  aCtx.fillStyle = baseHex;
  aCtx.fillRect(0, 0, size, size);
  hCtx.fillStyle = '#787878';
  hCtx.fillRect(0, 0, size, size);

  for (let i = 0; i < 1300; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    const r = 1.1 + Math.random() * 2.2;
    aCtx.fillStyle = i % 2 === 0 ? grainHex : 'rgba(255,225,190,0.05)';
    aCtx.beginPath();
    aCtx.arc(x, y, r, 0, Math.PI * 2);
    aCtx.fill();

    hCtx.fillStyle = i % 2 === 0 ? '#a8a8a8' : '#4a4a4a';
    hCtx.beginPath();
    hCtx.arc(x, y, r, 0, Math.PI * 2);
    hCtx.fill();
  }

  // Subtle stitched seam lines along strap borders
  for (const sy of [18, size - 18]) {
    for (let sx = 6; sx < size; sx += 14) {
      aCtx.fillStyle = stitchHex;
      aCtx.fillRect(sx, sy, 7, 2.2);
      hCtx.fillStyle = '#d8d8d8';
      hCtx.fillRect(sx, sy, 7, 2.2);
    }
  }

  const map = new THREE.CanvasTexture(aCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = maxAnisotropy;
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(2, 2);

  const normalMap = createNormalMapFromHeightCanvas(hCanvas, 2.0, maxAnisotropy, 2);
  return { map, normalMap };
}

/**
 * Rippled Water Moat Normal Map (linear space)
 */
function createWaterRippleNormalMap(maxAnisotropy: number): THREE.CanvasTexture {
  const size = 256;
  const hCanvas = document.createElement('canvas');
  hCanvas.width = size;
  hCanvas.height = size;
  const hCtx = hCanvas.getContext('2d')!;

  hCtx.fillStyle = '#808080';
  hCtx.fillRect(0, 0, size, size);

  for (let i = 0; i < 240; i++) {
    const cx = Math.random() * size;
    const cy = Math.random() * size;
    const rx = 10 + Math.random() * 24;
    const ry = 4 + Math.random() * 10;
    const g = hCtx.createRadialGradient(cx, cy, 1, cx, cy, rx);
    g.addColorStop(0, i % 2 === 0 ? 'rgba(220,220,220,0.18)' : 'rgba(30,30,30,0.18)');
    g.addColorStop(1, 'rgba(128,128,128,0)');
    hCtx.fillStyle = g;
    hCtx.beginPath();
    hCtx.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2);
    hCtx.fill();
  }

  return createNormalMapFromHeightCanvas(hCanvas, 1.4, maxAnisotropy, 6);
}

/**
 * Procedural PBR Metal Maps
 */
function createArmorTextureMaps(
  baseHex: string,
  etchHex: string,
  maxAnisotropy: number
): {
  map: THREE.CanvasTexture;
  normalMap: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
} {
  const size = 256;
  const albedoCanvas = document.createElement('canvas');
  albedoCanvas.width = size;
  albedoCanvas.height = size;
  const aCtx = albedoCanvas.getContext('2d')!;

  const heightCanvas = document.createElement('canvas');
  heightCanvas.width = size;
  heightCanvas.height = size;
  const hCtx = heightCanvas.getContext('2d')!;

  const roughCanvas = document.createElement('canvas');
  roughCanvas.width = size;
  roughCanvas.height = size;
  const rCtx = roughCanvas.getContext('2d')!;

  aCtx.fillStyle = baseHex;
  aCtx.fillRect(0, 0, size, size);

  hCtx.fillStyle = '#828282';
  hCtx.fillRect(0, 0, size, size);

  rCtx.fillStyle = '#484848';
  rCtx.fillRect(0, 0, size, size);

  for (let i = 0; i < 650; i++) {
    const y = Math.random() * size;
    const x = Math.random() * size;
    const len = 18 + Math.random() * 64;
    const bright = i % 2 === 0;
    aCtx.strokeStyle = bright ? 'rgba(255,255,255,0.06)' : 'rgba(0,0,0,0.07)';
    aCtx.lineWidth = 0.7 + Math.random() * 1.1;
    aCtx.beginPath();
    aCtx.moveTo(x, y);
    aCtx.lineTo(x + len, y + (Math.random() - 0.5) * 2);
    aCtx.stroke();

    hCtx.strokeStyle = bright ? 'rgba(255,255,255,0.09)' : 'rgba(0,0,0,0.09)';
    hCtx.lineWidth = 0.8;
    hCtx.beginPath();
    hCtx.moveTo(x, y);
    hCtx.lineTo(x + len, y);
    hCtx.stroke();

    rCtx.strokeStyle = bright ? 'rgba(130,130,130,0.16)' : 'rgba(40,40,40,0.16)';
    rCtx.beginPath();
    rCtx.moveTo(x, y);
    rCtx.lineTo(x + len, y);
    rCtx.stroke();
  }

  for (let i = 0; i < 110; i++) {
    const cx = Math.random() * size;
    const cy = Math.random() * size;
    const rad = 4 + Math.random() * 8;
    const g = hCtx.createRadialGradient(cx, cy, 0, cx, cy, rad);
    g.addColorStop(0, 'rgba(0,0,0,0.14)');
    g.addColorStop(1, 'rgba(0,0,0,0)');
    hCtx.fillStyle = g;
    hCtx.beginPath();
    hCtx.arc(cx, cy, rad, 0, Math.PI * 2);
    hCtx.fill();
  }

  for (const bandY of [size * 0.14, size * 0.86]) {
    aCtx.strokeStyle = etchHex;
    aCtx.globalAlpha = 0.25;
    aCtx.lineWidth = 2;
    aCtx.beginPath();
    aCtx.moveTo(0, bandY);
    aCtx.lineTo(size, bandY);
    aCtx.stroke();

    hCtx.strokeStyle = '#383838';
    hCtx.lineWidth = 2.5;
    hCtx.beginPath();
    hCtx.moveTo(0, bandY);
    hCtx.lineTo(size, bandY);
    hCtx.stroke();

    rCtx.strokeStyle = '#a0a0a0';
    rCtx.lineWidth = 2.5;
    rCtx.beginPath();
    rCtx.moveTo(0, bandY);
    rCtx.lineTo(size, bandY);
    rCtx.stroke();

    for (let x = 8; x < size; x += 24) {
      aCtx.beginPath();
      aCtx.arc(x, bandY + (bandY < size / 2 ? 10 : -10), 6, 0, Math.PI * 2);
      aCtx.stroke();
      hCtx.beginPath();
      hCtx.arc(x, bandY + (bandY < size / 2 ? 10 : -10), 6, 0, Math.PI * 2);
      hCtx.stroke();
    }
    aCtx.globalAlpha = 1;
  }

  const map = new THREE.CanvasTexture(albedoCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = maxAnisotropy;
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;

  const normalMap = createNormalMapFromHeightCanvas(heightCanvas, 2.2, maxAnisotropy, 1);

  const roughnessMap = new THREE.CanvasTexture(roughCanvas);
  roughnessMap.anisotropy = maxAnisotropy;
  roughnessMap.wrapS = THREE.RepeatWrapping;
  roughnessMap.wrapT = THREE.RepeatWrapping;

  return { map, normalMap, roughnessMap };
}

function createChainmailMaps(
  ringHex: string,
  darkGapHex: string,
  maxAnisotropy: number
): {
  map: THREE.CanvasTexture;
  normalMap: THREE.CanvasTexture;
} {
  const size = 256;
  const aCanvas = document.createElement('canvas');
  aCanvas.width = size;
  aCanvas.height = size;
  const aCtx = aCanvas.getContext('2d')!;

  const hCanvas = document.createElement('canvas');
  hCanvas.width = size;
  hCanvas.height = size;
  const hCtx = hCanvas.getContext('2d')!;

  aCtx.fillStyle = darkGapHex;
  aCtx.fillRect(0, 0, size, size);
  hCtx.fillStyle = '#202020';
  hCtx.fillRect(0, 0, size, size);

  const stepX = 16;
  const stepY = 12;
  for (let row = -1; row <= size / stepY + 1; row++) {
    const offsetX = (row % 2) * (stepX * 0.5);
    for (let col = -1; col <= size / stepX + 1; col++) {
      const cx = col * stepX + offsetX;
      const cy = row * stepY;

      aCtx.strokeStyle = ringHex;
      aCtx.lineWidth = 3.2;
      aCtx.beginPath();
      aCtx.ellipse(cx, cy, 7.2, 5.2, row % 2 === 0 ? 0.25 : -0.25, 0, Math.PI * 2);
      aCtx.stroke();

      hCtx.strokeStyle = '#dcdcdc';
      hCtx.lineWidth = 3.4;
      hCtx.beginPath();
      hCtx.ellipse(cx, cy, 7.2, 5.2, row % 2 === 0 ? 0.25 : -0.25, 0, Math.PI * 2);
      hCtx.stroke();
    }
  }

  const map = new THREE.CanvasTexture(aCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = maxAnisotropy;
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  map.repeat.set(3, 3);

  const normalMap = createNormalMapFromHeightCanvas(hCanvas, 2.8, maxAnisotropy, 3);
  return { map, normalMap };
}

function createRoyalClothMaps(
  baseHex: string,
  patternHex: string,
  trimHex: string,
  maxAnisotropy: number
): {
  map: THREE.CanvasTexture;
  normalMap: THREE.CanvasTexture;
} {
  const size = 256;
  const aCanvas = document.createElement('canvas');
  aCanvas.width = size;
  aCanvas.height = size;
  const aCtx = aCanvas.getContext('2d')!;

  const hCanvas = document.createElement('canvas');
  hCanvas.width = size;
  hCanvas.height = size;
  const hCtx = hCanvas.getContext('2d')!;

  aCtx.fillStyle = baseHex;
  aCtx.fillRect(0, 0, size, size);
  hCtx.fillStyle = '#7c7c7c';
  hCtx.fillRect(0, 0, size, size);

  aCtx.lineWidth = 1;
  hCtx.lineWidth = 1.5;
  for (let i = 0; i < size; i += 4) {
    aCtx.strokeStyle = 'rgba(255,255,255,0.03)';
    aCtx.beginPath();
    aCtx.moveTo(i, 0);
    aCtx.lineTo(i, size);
    aCtx.stroke();

    hCtx.strokeStyle = i % 8 === 0 ? 'rgba(255,255,255,0.16)' : 'rgba(0,0,0,0.14)';
    hCtx.beginPath();
    hCtx.moveTo(i, 0);
    hCtx.lineTo(i, size);
    hCtx.stroke();

    hCtx.beginPath();
    hCtx.moveTo(0, i);
    hCtx.lineTo(size, i);
    hCtx.stroke();
  }

  aCtx.strokeStyle = patternHex;
  aCtx.globalAlpha = 0.22;
  aCtx.lineWidth = 1.6;
  hCtx.strokeStyle = '#a8a8a8';
  hCtx.lineWidth = 1.6;
  const cell = 32;
  for (let y = 0; y < size; y += cell) {
    for (let x = 0; x < size; x += cell) {
      const cx = x + cell / 2;
      const cy = y + cell / 2;
      for (const ctx of [aCtx, hCtx]) {
        ctx.beginPath();
        ctx.moveTo(cx, cy - 11);
        ctx.lineTo(cx + 9, cy);
        ctx.lineTo(cx, cy + 11);
        ctx.lineTo(cx - 9, cy);
        ctx.closePath();
        ctx.stroke();
      }
    }
  }
  aCtx.globalAlpha = 1;

  // Embroidered golden hem border
  aCtx.fillStyle = trimHex;
  aCtx.fillRect(0, size - 22, size, 12);
  aCtx.fillRect(0, size - 6, size, 3);
  hCtx.fillStyle = '#c8c8c8';
  hCtx.fillRect(0, size - 22, size, 12);

  const map = new THREE.CanvasTexture(aCanvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = maxAnisotropy;
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.ClampToEdgeWrapping;

  const normalMap = createNormalMapFromHeightCanvas(hCanvas, 1.5, maxAnisotropy, 1);
  normalMap.wrapT = THREE.ClampToEdgeWrapping;
  return { map, normalMap };
}

function createFleurTabardTexture(
  bgHex: string,
  emblemHex: string,
  borderHex: string,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = bgHex;
  ctx.fillRect(0, 0, size, size);

  // Subtle woven fabric shading
  for (let i = 0; i < size; i += 4) {
    ctx.fillStyle = i % 8 === 0 ? 'rgba(255,255,255,0.03)' : 'rgba(0,0,0,0.05)';
    ctx.fillRect(i, 0, 2, size);
  }

  // Gold/bronze side trim & hem
  ctx.fillStyle = borderHex;
  ctx.fillRect(0, 0, 12, size);
  ctx.fillRect(size - 12, 0, 12, size);
  ctx.fillRect(0, size - 16, size, 16);

  // Draw crisp Fleur-de-Lis motifs vertically (top and lower)
  const drawFleur = (cx: number, cy: number, sc: number) => {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(sc, sc);
    ctx.fillStyle = emblemHex;
    // Center spearhead petal
    ctx.beginPath();
    ctx.moveTo(0, -34);
    ctx.bezierCurveTo(13, -12, 10, 8, 4, 16);
    ctx.lineTo(-4, 16);
    ctx.bezierCurveTo(-10, 8, -13, -12, 0, -34);
    ctx.fill();
    // Side curling petals
    for (const s of [-1, 1]) {
      ctx.beginPath();
      ctx.moveTo(s * 3, 12);
      ctx.bezierCurveTo(s * 24, -10, s * 30, 10, s * 16, 20);
      ctx.bezierCurveTo(s * 12, 12, s * 6, 15, s * 4, 22);
      ctx.fill();
    }
    // Crossbar & base
    ctx.fillRect(-16, 14, 32, 5);
    ctx.fillRect(-5, 19, 10, 12);
    ctx.restore();
  };

  drawFleur(size / 2, size * 0.34, 0.85);
  drawFleur(size / 2, size * 0.72, 1.05);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createScoutCoatMaps(
  baseHex: string,
  pipingHex: string,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, size, size);

  // Subtle fabric panel stitch shading
  ctx.strokeStyle = 'rgba(0,0,0,0.09)';
  ctx.lineWidth = 2;
  for (let x = 32; x < size; x += 64) {
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, size);
    ctx.stroke();
  }

  // Crimson red assassin/crusader hem & border trim
  ctx.fillStyle = pipingHex;
  ctx.fillRect(0, size - 18, size, 12);
  ctx.fillRect(0, 0, 10, size);
  ctx.fillRect(size - 10, 0, 10, size);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createShieldFaceTexture(
  isWhite: boolean,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const grad = ctx.createRadialGradient(size / 2, size / 2, 14, size / 2, size / 2, size * 0.6);
  if (isWhite) {
    // Crisp White Crusader / Royal Ivory & Gold Crest matching photo!
    grad.addColorStop(0, '#f4f1e8');
    grad.addColorStop(1, '#cfc8b8');
  } else {
    // Dark Obsidian & Bronze Wood/Iron Crest
    grad.addColorStop(0, '#302728');
    grad.addColorStop(1, '#141115');
  }
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);

  // Quartered cross / chevron accent
  ctx.fillStyle = isWhite ? '#d4a846' : '#7d2028';
  ctx.fillRect(size / 2 - 12, 14, 24, size - 28);
  ctx.fillRect(14, size / 2 - 12, size - 28, 24);

  const cx = size / 2;
  const cy = size / 2;
  ctx.fillStyle = isWhite ? '#e8bd54' : '#b87c42';
  ctx.beginPath();
  ctx.arc(cx, cy, 34, 0, Math.PI * 2);
  ctx.fill();

  ctx.strokeStyle = isWhite ? '#fff7dc' : '#e0a46c';
  ctx.lineWidth = 4;
  ctx.stroke();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createProceduralBumpTexture(
  mode: 'cloth' | 'leather' | 'skin' | 'hair' | 'wood',
  maxAnisotropy: number
): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = '#808080';
  ctx.fillRect(0, 0, size, size);

  if (mode === 'cloth') {
    ctx.lineWidth = 2;
    for (let i = 0; i < size; i += 5) {
      ctx.strokeStyle = 'rgba(255,255,255,0.16)';
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, size);
      ctx.stroke();

      ctx.strokeStyle = 'rgba(0,0,0,0.14)';
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(size, i);
      ctx.stroke();
    }
  } else if (mode === 'leather') {
    for (let i = 0; i < 900; i++) {
      ctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.15)' : 'rgba(0,0,0,0.16)';
      ctx.beginPath();
      ctx.arc(Math.random() * size, Math.random() * size, 1.3 + Math.random() * 2.3, 0, Math.PI * 2);
      ctx.fill();
    }
  } else if (mode === 'skin') {
    for (let i = 0; i < 1600; i++) {
      ctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.055)' : 'rgba(0,0,0,0.055)';
      ctx.fillRect(Math.random() * size, Math.random() * size, 1.2, 1.2);
    }
  } else if (mode === 'hair' || mode === 'wood') {
    const count = mode === 'hair' ? 750 : 420;
    for (let i = 0; i < count; i++) {
      const x = Math.random() * size;
      ctx.strokeStyle = i % 2 === 0 ? 'rgba(255,255,255,0.22)' : 'rgba(0,0,0,0.22)';
      ctx.lineWidth = mode === 'hair' ? 1.2 : 1.6;
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.bezierCurveTo(x + 5, size * 0.33, x - 5, size * 0.66, x, size);
      ctx.stroke();
    }
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.anisotropy = maxAnisotropy;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(2, 2);
  return tex;
}

function createIrisTexture(
  outerHex: string,
  innerHex: string,
  collaretteHex: string,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const size = 256;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const cx = size / 2;
  const cy = size / 2;
  const r = size * 0.45;

  // Clean off-white sclera margin around the iris limbal ring so white sclera frames the eye cleanly
  ctx.fillStyle = '#ede7df';
  ctx.fillRect(0, 0, size, size);

  // Dark limbal outer ring
  ctx.fillStyle = '#090e18';
  ctx.beginPath();
  ctx.arc(cx, cy, r, 0, Math.PI * 2);
  ctx.fill();

  const grad = ctx.createRadialGradient(cx, cy, r * 0.22, cx, cy, r * 0.94);
  grad.addColorStop(0, collaretteHex);
  grad.addColorStop(0.42, innerHex);
  grad.addColorStop(0.84, outerHex);
  grad.addColorStop(1, '#0b111c');
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, r * 0.94, 0, Math.PI * 2);
  ctx.fill();

  // Crisp radial iris stromal fibers
  for (let i = 0; i < 84; i++) {
    const ang = (i / 84) * Math.PI * 2;
    ctx.strokeStyle = i % 3 === 0 ? 'rgba(255,255,255,0.32)' : 'rgba(0,0,0,0.24)';
    ctx.lineWidth = 1.4;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(ang) * r * 0.34, cy + Math.sin(ang) * r * 0.34);
    ctx.lineTo(cx + Math.cos(ang) * r * 0.88, cy + Math.sin(ang) * r * 0.88);
    ctx.stroke();
  }

  // Deep black pupil
  ctx.fillStyle = '#040508';
  ctx.beginPath();
  ctx.arc(cx, cy, r * 0.36, 0, Math.PI * 2);
  ctx.fill();

  // Crisp primary & secondary cornea-like catchlights
  ctx.fillStyle = 'rgba(255, 255, 255, 0.94)';
  ctx.beginPath();
  ctx.arc(cx - r * 0.17, cy - r * 0.19, r * 0.115, 0, Math.PI * 2);
  ctx.fill();

  ctx.fillStyle = 'rgba(255, 255, 255, 0.52)';
  ctx.beginPath();
  ctx.arc(cx + r * 0.14, cy + r * 0.15, r * 0.05, 0, Math.PI * 2);
  ctx.fill();

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

type SkinArchetype = 'king' | 'queen' | 'warrior' | 'mage' | 'young';

function createFaceSkinMaps(
  baseHex: string,
  blushHex: string,
  shadowHex: string,
  highlightHex: string,
  archetype: SkinArchetype,
  maxAnisotropy: number
): {
  map: THREE.CanvasTexture;
  normalMap: THREE.CanvasTexture;
  roughnessMap: THREE.CanvasTexture;
} {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  const hCanvas = document.createElement('canvas');
  hCanvas.width = size;
  hCanvas.height = size;
  const hCtx = hCanvas.getContext('2d')!;

  const rCanvas = document.createElement('canvas');
  rCanvas.width = size;
  rCanvas.height = size;
  const rCtx = rCanvas.getContext('2d')!;

  const isFemale = archetype === 'queen';
  const isMature = archetype === 'king' || archetype === 'mage';
  const isRugged = archetype === 'warrior';

  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, size, size);
  hCtx.fillStyle = '#808080';
  hCtx.fillRect(0, 0, size, size);
  // Matte non-plastic cheek/jaw base roughness (~0.62)
  rCtx.fillStyle = '#9f9f9f';
  rCtx.fillRect(0, 0, size, size);

  const fx = size * 0.25;
  const fy = size * 0.5;

  // Forehead & nose bridge natural warm specular highlight + satin T-zone (~0.43)
  const noseHi = ctx.createRadialGradient(fx, fy - 4, 2, fx, fy - 4, 38);
  noseHi.addColorStop(0, highlightHex);
  noseHi.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.globalAlpha = 0.34;
  ctx.fillStyle = noseHi;
  ctx.fillRect(0, 0, size, size);

  const tZoneR = rCtx.createRadialGradient(fx, fy - 12, 4, fx, fy - 12, 46);
  tZoneR.addColorStop(0, '#6e6e6e');
  tZoneR.addColorStop(1, 'rgba(159,159,159,0)');
  rCtx.fillStyle = tZoneR;
  rCtx.fillRect(0, 0, size, size);

  // Forehead expression creases (stronger on mature king/mage, faint on young/queen)
  hCtx.strokeStyle = isMature ? 'rgba(32,32,32,0.34)' : 'rgba(40,40,40,0.14)';
  hCtx.lineWidth = isMature ? 2.4 : 1.5;
  for (const row of [-58, -48]) {
    hCtx.beginPath();
    hCtx.moveTo(fx - 34, fy + row);
    hCtx.quadraticCurveTo(fx, fy + row - 3, fx + 34, fy + row);
    hCtx.stroke();
  }

  for (const side of [-1, 1]) {
    const ex = fx + side * 26;
    const ey = fy - 12;

    // Orbital ambient shadow + crease
    const socket = ctx.createRadialGradient(ex, ey, 2, ex, ey, 24);
    socket.addColorStop(0, shadowHex);
    socket.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.globalAlpha = isFemale ? 0.28 : 0.42;
    ctx.fillStyle = socket;
    ctx.fillRect(0, 0, size, size);

    // Upper eyelid crease fold
    hCtx.strokeStyle = 'rgba(20,20,20,0.36)';
    hCtx.lineWidth = 2.2;
    hCtx.beginPath();
    hCtx.arc(ex, ey + 2, 13, Math.PI * 1.15, Math.PI * 1.85);
    hCtx.stroke();

    // Crow's-feet expression lines for mature king & mage
    if (isMature) {
      hCtx.strokeStyle = 'rgba(30,30,30,0.28)';
      hCtx.lineWidth = 1.4;
      for (const a of [-0.25, 0.15]) {
        hCtx.beginPath();
        hCtx.moveTo(ex + side * 14, ey);
        hCtx.lineTo(ex + side * 23, ey + a * 18);
        hCtx.stroke();
      }
    }

    // Sub-orbital & cheekbone warm flush
    const cx = fx + side * 34;
    const cy = fy + 24;
    const cheek = ctx.createRadialGradient(cx, cy, 4, cx, cy, 34);
    cheek.addColorStop(0, blushHex);
    cheek.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.globalAlpha = isFemale ? 0.36 : 0.26;
    ctx.fillStyle = cheek;
    ctx.fillRect(0, 0, size, size);

    // Nasolabial fold beside nostrils
    ctx.strokeStyle = shadowHex;
    ctx.globalAlpha = isFemale ? 0.1 : isMature ? 0.28 : 0.18;
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.moveTo(fx + side * 12, fy + 16);
    ctx.quadraticCurveTo(fx + side * 24, fy + 34, fx + side * 22, fy + 50);
    ctx.stroke();

    hCtx.strokeStyle = 'rgba(30,30,30,0.28)';
    hCtx.lineWidth = 2.4;
    hCtx.beginPath();
    hCtx.moveTo(fx + side * 12, fy + 16);
    hCtx.quadraticCurveTo(fx + side * 24, fy + 34, fx + side * 22, fy + 50);
    hCtx.stroke();
  }

  // Subtle weathered battle scar on rugged warrior (Rook / Knight) cheek
  if (isRugged) {
    ctx.strokeStyle = blushHex;
    ctx.globalAlpha = 0.42;
    ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(fx - 34, fy - 4);
    ctx.lineTo(fx - 22, fy + 26);
    ctx.stroke();

    hCtx.strokeStyle = '#383838';
    hCtx.lineWidth = 2.6;
    hCtx.beginPath();
    hCtx.moveTo(fx - 34, fy - 4);
    hCtx.lineTo(fx - 22, fy + 26);
    hCtx.stroke();
  }

  // Subtle 5-o'clock jaw stubble for rugged warrior & young soldier
  if (archetype === 'warrior' || archetype === 'young') {
    const stubble = ctx.createRadialGradient(fx, fy + 62, 12, fx, fy + 62, 58);
    stubble.addColorStop(0, shadowHex);
    stubble.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.globalAlpha = archetype === 'warrior' ? 0.28 : 0.14;
    ctx.fillStyle = stubble;
    ctx.fillRect(0, 0, size, size);
  }

  // Under-jaw & neck ambient shadow
  const jawShadow = ctx.createRadialGradient(fx, fy + 88, 10, fx, fy + 88, 68);
  jawShadow.addColorStop(0, shadowHex);
  jawShadow.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.globalAlpha = 0.34;
  ctx.fillStyle = jawShadow;
  ctx.fillRect(0, 0, size, size);

  // Fine organic skin pores & micro-tone variation
  for (let i = 0; i < 2600; i++) {
    const px = fx + (Math.random() - 0.5) * 210;
    const py = fy + (Math.random() - 0.5) * 220;
    ctx.globalAlpha = 0.045;
    ctx.fillStyle = i % 2 === 0 ? shadowHex : highlightHex;
    ctx.fillRect(px, py, 1.3, 1.3);

    hCtx.fillStyle = i % 2 === 0 ? 'rgba(65,65,65,0.24)' : 'rgba(185,185,185,0.16)';
    hCtx.fillRect(px, py, 1.2, 1.2);
  }
  ctx.globalAlpha = 1;

  const map = new THREE.CanvasTexture(canvas);
  map.colorSpace = THREE.SRGBColorSpace;
  map.anisotropy = maxAnisotropy;

  const normalMap = createNormalMapFromHeightCanvas(hCanvas, 1.4, maxAnisotropy, 1);

  const roughnessMap = new THREE.CanvasTexture(rCanvas);
  roughnessMap.anisotropy = maxAnisotropy;

  return { map, normalMap, roughnessMap };
}

function createBodySkinTexture(
  baseHex: string,
  shadowHex: string,
  highlightHex: string,
  maxAnisotropy: number
): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = baseHex;
  ctx.fillRect(0, 0, size, size);

  // Subtle muscular highlight & anatomical ambient occlusion bands along torso UV (u=0.25 front, 0.75 back)
  const fx = size * 0.25;
  const pecHi = ctx.createRadialGradient(fx, size * 0.34, 8, fx, size * 0.34, 72);
  pecHi.addColorStop(0, highlightHex);
  pecHi.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.globalAlpha = 0.28;
  ctx.fillStyle = pecHi;
  ctx.fillRect(0, 0, size, size);

  // Center sternum / linea alba soft muscle shadow
  ctx.strokeStyle = shadowHex;
  ctx.globalAlpha = 0.26;
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.moveTo(fx, size * 0.22);
  ctx.lineTo(fx, size * 0.78);
  ctx.stroke();

  // Horizontal pectoral underline & abdominal definition
  for (const yFrac of [0.42, 0.54, 0.65, 0.76]) {
    ctx.globalAlpha = yFrac === 0.42 ? 0.32 : 0.18;
    ctx.lineWidth = yFrac === 0.42 ? 5 : 3.5;
    ctx.beginPath();
    ctx.moveTo(fx - 46, size * yFrac);
    ctx.quadraticCurveTo(fx, size * (yFrac + 0.02), fx + 46, size * yFrac);
    ctx.stroke();
  }

  // Natural skin grain
  ctx.globalAlpha = 0.045;
  for (let i = 0; i < 2000; i++) {
    ctx.fillStyle = i % 2 === 0 ? shadowHex : highlightHex;
    ctx.fillRect(Math.random() * size, Math.random() * size, 1.5, 1.5);
  }
  ctx.globalAlpha = 1;

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

function createHorseCoatTexture(isWhite: boolean, maxAnisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.fillStyle = isWhite ? '#784e34' : '#1b1d24';
  ctx.fillRect(0, 0, size, size);

  // Muscular coat sheen & subtle dapple variations
  for (let i = 0; i < 160; i++) {
    const cx = Math.random() * size;
    const cy = Math.random() * size;
    const r = 10 + Math.random() * 24;
    const g = ctx.createRadialGradient(cx, cy, 2, cx, cy, r);
    if (isWhite) {
      g.addColorStop(0, 'rgba(164, 114, 78, 0.24)');
      g.addColorStop(1, 'rgba(64, 38, 22, 0.0)');
    } else {
      g.addColorStop(0, 'rgba(58, 66, 82, 0.26)');
      g.addColorStop(1, 'rgba(12, 14, 18, 0.0)');
    }
    ctx.fillStyle = g;
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Fine directional equine hair sheen strokes
  for (let i = 0; i < 2200; i++) {
    const x = Math.random() * size;
    const y = Math.random() * size;
    ctx.strokeStyle = isWhite ? 'rgba(255,235,215,0.12)' : 'rgba(125,135,155,0.09)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.lineTo(x + 9, y + 2);
    ctx.stroke();
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  return tex;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(size / 2, size / 2, 4, size / 2, size / 2, size / 2);
  grad.addColorStop(0, 'rgba(0, 0, 0, 0.62)');
  grad.addColorStop(0.55, 'rgba(0, 0, 0, 0.28)');
  grad.addColorStop(1, 'rgba(0, 0, 0, 0.0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

function createEmberTexture(): THREE.CanvasTexture {
  const size = 64;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grad.addColorStop(0, 'rgba(255, 252, 224, 0.95)');
  grad.addColorStop(0.4, 'rgba(245, 224, 150, 0.55)');
  grad.addColorStop(1, 'rgba(245, 224, 150, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, size, size);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  return tex;
}

/**
 * Engraved Dark Stone Coordinate Letters / Numbers matching the sandstone apron in the photo
 */
function createCoordinateTexture(label: string, maxAnisotropy: number): THREE.CanvasTexture {
  const size = 128;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;

  ctx.clearRect(0, 0, size, size);
  ctx.font = '700 72px Cinzel, Georgia, serif';
  ctx.textAlign = 'center';
  ctx.textBaseline = 'middle';

  // Subtle carved bevel highlight below, pale engraved ivory recess on top for dark granite stone
  ctx.fillStyle = 'rgba(8, 12, 20, 0.85)';
  ctx.fillText(label, size / 2 + 1.5, size / 2 + 3.5);
  ctx.fillStyle = 'rgba(222, 210, 184, 0.9)';
  ctx.fillText(label, size / 2, size / 2 + 1);

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.anisotropy = maxAnisotropy;
  return tex;
}

export function createSceneMaterialBank(renderer: THREE.WebGLRenderer): SceneMaterialBank {
  const maxAniso = renderer.capabilities.getMaxAnisotropy();
  const disposables: Array<{ dispose: () => void }> = [];
  const track = <T extends { dispose: () => void }>(item: T): T => {
    disposables.push(item);
    return item;
  };

  const lightMarbleTex = track(createMarbleTexture('#d2c9b8', '#a89f8e', '#eae3d5', maxAniso));
  const darkObsidianTex = track(createMarbleTexture('#1a202b', '#0d1118', '#2f3848', maxAniso));
  const citadelStoneMaps = createDarkCitadelStoneMaps(maxAniso, 5);
  track(citadelStoneMaps.map);
  track(citadelStoneMaps.normalMap);

  const ruinStoneMaps = createDarkCitadelStoneMaps(maxAniso, 2);
  track(ruinStoneMaps.map);
  track(ruinStoneMaps.normalMap);

  const whiteLeatherMaps = createLeatherMaps('#5e3a22', '#422614', '#8f6b47', maxAniso);
  track(whiteLeatherMaps.map);
  track(whiteLeatherMaps.normalMap);

  const blackLeatherMaps = createLeatherMaps('#251c19', '#140f0d', '#543c2c', maxAniso);
  track(blackLeatherMaps.map);
  track(blackLeatherMaps.normalMap);

  const waterNormalMap = track(createWaterRippleNormalMap(maxAniso));
  const contactTex = track(createContactShadowTexture());
  const emberTexture = track(createEmberTexture());

  const whiteArmorMaps = createArmorTextureMaps('#e2e7ef', '#a3b3c7', maxAniso);
  track(whiteArmorMaps.map);
  track(whiteArmorMaps.normalMap);
  track(whiteArmorMaps.roughnessMap);

  const blackArmorMaps = createArmorTextureMaps('#282d38', '#4f5a70', maxAniso);
  track(blackArmorMaps.map);
  track(blackArmorMaps.normalMap);
  track(blackArmorMaps.roughnessMap);

  const goldArmorMaps = createArmorTextureMaps('#ecc45d', '#a87d24', maxAniso);
  track(goldArmorMaps.map);
  track(goldArmorMaps.normalMap);
  track(goldArmorMaps.roughnessMap);

  const bronzeArmorMaps = createArmorTextureMaps('#a8743f', '#5a391c', maxAniso);
  track(bronzeArmorMaps.map);
  track(bronzeArmorMaps.normalMap);
  track(bronzeArmorMaps.roughnessMap);

  const whiteMailMaps = createChainmailMaps('#b4bec9', '#454e5c', maxAniso);
  track(whiteMailMaps.map);
  track(whiteMailMaps.normalMap);

  const blackMailMaps = createChainmailMaps('#464e5c', '#14171f', maxAniso);
  track(blackMailMaps.map);
  track(blackMailMaps.normalMap);

  // White Kingdom uses Radiant Ivory-White & Gold-Trimmed Robes/Capes/Tabards
  const whiteCapeMaps = createRoyalClothMaps('#ede8dc', '#d6cbb5', '#d9b14c', maxAniso);
  track(whiteCapeMaps.map);
  track(whiteCapeMaps.normalMap);

  // Black Kingdom uses Charcoal-Black & Crimson/Bronze-Trimmed Robes/Capes/Tabards
  const blackCapeMaps = createRoyalClothMaps('#1d1e24', '#38303b', '#9c6e3b', maxAniso);
  track(blackCapeMaps.map);
  track(blackCapeMaps.normalMap);

  // Queen Plum-Violet & Midnight Damask Royal Silk Maps
  const whiteQueenMaps = createRoyalClothMaps('#5b2868', '#8e4ea3', '#e0b854', maxAniso);
  track(whiteQueenMaps.map);
  track(whiteQueenMaps.normalMap);

  const blackQueenMaps = createRoyalClothMaps('#281230', '#631d3a', '#b58146', maxAniso);
  track(blackQueenMaps.map);
  track(blackQueenMaps.normalMap);

  // King Royal Crimson Fleur-de-lis Tabards & Scout Coats
  const whiteKingTabardTex = track(createFleurTabardTexture('#8c161e', '#f2ece1', '#e0b854', maxAniso));
  const blackKingTabardTex = track(createFleurTabardTexture('#3a0d14', '#d49d56', '#9e6e36', maxAniso));
  const whiteScoutCoatTex = track(createScoutCoatMaps('#eae5db', '#9e1c24', maxAniso));
  const blackScoutCoatTex = track(createScoutCoatMaps('#1d1f26', '#8a1824', maxAniso));

  const whiteShieldTex = track(createShieldFaceTexture(true, maxAniso));
  const blackShieldTex = track(createShieldFaceTexture(false, maxAniso));

  const clothBump = track(createProceduralBumpTexture('cloth', maxAniso));
  const skinBump = track(createProceduralBumpTexture('skin', maxAniso));
  const hairBump = track(createProceduralBumpTexture('hair', maxAniso));
  const woodBump = track(createProceduralBumpTexture('wood', maxAniso));

  // Distinct per-archetype facial skin textures (King, Queen, Warrior/Rook/Knight, Mage/Bishop, Young/Pawn)
  const whiteKingSkin = createFaceSkinMaps('#e3b192', '#d27c68', '#996751', '#f7d5bc', 'king', maxAniso);
  track(whiteKingSkin.map);
  track(whiteKingSkin.normalMap);
  track(whiteKingSkin.roughnessMap);

  const whiteQueenSkin = createFaceSkinMaps('#f1c5ac', '#db8377', '#aa7767', '#fde2cf', 'queen', maxAniso);
  track(whiteQueenSkin.map);
  track(whiteQueenSkin.normalMap);
  track(whiteQueenSkin.roughnessMap);

  const whiteWarriorSkin = createFaceSkinMaps('#dca688', '#c86f5b', '#8e5c48', '#f0c7ad', 'warrior', maxAniso);
  track(whiteWarriorSkin.map);
  track(whiteWarriorSkin.normalMap);
  track(whiteWarriorSkin.roughnessMap);

  const whiteMageSkin = createFaceSkinMaps('#e8baa0', '#cf8272', '#9c6f5e', '#fae0cc', 'mage', maxAniso);
  track(whiteMageSkin.map);
  track(whiteMageSkin.normalMap);
  track(whiteMageSkin.roughnessMap);

  const whiteYoungSkin = createFaceSkinMaps('#ecc0a4', '#df8b7b', '#a87864', '#fce2ce', 'young', maxAniso);
  track(whiteYoungSkin.map);
  track(whiteYoungSkin.normalMap);
  track(whiteYoungSkin.roughnessMap);

  const blackKingSkin = createFaceSkinMaps('#c8967b', '#a05e54', '#6b4339', '#dcb096', 'king', maxAniso);
  track(blackKingSkin.map);
  track(blackKingSkin.normalMap);
  track(blackKingSkin.roughnessMap);

  const blackQueenSkin = createFaceSkinMaps('#d3a38b', '#ae6460', '#794a44', '#e5bda4', 'queen', maxAniso);
  track(blackQueenSkin.map);
  track(blackQueenSkin.normalMap);
  track(blackQueenSkin.roughnessMap);

  const blackWarriorSkin = createFaceSkinMaps('#be8b70', '#96564c', '#613c33', '#d4a68d', 'warrior', maxAniso);
  track(blackWarriorSkin.map);
  track(blackWarriorSkin.normalMap);
  track(blackWarriorSkin.roughnessMap);

  const blackMageSkin = createFaceSkinMaps('#cca088', '#a46960', '#6e4941', '#e0baa2', 'mage', maxAniso);
  track(blackMageSkin.map);
  track(blackMageSkin.normalMap);
  track(blackMageSkin.roughnessMap);

  const blackYoungSkin = createFaceSkinMaps('#d2a186', '#ad6a5f', '#754b42', '#e4b9a0', 'young', maxAniso);
  track(blackYoungSkin.map);
  track(blackYoungSkin.normalMap);
  track(blackYoungSkin.roughnessMap);

  const whiteBodySkinTex = track(createBodySkinTexture('#e3b293', '#9d6a52', '#f7d3b8', maxAniso));
  const blackBodySkinTex = track(createBodySkinTexture('#c59277', '#6a4238', '#dab096', maxAniso));

  const whiteIrisTex = track(createIrisTexture('#255ea3', '#5baef5', '#c8e4ff', maxAniso));
  const blackIrisTex = track(createIrisTexture('#8a1d26', '#d94534', '#ffb184', maxAniso));

  const whiteHorseTex = track(createHorseCoatTexture(true, maxAniso));
  const blackHorseTex = track(createHorseCoatTexture(false, maxAniso));

  const files = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H'].map((l) =>
    track(createCoordinateTexture(l, maxAniso))
  );
  const ranks = ['1', '2', '3', '4', '5', '6', '7', '8'].map((l) =>
    track(createCoordinateTexture(l, maxAniso))
  );

  const white: KingdomMaterials = {
    armorPrimary: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteArmorMaps.map,
        normalMap: whiteArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.55, 0.55),
        roughnessMap: whiteArmorMaps.roughnessMap,
        metalness: 0.9,
        roughness: 0.65,
        clearcoat: 0.25,
        clearcoatRoughness: 0.24,
        envMapIntensity: 1.4,
      })
    ),
    armorDarkSteel: track(
      new THREE.MeshPhysicalMaterial({
        map: blackArmorMaps.map,
        normalMap: blackArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.55, 0.55),
        roughnessMap: blackArmorMaps.roughnessMap,
        color: 0x5c6472,
        metalness: 0.9,
        roughness: 0.68,
        clearcoat: 0.22,
        envMapIntensity: 1.38,
      })
    ),
    armorSecondary: track(
      new THREE.MeshStandardMaterial({
        color: 0xaab6c4,
        normalMap: whiteArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.4, 0.4),
        metalness: 0.84,
        roughness: 0.32,
      })
    ),
    armorTrim: track(
      new THREE.MeshPhysicalMaterial({
        map: goldArmorMaps.map,
        normalMap: goldArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        roughnessMap: goldArmorMaps.roughnessMap,
        metalness: 0.95,
        roughness: 0.56,
        clearcoat: 0.42,
        envMapIntensity: 1.45,
      })
    ),
    chainmail: track(
      new THREE.MeshStandardMaterial({
        map: whiteMailMaps.map,
        normalMap: whiteMailMaps.normalMap,
        normalScale: new THREE.Vector2(0.95, 0.95),
        metalness: 0.85,
        roughness: 0.38,
      })
    ),
    cloth: track(
      new THREE.MeshPhysicalMaterial({
        color: 0xf0ebe0,
        metalness: 0.02,
        roughness: 0.85,
        sheen: 0.55,
        sheenRoughness: 0.65,
        bumpMap: clothBump,
        bumpScale: 0.012,
      })
    ),
    tabard: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteCapeMaps.map,
        normalMap: whiteCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        metalness: 0.02,
        roughness: 0.82,
        sheen: 0.55,
        sheenColor: new THREE.Color(0xfff5d9),
      })
    ),
    royalTabard: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteKingTabardTex,
        normalMap: whiteCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        metalness: 0.05,
        roughness: 0.72,
        sheen: 0.75,
        sheenColor: new THREE.Color(0xd93b48),
        side: THREE.DoubleSide,
      })
    ),
    pawnCoat: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteScoutCoatTex,
        normalMap: whiteCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.35, 0.35),
        metalness: 0.02,
        roughness: 0.78,
        sheen: 0.55,
        sheenColor: new THREE.Color(0xfff5e8),
        side: THREE.DoubleSide,
      })
    ),
    crimsonAccent: track(
      new THREE.MeshPhysicalMaterial({
        color: 0x941922,
        normalMap: whiteCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        metalness: 0.04,
        roughness: 0.74,
        sheen: 0.82,
        sheenColor: new THREE.Color(0xe64c5a),
        side: THREE.DoubleSide,
      })
    ),
    cape: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteCapeMaps.map,
        normalMap: whiteCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.55, 0.55),
        metalness: 0.03,
        roughness: 0.8,
        sheen: 0.72,
        sheenColor: new THREE.Color(0xfff7e2),
        side: THREE.DoubleSide,
      })
    ),
    gown: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteCapeMaps.map,
        normalMap: whiteCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        metalness: 0.04,
        roughness: 0.72,
        sheen: 0.85,
        sheenColor: new THREE.Color(0xffffff),
        side: THREE.DoubleSide,
      })
    ),
    queenGown: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteQueenMaps.map,
        normalMap: whiteQueenMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        metalness: 0.1,
        roughness: 0.56,
        sheen: 0.9,
        sheenColor: new THREE.Color(0xc982e8),
        side: THREE.DoubleSide,
      })
    ),
    crownVelvet: track(
      new THREE.MeshPhysicalMaterial({
        color: 0x8b1e2d,
        roughness: 0.92,
        metalness: 0.02,
        sheen: 0.85,
        sheenColor: new THREE.Color(0xd9596b),
      })
    ),
    furTrim: track(
      new THREE.MeshStandardMaterial({
        color: 0xf2ece2,
        roughness: 0.94,
        metalness: 0.0,
        bumpMap: hairBump,
        bumpScale: 0.022,
      })
    ),
    shieldFace: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteShieldTex,
        normalMap: whiteArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.3, 0.3),
        metalness: 0.25,
        roughness: 0.45,
        clearcoat: 0.25,
      })
    ),
    skin: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteKingSkin.map,
        normalMap: whiteKingSkin.normalMap,
        normalScale: new THREE.Vector2(0.32, 0.32),
        roughnessMap: whiteKingSkin.roughnessMap,
        metalness: 0.0,
        roughness: 1.0,
        clearcoat: 0.03,
        clearcoatRoughness: 0.65,
        sheen: 0.24,
        sheenRoughness: 0.72,
        sheenColor: new THREE.Color(0xffaa94),
      })
    ),
    skinFemale: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteQueenSkin.map,
        normalMap: whiteQueenSkin.normalMap,
        normalScale: new THREE.Vector2(0.24, 0.24),
        roughnessMap: whiteQueenSkin.roughnessMap,
        metalness: 0.0,
        roughness: 0.96,
        clearcoat: 0.04,
        clearcoatRoughness: 0.6,
        sheen: 0.28,
        sheenRoughness: 0.68,
        sheenColor: new THREE.Color(0xffb8aa),
      })
    ),
    skinWarrior: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteWarriorSkin.map,
        normalMap: whiteWarriorSkin.normalMap,
        normalScale: new THREE.Vector2(0.36, 0.36),
        roughnessMap: whiteWarriorSkin.roughnessMap,
        metalness: 0.0,
        roughness: 1.0,
        clearcoat: 0.03,
        clearcoatRoughness: 0.68,
        sheen: 0.22,
        sheenRoughness: 0.74,
        sheenColor: new THREE.Color(0xf7a28c),
      })
    ),
    skinMage: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteMageSkin.map,
        normalMap: whiteMageSkin.normalMap,
        normalScale: new THREE.Vector2(0.34, 0.34),
        roughnessMap: whiteMageSkin.roughnessMap,
        metalness: 0.0,
        roughness: 1.0,
        clearcoat: 0.03,
        clearcoatRoughness: 0.65,
        sheen: 0.24,
        sheenRoughness: 0.7,
        sheenColor: new THREE.Color(0xffb29e),
      })
    ),
    skinYoung: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteYoungSkin.map,
        normalMap: whiteYoungSkin.normalMap,
        normalScale: new THREE.Vector2(0.26, 0.26),
        roughnessMap: whiteYoungSkin.roughnessMap,
        metalness: 0.0,
        roughness: 0.98,
        clearcoat: 0.04,
        clearcoatRoughness: 0.62,
        sheen: 0.26,
        sheenRoughness: 0.68,
        sheenColor: new THREE.Color(0xffb8a4),
      })
    ),
    skinBody: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteBodySkinTex,
        bumpMap: skinBump,
        bumpScale: 0.003,
        metalness: 0.0,
        roughness: 0.6,
        clearcoat: 0.04,
        clearcoatRoughness: 0.65,
        sheen: 0.24,
        sheenColor: new THREE.Color(0xffad96),
      })
    ),
    lips: track(
      new THREE.MeshStandardMaterial({
        color: 0xb25f58,
        roughness: 0.42,
        metalness: 0.0,
      })
    ),
    sclera: track(
      new THREE.MeshPhysicalMaterial({
        color: 0xede7df,
        roughness: 0.14,
        metalness: 0.0,
        clearcoat: 0.95,
      })
    ),
    iris: track(
      new THREE.MeshStandardMaterial({
        map: whiteIrisTex,
        roughness: 0.16,
        metalness: 0.04,
      })
    ),
    cornea: track(
      new THREE.MeshPhysicalMaterial({
        color: 0xffffff,
        roughness: 0.03,
        metalness: 0.0,
        transparent: true,
        opacity: 0.2,
        clearcoat: 1.0,
        clearcoatRoughness: 0.03,
        envMapIntensity: 1.8,
        depthWrite: false,
      })
    ),
    lashLine: track(
      new THREE.MeshStandardMaterial({
        color: 0x201512,
        roughness: 0.72,
        metalness: 0.0,
      })
    ),
    eyebrow: track(
      new THREE.MeshStandardMaterial({
        color: 0x4a301e,
        roughness: 0.78,
        metalness: 0.0,
        bumpMap: hairBump,
        bumpScale: 0.012,
      })
    ),
    leather: track(
      new THREE.MeshStandardMaterial({
        map: whiteLeatherMaps.map,
        normalMap: whiteLeatherMaps.normalMap,
        normalScale: new THREE.Vector2(0.75, 0.75),
        metalness: 0.04,
        roughness: 0.64,
      })
    ),
    trousers: track(
      new THREE.MeshStandardMaterial({
        color: 0x28262b,
        metalness: 0.02,
        roughness: 0.84,
        bumpMap: clothBump,
        bumpScale: 0.012,
      })
    ),
    wood: track(
      new THREE.MeshStandardMaterial({
        color: 0x6b4628,
        metalness: 0.02,
        roughness: 0.74,
        bumpMap: woodBump,
        bumpScale: 0.016,
      })
    ),
    weaponBlade: track(
      new THREE.MeshPhysicalMaterial({
        color: 0xf2f7fc,
        normalMap: whiteArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.2, 0.2),
        metalness: 0.97,
        roughness: 0.14,
        anisotropy: 0.82,
        clearcoat: 0.25,
        envMapIntensity: 1.5,
      })
    ),
    gem: track(
      new THREE.MeshStandardMaterial({
        color: 0x54adff,
        emissive: 0x1c6ee8,
        emissiveIntensity: 1.35,
        metalness: 0.15,
        roughness: 0.12,
      })
    ),
    horseCoat: track(
      new THREE.MeshStandardMaterial({
        map: whiteHorseTex,
        metalness: 0.04,
        roughness: 0.54,
        bumpMap: hairBump,
        bumpScale: 0.005,
      })
    ),
    horseMane: track(
      new THREE.MeshStandardMaterial({
        color: 0xd4cab8,
        metalness: 0.02,
        roughness: 0.8,
        bumpMap: hairBump,
        bumpScale: 0.016,
      })
    ),
    horseCaparison: track(
      new THREE.MeshPhysicalMaterial({
        map: whiteCapeMaps.map,
        normalMap: whiteCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.5, 0.5),
        roughness: 0.78,
        sheen: 0.7,
        sheenColor: new THREE.Color(0xfff5d9),
        side: THREE.DoubleSide,
      })
    ),
    hair: track(
      new THREE.MeshStandardMaterial({
        color: 0x624028,
        metalness: 0.04,
        roughness: 0.6,
        bumpMap: hairBump,
        bumpScale: 0.016,
      })
    ),
    hairAuburn: track(
      new THREE.MeshStandardMaterial({
        color: 0x7d2f1e,
        metalness: 0.05,
        roughness: 0.52,
        bumpMap: hairBump,
        bumpScale: 0.016,
      })
    ),
    hairSilver: track(
      new THREE.MeshStandardMaterial({
        color: 0xd6d2ca,
        metalness: 0.06,
        roughness: 0.55,
        bumpMap: hairBump,
        bumpScale: 0.016,
      })
    ),
  };

  const black: KingdomMaterials = {
    armorPrimary: track(
      new THREE.MeshPhysicalMaterial({
        map: blackArmorMaps.map,
        normalMap: blackArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.55, 0.55),
        roughnessMap: blackArmorMaps.roughnessMap,
        metalness: 0.88,
        roughness: 0.72,
        clearcoat: 0.24,
        clearcoatRoughness: 0.26,
        envMapIntensity: 1.32,
      })
    ),
    armorDarkSteel: track(
      new THREE.MeshPhysicalMaterial({
        map: blackArmorMaps.map,
        normalMap: blackArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.55, 0.55),
        roughnessMap: blackArmorMaps.roughnessMap,
        color: 0x1c1f28,
        metalness: 0.9,
        roughness: 0.68,
        clearcoat: 0.24,
        envMapIntensity: 1.32,
      })
    ),
    armorSecondary: track(
      new THREE.MeshStandardMaterial({
        color: 0x161920,
        normalMap: blackArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.4, 0.4),
        metalness: 0.82,
        roughness: 0.34,
      })
    ),
    armorTrim: track(
      new THREE.MeshPhysicalMaterial({
        map: bronzeArmorMaps.map,
        normalMap: bronzeArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        roughnessMap: bronzeArmorMaps.roughnessMap,
        metalness: 0.94,
        roughness: 0.6,
        clearcoat: 0.28,
        envMapIntensity: 1.35,
      })
    ),
    chainmail: track(
      new THREE.MeshStandardMaterial({
        map: blackMailMaps.map,
        normalMap: blackMailMaps.normalMap,
        normalScale: new THREE.Vector2(0.95, 0.95),
        metalness: 0.84,
        roughness: 0.42,
      })
    ),
    cloth: track(
      new THREE.MeshPhysicalMaterial({
        color: 0x1f1d24,
        metalness: 0.03,
        roughness: 0.86,
        sheen: 0.45,
        bumpMap: clothBump,
        bumpScale: 0.012,
      })
    ),
    tabard: track(
      new THREE.MeshPhysicalMaterial({
        map: blackCapeMaps.map,
        normalMap: blackCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        metalness: 0.03,
        roughness: 0.84,
        sheen: 0.45,
        sheenColor: new THREE.Color(0x8c2a34),
      })
    ),
    royalTabard: track(
      new THREE.MeshPhysicalMaterial({
        map: blackKingTabardTex,
        normalMap: blackCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        metalness: 0.06,
        roughness: 0.74,
        sheen: 0.7,
        sheenColor: new THREE.Color(0x9e2533),
        side: THREE.DoubleSide,
      })
    ),
    pawnCoat: track(
      new THREE.MeshPhysicalMaterial({
        map: blackScoutCoatTex,
        normalMap: blackCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.35, 0.35),
        metalness: 0.04,
        roughness: 0.78,
        sheen: 0.45,
        sheenColor: new THREE.Color(0x70212b),
        side: THREE.DoubleSide,
      })
    ),
    crimsonAccent: track(
      new THREE.MeshPhysicalMaterial({
        color: 0x5c1119,
        normalMap: blackCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        metalness: 0.05,
        roughness: 0.76,
        sheen: 0.72,
        sheenColor: new THREE.Color(0xa62634),
        side: THREE.DoubleSide,
      })
    ),
    cape: track(
      new THREE.MeshPhysicalMaterial({
        map: blackCapeMaps.map,
        normalMap: blackCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.55, 0.55),
        metalness: 0.04,
        roughness: 0.8,
        sheen: 0.65,
        sheenColor: new THREE.Color(0x9e2a36),
        side: THREE.DoubleSide,
      })
    ),
    gown: track(
      new THREE.MeshPhysicalMaterial({
        map: blackCapeMaps.map,
        normalMap: blackCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        metalness: 0.06,
        roughness: 0.72,
        sheen: 0.7,
        sheenColor: new THREE.Color(0xb07246),
        side: THREE.DoubleSide,
      })
    ),
    queenGown: track(
      new THREE.MeshPhysicalMaterial({
        map: blackQueenMaps.map,
        normalMap: blackQueenMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        metalness: 0.12,
        roughness: 0.58,
        sheen: 0.85,
        sheenColor: new THREE.Color(0x9c2848),
        side: THREE.DoubleSide,
      })
    ),
    crownVelvet: track(
      new THREE.MeshPhysicalMaterial({
        color: 0x3b0d17,
        roughness: 0.92,
        metalness: 0.02,
        sheen: 0.75,
        sheenColor: new THREE.Color(0x962133),
      })
    ),
    furTrim: track(
      new THREE.MeshStandardMaterial({
        color: 0x262228,
        roughness: 0.94,
        metalness: 0.0,
        bumpMap: hairBump,
        bumpScale: 0.022,
      })
    ),
    shieldFace: track(
      new THREE.MeshPhysicalMaterial({
        map: blackShieldTex,
        normalMap: blackArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.3, 0.3),
        metalness: 0.32,
        roughness: 0.48,
        clearcoat: 0.22,
      })
    ),
    skin: track(
      new THREE.MeshPhysicalMaterial({
        map: blackKingSkin.map,
        normalMap: blackKingSkin.normalMap,
        normalScale: new THREE.Vector2(0.32, 0.32),
        roughnessMap: blackKingSkin.roughnessMap,
        metalness: 0.0,
        roughness: 1.0,
        clearcoat: 0.03,
        clearcoatRoughness: 0.65,
        sheen: 0.22,
        sheenRoughness: 0.72,
        sheenColor: new THREE.Color(0xd99280),
      })
    ),
    skinFemale: track(
      new THREE.MeshPhysicalMaterial({
        map: blackQueenSkin.map,
        normalMap: blackQueenSkin.normalMap,
        normalScale: new THREE.Vector2(0.24, 0.24),
        roughnessMap: blackQueenSkin.roughnessMap,
        metalness: 0.0,
        roughness: 0.96,
        clearcoat: 0.04,
        clearcoatRoughness: 0.6,
        sheen: 0.25,
        sheenRoughness: 0.68,
        sheenColor: new THREE.Color(0xe39e90),
      })
    ),
    skinWarrior: track(
      new THREE.MeshPhysicalMaterial({
        map: blackWarriorSkin.map,
        normalMap: blackWarriorSkin.normalMap,
        normalScale: new THREE.Vector2(0.36, 0.36),
        roughnessMap: blackWarriorSkin.roughnessMap,
        metalness: 0.0,
        roughness: 1.0,
        clearcoat: 0.03,
        clearcoatRoughness: 0.68,
        sheen: 0.2,
        sheenRoughness: 0.74,
        sheenColor: new THREE.Color(0xd08876),
      })
    ),
    skinMage: track(
      new THREE.MeshPhysicalMaterial({
        map: blackMageSkin.map,
        normalMap: blackMageSkin.normalMap,
        normalScale: new THREE.Vector2(0.34, 0.34),
        roughnessMap: blackMageSkin.roughnessMap,
        metalness: 0.0,
        roughness: 1.0,
        clearcoat: 0.03,
        clearcoatRoughness: 0.65,
        sheen: 0.22,
        sheenRoughness: 0.7,
        sheenColor: new THREE.Color(0xdc9888),
      })
    ),
    skinYoung: track(
      new THREE.MeshPhysicalMaterial({
        map: blackYoungSkin.map,
        normalMap: blackYoungSkin.normalMap,
        normalScale: new THREE.Vector2(0.26, 0.26),
        roughnessMap: blackYoungSkin.roughnessMap,
        metalness: 0.0,
        roughness: 0.98,
        clearcoat: 0.04,
        clearcoatRoughness: 0.62,
        sheen: 0.24,
        sheenRoughness: 0.68,
        sheenColor: new THREE.Color(0xe09c8a),
      })
    ),
    skinBody: track(
      new THREE.MeshPhysicalMaterial({
        map: blackBodySkinTex,
        bumpMap: skinBump,
        bumpScale: 0.003,
        metalness: 0.0,
        roughness: 0.62,
        clearcoat: 0.04,
        clearcoatRoughness: 0.66,
        sheen: 0.22,
        sheenColor: new THREE.Color(0xd99280),
      })
    ),
    lips: track(
      new THREE.MeshStandardMaterial({
        color: 0x8f464a,
        roughness: 0.44,
        metalness: 0.0,
      })
    ),
    sclera: track(
      new THREE.MeshPhysicalMaterial({
        color: 0xe8e0d8,
        roughness: 0.14,
        metalness: 0.0,
        clearcoat: 0.95,
      })
    ),
    iris: track(
      new THREE.MeshStandardMaterial({
        map: blackIrisTex,
        roughness: 0.16,
        metalness: 0.05,
      })
    ),
    cornea: track(
      new THREE.MeshPhysicalMaterial({
        color: 0xffffff,
        roughness: 0.03,
        metalness: 0.0,
        transparent: true,
        opacity: 0.2,
        clearcoat: 1.0,
        clearcoatRoughness: 0.03,
        envMapIntensity: 1.8,
        depthWrite: false,
      })
    ),
    lashLine: track(
      new THREE.MeshStandardMaterial({
        color: 0x120d10,
        roughness: 0.72,
        metalness: 0.0,
      })
    ),
    eyebrow: track(
      new THREE.MeshStandardMaterial({
        color: 0x19151b,
        roughness: 0.78,
        metalness: 0.0,
        bumpMap: hairBump,
        bumpScale: 0.012,
      })
    ),
    leather: track(
      new THREE.MeshStandardMaterial({
        map: blackLeatherMaps.map,
        normalMap: blackLeatherMaps.normalMap,
        normalScale: new THREE.Vector2(0.75, 0.75),
        metalness: 0.04,
        roughness: 0.68,
      })
    ),
    trousers: track(
      new THREE.MeshStandardMaterial({
        color: 0x151418,
        metalness: 0.02,
        roughness: 0.86,
        bumpMap: clothBump,
        bumpScale: 0.012,
      })
    ),
    wood: track(
      new THREE.MeshStandardMaterial({
        color: 0x2d1f19,
        metalness: 0.03,
        roughness: 0.78,
        bumpMap: woodBump,
        bumpScale: 0.016,
      })
    ),
    weaponBlade: track(
      new THREE.MeshPhysicalMaterial({
        color: 0xa4adba,
        normalMap: blackArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.2, 0.2),
        metalness: 0.96,
        roughness: 0.17,
        anisotropy: 0.8,
        clearcoat: 0.22,
        envMapIntensity: 1.4,
      })
    ),
    gem: track(
      new THREE.MeshStandardMaterial({
        color: 0xff4048,
        emissive: 0xc41828,
        emissiveIntensity: 1.35,
        metalness: 0.15,
        roughness: 0.14,
      })
    ),
    horseCoat: track(
      new THREE.MeshStandardMaterial({
        map: blackHorseTex,
        metalness: 0.06,
        roughness: 0.52,
        bumpMap: hairBump,
        bumpScale: 0.005,
      })
    ),
    horseMane: track(
      new THREE.MeshStandardMaterial({
        color: 0x3b181d,
        metalness: 0.04,
        roughness: 0.78,
        bumpMap: hairBump,
        bumpScale: 0.016,
      })
    ),
    horseCaparison: track(
      new THREE.MeshPhysicalMaterial({
        map: blackCapeMaps.map,
        normalMap: blackCapeMaps.normalMap,
        normalScale: new THREE.Vector2(0.5, 0.5),
        roughness: 0.78,
        sheen: 0.65,
        sheenColor: new THREE.Color(0xc93b49),
        side: THREE.DoubleSide,
      })
    ),
    hair: track(
      new THREE.MeshStandardMaterial({
        color: 0x1a171f,
        metalness: 0.04,
        roughness: 0.62,
        bumpMap: hairBump,
        bumpScale: 0.016,
      })
    ),
    hairAuburn: track(
      new THREE.MeshStandardMaterial({
        color: 0x26181c,
        metalness: 0.05,
        roughness: 0.55,
        bumpMap: hairBump,
        bumpScale: 0.016,
      })
    ),
    hairSilver: track(
      new THREE.MeshStandardMaterial({
        color: 0x525764,
        metalness: 0.06,
        roughness: 0.58,
        bumpMap: hairBump,
        bumpScale: 0.016,
      })
    ),
  };

  return {
    white,
    black,
    lightTile: track(
      new THREE.MeshStandardMaterial({
        map: lightMarbleTex,
        roughness: 0.34,
        metalness: 0.04,
      })
    ),
    darkTile: track(
      new THREE.MeshStandardMaterial({
        map: darkObsidianTex,
        roughness: 0.4,
        metalness: 0.1,
      })
    ),
    stoneApron: track(
      new THREE.MeshStandardMaterial({
        map: citadelStoneMaps.map,
        normalMap: citadelStoneMaps.normalMap,
        normalScale: new THREE.Vector2(0.7, 0.7),
        roughness: 0.74,
        metalness: 0.08,
      })
    ),
    boardFrame: track(
      new THREE.MeshStandardMaterial({
        map: citadelStoneMaps.map,
        normalMap: citadelStoneMaps.normalMap,
        normalScale: new THREE.Vector2(0.75, 0.75),
        color: 0x8e98ab,
        roughness: 0.78,
        metalness: 0.1,
      })
    ),
    boardGoldTrim: track(
      new THREE.MeshPhysicalMaterial({
        color: 0xb8965c,
        metalness: 0.72,
        roughness: 0.34,
        clearcoat: 0.2,
      })
    ),
    waterMoat: track(
      new THREE.MeshPhysicalMaterial({
        color: 0x0c1d2b,
        normalMap: waterNormalMap,
        normalScale: new THREE.Vector2(0.36, 0.36),
        roughness: 0.09,
        metalness: 0.18,
        clearcoat: 1.0,
        clearcoatRoughness: 0.05,
        envMapIntensity: 1.6,
      })
    ),
    waterNormalMap,
    citadelGround: track(
      new THREE.MeshStandardMaterial({
        color: 0x161c26,
        normalMap: ruinStoneMaps.normalMap,
        normalScale: new THREE.Vector2(0.45, 0.45),
        roughness: 0.92,
        metalness: 0.04,
      })
    ),
    ruinStone: track(
      new THREE.MeshStandardMaterial({
        map: ruinStoneMaps.map,
        normalMap: ruinStoneMaps.normalMap,
        normalScale: new THREE.Vector2(0.7, 0.7),
        color: 0x8f9ab0,
        roughness: 0.85,
        metalness: 0.06,
      })
    ),
    brazierIron: track(
      new THREE.MeshStandardMaterial({
        color: 0x20252f,
        normalMap: blackArmorMaps.normalMap,
        normalScale: new THREE.Vector2(0.5, 0.5),
        roughness: 0.56,
        metalness: 0.82,
      })
    ),
    brazierEmber: track(
      new THREE.MeshStandardMaterial({
        color: 0x3b1308,
        emissive: 0xff5a12,
        emissiveIntensity: 2.2,
        roughness: 0.85,
      })
    ),
    brazierFlame: track(
      new THREE.MeshBasicMaterial({
        color: 0xffa638,
        transparent: true,
        opacity: 0.88,
        blending: THREE.AdditiveBlending,
        depthWrite: false,
      })
    ),
    contactShadowMat: track(
      new THREE.MeshBasicMaterial({
        map: contactTex,
        transparent: true,
        opacity: 0.58,
        depthWrite: false,
      })
    ),
    emberTexture,
    coordTextures: { files, ranks },
    dispose: () => {
      for (const item of disposables) {
        item.dispose();
      }
    },
  };
}

export function getKingdomPalette(bank: SceneMaterialBank, color: PieceColor): KingdomMaterials {
  return color === 'w' ? bank.white : bank.black;
}
