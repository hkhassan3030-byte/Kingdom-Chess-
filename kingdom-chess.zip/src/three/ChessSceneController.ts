import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { createBattlefield, squareToWorld, type BattlefieldRefs } from './createBattlefield';
import {
  createCharacterGeometryBank,
  createCharacterPiece,
  type CharacterGeometryBank,
  type CharacterRig,
} from './createCharacterPieces';
import { CharacterGLTFProvider } from './characterAssetLoader';
import { createSceneMaterialBank, type SceneMaterialBank } from './materials';
import {
  CombatEffectsManager,
  getCombatDuration,
  shortestAngleLerp,
  updateCombatDuel,
  type CombatDuelContext,
  type CombatSoundCue,
} from './combatChoreography';
import type { BoardPiece, GraphicsQuality, MoveAnimationPayload, PieceColor } from '../types/chess';

const _v1 = new THREE.Vector3();
const _camGoalPos = new THREE.Vector3();
const _camGoalTarget = new THREE.Vector3();

interface ActiveMoveAnim {
  payload: MoveAnimationPayload;
  attacker: CharacterRig;
  defender: CharacterRig | null;
  rookRig: CharacterRig | null;
  fromPos: THREE.Vector3;
  toPos: THREE.Vector3;
  rookFromPos: THREE.Vector3;
  rookToPos: THREE.Vector3;
  elapsed: number;
  duration: number;
  isCapture: boolean;
  duelCtx: CombatDuelContext | null;
  savedCamPos: THREE.Vector3;
  savedTarget: THREE.Vector3;
  onComplete: () => void;
}

export class ChessSceneController {
  private container: HTMLElement;
  private renderer: THREE.WebGLRenderer;
  private scene: THREE.Scene;
  private camera: THREE.PerspectiveCamera;
  private controls: OrbitControls;
  private isSoftwareGl: boolean;
  private clock = new THREE.Clock();
  private frameId = 0;
  private disposed = false;

  private materials: SceneMaterialBank;
  private charGeos: CharacterGeometryBank;
  private gltfProvider = new CharacterGLTFProvider();
  private battlefield: BattlefieldRefs;
  private keyLight: THREE.DirectionalLight;

  private piecesGroup = new THREE.Group();
  private highlightsGroup = new THREE.Group();
  private effectsGroup = new THREE.Group();

  private pieceMap = new Map<string, CharacterRig>();
  private hitProxyToSquare = new Map<THREE.Object3D, string>();

  // Highlight meshes
  private selectedRing: THREE.Mesh;
  private checkRing: THREE.Mesh;
  private lastMoveMeshes: THREE.Mesh[] = [];
  private legalMoveMeshes: THREE.Mesh[] = [];
  private legalCaptureMeshes: THREE.Mesh[] = [];
  private sharedHighlightGeos: THREE.BufferGeometry[] = [];
  private sharedHighlightMats: THREE.Material[] = [];

  private activeAnim: ActiveMoveAnim | null = null;
  private combatEffects: CombatEffectsManager;

  // Smooth camera glide state
  private cameraGlide: {
    active: boolean;
    pos: THREE.Vector3;
    target: THREE.Vector3;
  } = {
    active: false,
    pos: new THREE.Vector3(),
    target: new THREE.Vector3(),
  };

  // Raycasting & touch disambiguation
  private raycaster = new THREE.Raycaster();
  private pointerNdc = new THREE.Vector2();
  private pointerDownInfo: { x: number; y: number; time: number; pointerId: number } | null = null;
  private activePointers = new Set<number>();

  private onSquareTapCallback: (square: string) => void;
  private onContextLostCallback?: () => void;
  private onContextRestoredCallback?: () => void;
  private onCombatSoundCallback?: (cue: CombatSoundCue) => void;

  private triggerCombatSound = (cue: CombatSoundCue) => {
    this.onCombatSoundCallback?.(cue);
  };

  constructor(
    container: HTMLElement,
    options: {
      onSquareTap: (square: string) => void;
      onCombatSound?: (cue: CombatSoundCue) => void;
      onContextLost?: () => void;
      onContextRestored?: () => void;
      initialSide?: PieceColor;
    }
  ) {
    this.container = container;
    this.onSquareTapCallback = options.onSquareTap;
    this.onCombatSoundCallback = options.onCombatSound;
    this.onContextLostCallback = options.onContextLost;
    this.onContextRestoredCallback = options.onContextRestored;

    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    this.renderer.setSize(width, height);
    this.renderer.domElement.style.display = 'block';
    this.renderer.domElement.style.width = '100%';
    this.renderer.domElement.style.height = '100%';
    this.renderer.domElement.className = 'touch-canvas';
    container.appendChild(this.renderer.domElement);

    // Dark Fantasy Citadel Twilight Sky & Horizon Mist
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x131a28);
    this.scene.fog = new THREE.FogExp2(0x161f2f, 0.0175);

    // Studio Environment Reflections tuned for dark fantasy contrast & metal sheen
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    this.scene.environmentIntensity = 0.65;
    pmremGenerator.dispose();

    // Camera
    this.camera = new THREE.PerspectiveCamera(44, width / height, 0.08, 120);
    const startSide = options.initialSide ?? 'w';
    const startZ = startSide === 'w' ? 10.6 : -10.6;
    this.camera.position.set(0, 9.2, startZ);

    // OrbitControls
    this.controls = new OrbitControls(this.camera, this.renderer.domElement);
    this.controls.target.set(0, 0.25, 0);
    this.controls.enableDamping = !this.isSoftwareGl;
    this.controls.dampingFactor = 0.07;
    this.controls.rotateSpeed = 0.85;
    this.controls.zoomSpeed = 0.95;
    this.controls.panSpeed = 0.7;
    this.controls.minDistance = 0.85;
    this.controls.maxDistance = 21.0;
    this.controls.minPolarAngle = 0.18;
    this.controls.maxPolarAngle = Math.PI / 2.12;
    this.controls.enablePan = true;

    this.controls.addEventListener('start', () => {
      // Cancel scripted glide immediately when user takes camera control
      this.cameraGlide.active = false;
    });

    // Cinematic Dark Fantasy Lighting: Cool Moonlight Key + Back Rim + Warm Front Face Fills
    const hemi = new THREE.HemisphereLight(0x6f8ec4, 0x29231f, 0.95);
    this.scene.add(hemi);

    this.keyLight = new THREE.DirectionalLight(0xb9d3ff, 1.95);
    this.keyLight.position.set(10.0, 14.5, 7.5);
    this.keyLight.castShadow = !this.isSoftwareGl;
    this.keyLight.shadow.mapSize.width = 2048;
    this.keyLight.shadow.mapSize.height = 2048;
    this.keyLight.shadow.camera.near = 2;
    this.keyLight.shadow.camera.far = 42;
    const d = 9.5;
    this.keyLight.shadow.camera.left = -d;
    this.keyLight.shadow.camera.right = d;
    this.keyLight.shadow.camera.top = d;
    this.keyLight.shadow.camera.bottom = -d;
    this.keyLight.shadow.bias = -0.0005;
    this.keyLight.shadow.normalBias = 0.02;
    this.scene.add(this.keyLight);

    const rimLight = new THREE.DirectionalLight(0x82b4ff, 1.15);
    rimLight.position.set(-8.0, 7.0, -9.0);
    this.scene.add(rimLight);

    // Warm torch-bounce front face fill lights from both kingdom sides so faces & eyes remain crisp and legible
    const faceFillSouth = new THREE.DirectionalLight(0xffe1c4, 0.85);
    faceFillSouth.position.set(-5.0, 5.2, 8.8);
    this.scene.add(faceFillSouth);

    const faceFillNorth = new THREE.DirectionalLight(0xffd7b5, 0.65);
    faceFillNorth.position.set(5.5, 4.8, -8.8);
    this.scene.add(faceFillNorth);

    // Build Battlefield, Material Bank, Character Geo Bank
    this.materials = createSceneMaterialBank(this.renderer);
    this.charGeos = createCharacterGeometryBank();
    this.battlefield = createBattlefield(this.materials);
    this.scene.add(this.battlefield.group);
    this.scene.add(this.highlightsGroup);
    this.scene.add(this.piecesGroup);
    this.scene.add(this.effectsGroup);
    this.combatEffects = new CombatEffectsManager(this.effectsGroup);

    // Highlight rings & discs
    const selGeo = new THREE.RingGeometry(0.38, 0.49, 28);
    const selMat = new THREE.MeshBasicMaterial({
      color: 0xf4c44e,
      transparent: true,
      opacity: 0.92,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.selectedRing = new THREE.Mesh(selGeo, selMat);
    this.selectedRing.rotation.x = -Math.PI / 2;
    this.selectedRing.position.y = 0.022;
    this.selectedRing.visible = false;
    this.highlightsGroup.add(this.selectedRing);

    const chkGeo = new THREE.RingGeometry(0.36, 0.52, 28);
    const chkMat = new THREE.MeshBasicMaterial({
      color: 0xef4444,
      transparent: true,
      opacity: 0.88,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.checkRing = new THREE.Mesh(chkGeo, chkMat);
    this.checkRing.rotation.x = -Math.PI / 2;
    this.checkRing.position.y = 0.024;
    this.checkRing.visible = false;
    this.highlightsGroup.add(this.checkRing);

    const lastMoveGeo = new THREE.PlaneGeometry(1.06, 1.06);
    const lastMoveMat = new THREE.MeshBasicMaterial({
      color: 0xd4a438,
      transparent: true,
      opacity: 0.24,
      depthWrite: false,
    });
    for (let i = 0; i < 2; i++) {
      const m = new THREE.Mesh(lastMoveGeo, lastMoveMat);
      m.rotation.x = -Math.PI / 2;
      m.position.y = 0.012;
      m.visible = false;
      this.highlightsGroup.add(m);
      this.lastMoveMeshes.push(m);
    }

    const legalMoveGeo = new THREE.CircleGeometry(0.2, 20);
    const legalMoveMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.72,
      depthWrite: false,
    });
    for (let i = 0; i < 32; i++) {
      const m = new THREE.Mesh(legalMoveGeo, legalMoveMat);
      m.rotation.x = -Math.PI / 2;
      m.position.y = 0.018;
      m.visible = false;
      this.highlightsGroup.add(m);
      this.legalMoveMeshes.push(m);
    }

    const legalCapGeo = new THREE.RingGeometry(0.35, 0.48, 24);
    const legalCapMat = new THREE.MeshBasicMaterial({
      color: 0xf97316,
      transparent: true,
      opacity: 0.88,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    for (let i = 0; i < 16; i++) {
      const m = new THREE.Mesh(legalCapGeo, legalCapMat);
      m.rotation.x = -Math.PI / 2;
      m.position.y = 0.02;
      m.visible = false;
      this.highlightsGroup.add(m);
      this.legalCaptureMeshes.push(m);
    }

    this.sharedHighlightGeos.push(selGeo, chkGeo, lastMoveGeo, legalMoveGeo, legalCapGeo);
    this.sharedHighlightMats.push(selMat, chkMat, lastMoveMat, legalMoveMat, legalCapMat);

    // Layer 1 raycasting
    this.raycaster.layers.set(1);

    if (!this.isSoftwareGl) {
      this.renderer.compile(this.scene, this.camera);
    }

    this.bindEvents();
    this.tick();
  }

  private bindEvents() {
    const dom = this.renderer.domElement;
    dom.addEventListener('pointerdown', this.handlePointerDown);
    dom.addEventListener('pointerup', this.handlePointerUp);
    dom.addEventListener('pointercancel', this.handlePointerCancel);
    dom.addEventListener('webglcontextlost', this.handleContextLost);
    dom.addEventListener('webglcontextrestored', this.handleContextRestored);
    window.addEventListener('resize', this.handleResize);
  }

  private handleContextLost = (e: Event) => {
    e.preventDefault();
    this.onContextLostCallback?.();
  };

  private handleContextRestored = () => {
    this.onContextRestoredCallback?.();
  };

  private handleResize = () => {
    if (this.disposed) return;
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
  };

  private handlePointerDown = (e: PointerEvent) => {
    this.activePointers.add(e.pointerId);
    if (this.activePointers.size === 1) {
      this.pointerDownInfo = {
        x: e.clientX,
        y: e.clientY,
        time: performance.now(),
        pointerId: e.pointerId,
      };
    } else {
      // Multi-touch pinch gesture -> cancel tap
      this.pointerDownInfo = null;
    }
  };

  private handlePointerCancel = (e: PointerEvent) => {
    this.activePointers.delete(e.pointerId);
    this.pointerDownInfo = null;
  };

  private handlePointerUp = (e: PointerEvent) => {
    this.activePointers.delete(e.pointerId);
    const down = this.pointerDownInfo;
    this.pointerDownInfo = null;
    if (!down || down.pointerId !== e.pointerId) return;

    const dx = e.clientX - down.x;
    const dy = e.clientY - down.y;
    const dist = Math.hypot(dx, dy);
    const dt = performance.now() - down.time;

    // Only treat as a tap if finger/mouse stayed within 11px and < 360ms
    if (dist > 11 || dt > 360) return;
    if (this.activeAnim) return; // Lock board clicks during active combat/move animation

    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointerNdc.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointerNdc.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    this.raycaster.setFromCamera(this.pointerNdc, this.camera);

    const targets: THREE.Object3D[] = [...this.battlefield.tileHitMeshes];
    this.hitProxyToSquare.forEach((_sq, proxy) => targets.push(proxy));

    const hits = this.raycaster.intersectObjects(targets, false);
    if (hits.length === 0) return;

    for (const hit of hits) {
      const pieceSq = this.hitProxyToSquare.get(hit.object);
      if (pieceSq) {
        this.onSquareTapCallback(pieceSq);
        return;
      }
      const tileSq = hit.object.userData.square as string | undefined;
      if (tileSq) {
        this.onSquareTapCallback(tileSq);
        return;
      }
    }
  };

  public setShowCoordinates(show: boolean) {
    this.battlefield.coordGroup.visible = show;
  }

  public setQuality(quality: GraphicsQuality) {
    if (this.isSoftwareGl) return;
    const enableShadows = quality === 'high';
    this.renderer.shadowMap.enabled = enableShadows;
    this.keyLight.castShadow = enableShadows;
    this.renderer.setPixelRatio(
      quality === 'high' ? Math.min(window.devicePixelRatio, 2) : Math.min(window.devicePixelRatio, 1.25)
    );
  }

  public resetCamera(side: PieceColor, immediate = false) {
    const aspect = (this.container.clientWidth || window.innerWidth) / (this.container.clientHeight || window.innerHeight);
    // Slightly pull back on narrow portrait mobile screens so the entire 8x8 battlefield fits cleanly!
    const mobileScale = aspect < 0.85 ? 1.32 : aspect < 1.1 ? 1.15 : 1.0;
    const z = (side === 'w' ? 10.6 : -10.6) * mobileScale;
    const y = 9.2 * mobileScale;

    if (immediate) {
      this.camera.position.set(0, y, z);
      this.controls.target.set(0, 0.25, 0);
      this.controls.update();
      this.cameraGlide.active = false;
    } else {
      this.cameraGlide.pos.set(0, y, z);
      this.cameraGlide.target.set(0, 0.25, 0);
      this.cameraGlide.active = true;
    }
  }

  public adjustZoom(factor: number) {
    this.cameraGlide.active = false;
    _v1.copy(this.camera.position).sub(this.controls.target);
    const dist = _v1.length();
    const newDist = THREE.MathUtils.clamp(dist * factor, this.controls.minDistance, this.controls.maxDistance);
    _v1.setLength(newDist).add(this.controls.target);
    _v1.y = Math.max(0.28, _v1.y);
    this.camera.position.copy(_v1);
    this.controls.update();
  }

  public focusCharacter(square: string) {
    const rig = this.pieceMap.get(square);
    if (!rig) return;
    squareToWorld(square, _v1);
    const faceDir = rig.color === 'w' ? -1 : 1; // White faces -Z, Black faces +Z
    const focusY =
      rig.type === 'k'
        ? 1.36
        : rig.type === 'q'
        ? 1.28
        : rig.type === 'p'
        ? 1.08
        : 1.24;
    this.cameraGlide.target.set(_v1.x, focusY, _v1.z);
    this.cameraGlide.pos.set(_v1.x + 0.36, focusY + 0.14, _v1.z + faceDir * 1.12);
    this.cameraGlide.active = true;
  }

  public updateHighlights(params: {
    selectedSquare: string | null;
    legalTargets: Array<{ square: string; isCapture: boolean }>;
    lastMove: { from: string; to: string } | null;
    checkSquare: string | null;
  }) {
    if (params.selectedSquare) {
      squareToWorld(params.selectedSquare, _v1);
      this.selectedRing.position.set(_v1.x, 0.022, _v1.z);
      this.selectedRing.visible = true;
    } else {
      this.selectedRing.visible = false;
    }

    if (params.checkSquare) {
      squareToWorld(params.checkSquare, _v1);
      this.checkRing.position.set(_v1.x, 0.024, _v1.z);
      this.checkRing.visible = true;
    } else {
      this.checkRing.visible = false;
    }

    if (params.lastMove) {
      squareToWorld(params.lastMove.from, _v1);
      this.lastMoveMeshes[0].position.set(_v1.x, 0.012, _v1.z);
      this.lastMoveMeshes[0].visible = true;
      squareToWorld(params.lastMove.to, _v1);
      this.lastMoveMeshes[1].position.set(_v1.x, 0.012, _v1.z);
      this.lastMoveMeshes[1].visible = true;
    } else {
      this.lastMoveMeshes.forEach((m) => (m.visible = false));
    }

    let quietIdx = 0;
    let capIdx = 0;
    for (const target of params.legalTargets) {
      squareToWorld(target.square, _v1);
      if (target.isCapture) {
        if (capIdx < this.legalCaptureMeshes.length) {
          const m = this.legalCaptureMeshes[capIdx++];
          m.position.set(_v1.x, 0.02, _v1.z);
          m.visible = true;
        }
      } else {
        if (quietIdx < this.legalMoveMeshes.length) {
          const m = this.legalMoveMeshes[quietIdx++];
          m.position.set(_v1.x, 0.018, _v1.z);
          m.visible = true;
        }
      }
    }
    for (let i = quietIdx; i < this.legalMoveMeshes.length; i++) {
      this.legalMoveMeshes[i].visible = false;
    }
    for (let i = capIdx; i < this.legalCaptureMeshes.length; i++) {
      this.legalCaptureMeshes[i].visible = false;
    }
  }

  public syncBoard(pieces: BoardPiece[]) {
    // Clear existing pieces cleanly
    this.pieceMap.forEach((rig) => {
      this.piecesGroup.remove(rig.root);
      (rig.hitProxy.material as THREE.Material).dispose();
    });
    this.pieceMap.clear();
    this.hitProxyToSquare.clear();

    for (const p of pieces) {
      const rig = createCharacterPiece(
        p.type,
        p.color,
        this.charGeos,
        this.materials,
        Math.random() * Math.PI * 2
      );
      squareToWorld(p.square, _v1);
      rig.root.position.copy(_v1);
      this.piecesGroup.add(rig.root);
      this.pieceMap.set(p.square, rig);
      this.hitProxyToSquare.set(rig.hitProxy, p.square);

      // Optional GLTF/GLB override if external model URL is registered
      if (this.gltfProvider.hasModel(p.color, p.type)) {
        void this.gltfProvider.loadCharacterModel(p.color, p.type).then((gltf) => {
          if (!gltf || this.disposed) return;
          if (this.pieceMap.get(p.square) !== rig) return;
          const clone = gltf.scene.clone();
          rig.body.clear();
          rig.body.add(clone);
        });
      }
    }
  }

  public playMoveAnimation(payload: MoveAnimationPayload, onComplete: () => void) {
    const attacker = this.pieceMap.get(payload.from);
    if (!attacker) {
      onComplete();
      return;
    }

    const capturedSq = payload.capturedSquare ?? payload.to;
    const defender = payload.captured ? this.pieceMap.get(capturedSq) ?? null : null;
    const rookRig = payload.rookFrom ? this.pieceMap.get(payload.rookFrom) ?? null : null;

    const fromPos = squareToWorld(payload.from, new THREE.Vector3());
    const toPos = squareToWorld(payload.to, new THREE.Vector3());

    const dir = toPos.clone().sub(fromPos);
    const dist = dir.length();
    const normDir = dist > 0.001 ? dir.clone().normalize() : new THREE.Vector3(0, 0, 1);
    const duelSpot = toPos
      .clone()
      .sub(normDir.clone().multiplyScalar(Math.min(0.96, dist * 0.72)));

    const rookFromPos = payload.rookFrom ? squareToWorld(payload.rookFrom, new THREE.Vector3()) : new THREE.Vector3();
    const rookToPos = payload.rookTo ? squareToWorld(payload.rookTo, new THREE.Vector3()) : new THREE.Vector3();

    const isCapture = Boolean(defender);
    const midpoint = fromPos.clone().lerp(toPos, 0.72);
    const sidePerp = new THREE.Vector3(-normDir.z, 0, normDir.x);
    const camToMid = this.camera.position.clone().sub(midpoint);
    if (sidePerp.dot(camToMid) < 0) sidePerp.negate();

    const savedCamPos = this.camera.position.clone();
    const savedTarget = this.controls.target.clone();
    const travelAngle = Math.atan2(toPos.x - fromPos.x, toPos.z - fromPos.z);
    const homeAngle = payload.color === 'w' ? Math.PI : 0;

    const duelCtx: CombatDuelContext | null =
      isCapture && defender
        ? {
            payload,
            attacker,
            defender,
            fromPos,
            toPos,
            duelSpot,
            normDir,
            sidePerp,
            travelAngle,
            homeAngle,
            firedCues: new Set<string>(),
            shakeIntensity: 0,
            savedCamPos,
            savedTarget,
          }
        : null;

    this.cameraGlide.active = false;

    this.activeAnim = {
      payload,
      attacker,
      defender,
      rookRig,
      fromPos,
      toPos,
      rookFromPos,
      rookToPos,
      elapsed: 0,
      duration: isCapture ? getCombatDuration(payload.piece) : 0.46,
      isCapture,
      duelCtx,
      savedCamPos,
      savedTarget,
      onComplete,
    };
  }

  private updateIdleCharacters(elapsed: number) {
    this.pieceMap.forEach((rig) => {
      if (this.activeAnim && (this.activeAnim.attacker === rig || this.activeAnim.defender === rig)) {
        return;
      }
      const t = elapsed * 2.1 + rig.phaseOffset;
      // Subtle breathing bob using each piece's calibrated torsoBaseY
      rig.torso.position.y = rig.torsoBaseY + Math.sin(t) * 0.01;
      rig.head.rotation.y = Math.sin(t * 0.55) * 0.08;
      if (rig.cape) {
        rig.cape.rotation.x = 0.16 + Math.sin(t * 1.2) * 0.04;
        rig.cape.rotation.z = Math.sin(t * 0.95) * 0.025;
      }
      if (rig.crystal) {
        rig.crystal.rotation.y = elapsed * 1.4 + rig.phaseOffset;
        rig.crystal.position.y = (rig.type === 'q' ? 0.8 : 0.82) + Math.sin(t * 1.4) * 0.025;
      }
      if (rig.horse) {
        rig.horse.neck.rotation.x = Math.sin(t * 0.8) * 0.045;
        rig.horse.tail.rotation.z = Math.sin(t * 1.3) * 0.08;
      }
    });
  }

  private updateActiveAnimation(dt: number) {
    const anim = this.activeAnim;
    if (!anim) return;

    anim.elapsed += dt;
    const p = Math.min(anim.elapsed / anim.duration, 1);

    const { attacker, defender, rookRig, payload } = anim;
    const dx = anim.toPos.x - anim.fromPos.x;
    const dz = anim.toPos.z - anim.fromPos.z;
    const travelAngle = Math.atan2(dx, dz);
    const homeAngle = payload.color === 'w' ? Math.PI : 0;

    if (!anim.isCapture) {
      // Smooth movement animation
      const ease = 1 - Math.pow(1 - p, 3);
      attacker.root.position.lerpVectors(anim.fromPos, anim.toPos, ease);

      // Knights leap gracefully; foot units stride
      if (attacker.type === 'n') {
        attacker.root.position.y = Math.sin(p * Math.PI) * 0.85;
        if (attacker.horse) {
          attacker.horse.legs.forEach((leg, idx) => {
            leg.rotation.x = Math.sin(p * Math.PI * 3 + (idx < 2 ? 0 : Math.PI)) * 0.55;
          });
        }
      } else {
        attacker.root.position.y = Math.sin(p * Math.PI) * 0.18;
        attacker.legs.forEach((leg, idx) => {
          leg.rotation.x = Math.sin(p * Math.PI * 4 + idx * Math.PI) * 0.45;
        });
      }

      if (p < 0.78) {
        attacker.body.rotation.y = shortestAngleLerp(attacker.body.rotation.y, travelAngle, 0.25);
      } else {
        attacker.body.rotation.y = shortestAngleLerp(attacker.body.rotation.y, homeAngle, 0.25);
      }

      if (rookRig) {
        rookRig.root.position.lerpVectors(anim.rookFromPos, anim.rookToPos, ease);
        rookRig.root.position.y = Math.sin(p * Math.PI) * 0.15;
      }
    } else if (anim.duelCtx) {
      updateCombatDuel(
        anim.duelCtx,
        p,
        dt,
        this.combatEffects,
        this.camera,
        this.controls.target,
        this.triggerCombatSound
      );
    }

    if (p >= 1) {
      // Reset attacker pose cleanly
      attacker.root.position.copy(anim.toPos);
      attacker.root.position.y = 0;
      attacker.body.position.y = attacker.baseY;
      attacker.body.rotation.set(0, homeAngle, 0);
      attacker.torso.rotation.set(0, 0, 0);
      attacker.rightArm.rotation.set(-0.28, 0, -0.12);
      attacker.leftArm.rotation.set(-0.25, 0, 0.12);
      attacker.legs.forEach((l) => (l.rotation.x = 0));
      if (attacker.crystal) {
        attacker.crystal.scale.setScalar(0.92);
      }
      if (attacker.horse) {
        attacker.horse.legs.forEach((l) => (l.rotation.x = 0));
        attacker.horse.neck.rotation.x = 0;
      }

      if (defender && defender.root.parent) {
        this.piecesGroup.remove(defender.root);
      }

      if (anim.isCapture) {
        // Hand off smooth return glide to cameraGlide so it settles softly even after move completes
        this.cameraGlide.pos.copy(anim.savedCamPos);
        this.cameraGlide.target.copy(anim.savedTarget);
        this.cameraGlide.active = true;
      }

      const done = anim.onComplete;
      this.activeAnim = null;
      done();
    }
  }

  private updateEnvironment(elapsed: number, dt: number) {
    // Gentle moat water ripple drift
    this.materials.waterNormalMap.offset.x = (this.materials.waterNormalMap.offset.x + dt * 0.015) % 1;
    this.materials.waterNormalMap.offset.y = (this.materials.waterNormalMap.offset.y + dt * 0.01) % 1;

    // Flicker corner brazier flames (if present)
    this.battlefield.brazierFlames.forEach((flame, i) => {
      const f = 1 + Math.sin(elapsed * 9.5 + i * 1.7) * 0.14;
      flame.scale.set(0.9 * f, 1.35 * f, 0.9 * f);
      flame.rotation.y = elapsed * 1.8 + i;
    });
    this.battlefield.brazierLights.forEach((pt, i) => {
      pt.intensity = 1.5 + Math.sin(elapsed * 11 + i * 2.1) * 0.25;
    });

    // Subtle banner sway
    this.battlefield.banners.forEach((b, i) => {
      b.rotation.x = Math.sin(elapsed * 2.2 + i * 1.1) * 0.06;
    });

    // Ambient floating sunlit pollen motes
    const posAttr = this.battlefield.embers.geometry.getAttribute('position') as THREE.BufferAttribute;
    const arr = posAttr.array as Float32Array;
    const vels = this.battlefield.emberVelocities;
    for (let i = 0; i < arr.length; i += 3) {
      arr[i] += vels[i] * dt + Math.sin(elapsed + i) * 0.002;
      arr[i + 1] += vels[i + 1] * dt;
      arr[i + 2] += vels[i + 2] * dt;
      if (arr[i + 1] > 6.0) {
        arr[i] = (Math.random() - 0.5) * 16;
        arr[i + 1] = 0.2;
        arr[i + 2] = (Math.random() - 0.5) * 16;
      }
    }
    posAttr.needsUpdate = true;

    // Pulse check ring gently
    if (this.checkRing.visible) {
      const s = 1 + Math.sin(elapsed * 5.2) * 0.08;
      this.checkRing.scale.set(s, s, 1);
    }

    // Update combat weapon trails, sparks, shockwaves, and arcane projectiles
    this.combatEffects.update(dt);
  }

  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      if (this.disposed) {
        if (sync) gl.deleteSync(sync);
        return;
      }
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 5);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 80);
      }
    };
    this.frameId = window.setTimeout(poll, 5);
  }

  private tick = () => {
    if (this.disposed) return;

    const dt = Math.min(this.clock.getDelta(), 0.05);
    const elapsed = this.clock.elapsedTime;

    this.updateIdleCharacters(elapsed);
    this.updateActiveAnimation(dt);
    this.updateEnvironment(elapsed, dt);

    // Smooth camera preset / post-combat return glide
    if (this.cameraGlide.active && !this.activeAnim) {
      const alpha = 1 - Math.exp(-6.5 * dt);
      _camGoalPos.copy(this.cameraGlide.pos);
      _camGoalTarget.copy(this.cameraGlide.target);
      this.camera.position.lerp(_camGoalPos, alpha);
      this.controls.target.lerp(_camGoalTarget, alpha);
      if (
        this.camera.position.distanceToSquared(_camGoalPos) < 0.002 &&
        this.controls.target.distanceToSquared(_camGoalTarget) < 0.002
      ) {
        this.camera.position.copy(_camGoalPos);
        this.controls.target.copy(_camGoalTarget);
        this.cameraGlide.active = false;
      }
    }

    // Keep pan target within full chessboard bounds for corner close-up inspection
    this.controls.target.x = THREE.MathUtils.clamp(this.controls.target.x, -4.6, 4.6);
    this.controls.target.y = THREE.MathUtils.clamp(this.controls.target.y, -0.1, 2.5);
    this.controls.target.z = THREE.MathUtils.clamp(this.controls.target.z, -4.6, 4.6);
    this.controls.update();
    if (this.camera.position.y < 0.28) {
      this.camera.position.y = 0.28;
    }

    this.renderer.render(this.scene, this.camera);

    if (this.isSoftwareGl) {
      this.afterDraw(this.tick);
    } else {
      this.frameId = requestAnimationFrame(this.tick);
    }
  };

  public dispose() {
    this.disposed = true;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);

    const dom = this.renderer.domElement;
    dom.removeEventListener('pointerdown', this.handlePointerDown);
    dom.removeEventListener('pointerup', this.handlePointerUp);
    dom.removeEventListener('pointercancel', this.handlePointerCancel);
    dom.removeEventListener('webglcontextlost', this.handleContextLost);
    dom.removeEventListener('webglcontextrestored', this.handleContextRestored);
    window.removeEventListener('resize', this.handleResize);

    this.controls.dispose();
    this.pieceMap.forEach((rig) => {
      (rig.hitProxy.material as THREE.Material).dispose();
    });
    this.combatEffects.dispose();
    this.sharedHighlightGeos.forEach((g) => g.dispose());
    this.sharedHighlightMats.forEach((m) => m.dispose());
    this.battlefield.dispose();
    this.charGeos.dispose();
    this.gltfProvider.dispose();
    this.materials.dispose();
    this.renderer.dispose();

    if (dom.parentElement === this.container) {
      this.container.removeChild(dom);
    }
  }
}
