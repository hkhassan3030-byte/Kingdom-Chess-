import * as THREE from 'three';
import type { SceneMaterialBank } from './materials';

export const TILE_SIZE = 1.15;
export const BOARD_SPAN = TILE_SIZE * 8;

export interface BattlefieldRefs {
  group: THREE.Group;
  tileHitMeshes: THREE.Mesh[];
  coordGroup: THREE.Group;
  banners: THREE.Mesh[];
  brazierFlames: THREE.Mesh[];
  brazierLights: THREE.PointLight[];
  embers: THREE.Points;
  emberVelocities: Float32Array;
  dispose: () => void;
}

export function squareToWorld(square: string, target = new THREE.Vector3()): THREE.Vector3 {
  const file = square.charCodeAt(0) - 97; // 'a' = 0 .. 'h' = 7
  const rank = parseInt(square[1], 10) - 1; // '1' = 0 .. '8' = 7
  const x = (file - 3.5) * TILE_SIZE;
  const z = (3.5 - rank) * TILE_SIZE;
  return target.set(x, 0, z);
}

function createCornerBrazier(
  bank: SceneMaterialBank,
  trackGeo: <T extends THREE.BufferGeometry>(g: T) => T,
  brazierFlames: THREE.Mesh[],
  brazierLights: THREE.PointLight[],
  withPointLight: boolean
): THREE.Group {
  const brazier = new THREE.Group();

  // Carved octagon stone plinth & column
  const plinth = new THREE.Mesh(
    trackGeo(new THREE.CylinderGeometry(0.62, 0.76, 0.36, 8)),
    bank.ruinStone
  );
  plinth.position.y = 0.18;
  plinth.castShadow = true;
  plinth.receiveShadow = true;
  brazier.add(plinth);

  const shaft = new THREE.Mesh(
    trackGeo(new THREE.CylinderGeometry(0.36, 0.48, 0.72, 8)),
    bank.ruinStone
  );
  shaft.position.y = 0.72;
  shaft.castShadow = true;
  shaft.receiveShadow = true;
  brazier.add(shaft);

  // Forged iron fire bowl & rim
  const bowl = new THREE.Mesh(
    trackGeo(new THREE.CylinderGeometry(0.54, 0.28, 0.32, 10)),
    bank.brazierIron
  );
  bowl.position.y = 1.22;
  bowl.castShadow = true;
  bowl.receiveShadow = true;
  brazier.add(bowl);

  const rim = new THREE.Mesh(
    trackGeo(new THREE.TorusGeometry(0.52, 0.045, 6, 12)),
    bank.brazierIron
  );
  rim.rotation.x = Math.PI / 2;
  rim.position.y = 1.38;
  brazier.add(rim);

  // Glowing ember bed
  const emberBed = new THREE.Mesh(
    trackGeo(new THREE.SphereGeometry(0.42, 10, 6, 0, Math.PI * 2, 0, Math.PI * 0.5)),
    bank.brazierEmber
  );
  emberBed.scale.set(1, 0.45, 1);
  emberBed.position.y = 1.34;
  brazier.add(emberBed);

  // Flickering stylized multi-lobe flame
  const flame = new THREE.Mesh(
    trackGeo(new THREE.ConeGeometry(0.24, 0.65, 7)),
    bank.brazierFlame
  );
  flame.position.y = 1.62;
  brazier.add(flame);
  brazierFlames.push(flame);

  if (withPointLight) {
    const pt = new THREE.PointLight(0xff8b38, 1.8, 14, 2);
    pt.position.set(0, 1.78, 0);
    pt.castShadow = false;
    brazier.add(pt);
    brazierLights.push(pt);
  }

  return brazier;
}

export function createBattlefield(bank: SceneMaterialBank): BattlefieldRefs {
  const group = new THREE.Group();
  const geometries: THREE.BufferGeometry[] = [];
  const materials: THREE.Material[] = [];

  const trackGeo = <T extends THREE.BufferGeometry>(g: T): T => {
    geometries.push(g);
    return g;
  };
  const trackMat = <T extends THREE.Material>(m: T): T => {
    materials.push(m);
    return m;
  };

  // 1. Dark Citadel Basalt Arena Courtyard Floor & Stepped Outer Ring
  const groundGeo = trackGeo(new THREE.CylinderGeometry(68, 68, 1.6, 56));
  const ground = new THREE.Mesh(groundGeo, bank.citadelGround);
  ground.position.y = -1.25;
  ground.receiveShadow = true;
  group.add(ground);

  const daisRingGeo = trackGeo(new THREE.RingGeometry(8.5, 11.4, 48));
  const daisRing = new THREE.Mesh(daisRingGeo, bank.boardFrame);
  daisRing.rotation.x = -Math.PI / 2;
  daisRing.position.y = -0.44;
  daisRing.receiveShadow = true;
  group.add(daisRing);

  // 2. Moonlit Dark Reflecting Water Moat + Carved Basalt Retaining Curb
  const moatSize = BOARD_SPAN + 5.2;
  const waterGeo = trackGeo(new THREE.BoxGeometry(moatSize, 0.2, moatSize));
  const waterMesh = new THREE.Mesh(waterGeo, bank.waterMoat);
  waterMesh.position.y = -0.34;
  waterMesh.receiveShadow = true;
  group.add(waterMesh);

  const curbLen = moatSize + 0.72;
  const curbH = trackGeo(new THREE.BoxGeometry(curbLen, 0.38, 0.46));
  const curbV = trackGeo(new THREE.BoxGeometry(0.46, 0.38, curbLen));
  const curbDist = moatSize / 2 + 0.18;
  for (const s of [-1, 1]) {
    const ch = new THREE.Mesh(curbH, bank.boardFrame);
    ch.position.set(0, -0.3, s * curbDist);
    ch.receiveShadow = true;
    ch.castShadow = true;
    group.add(ch);

    const cv = new THREE.Mesh(curbV, bank.boardFrame);
    cv.position.set(s * curbDist, -0.3, 0);
    cv.receiveShadow = true;
    cv.castShadow = true;
    group.add(cv);
  }

  // 3. Carved Dark Granite Paver Apron with Recessed Corner Moat Bays
  const apronThick = 0.5;
  const apronSpan = BOARD_SPAN + 2.35;
  const apronBandW = BOARD_SPAN + 0.16;

  const apronNS = new THREE.Mesh(
    trackGeo(new THREE.BoxGeometry(apronBandW, apronThick, apronSpan)),
    bank.stoneApron
  );
  apronNS.position.y = -apronThick / 2 - 0.005;
  apronNS.receiveShadow = true;
  apronNS.castShadow = true;
  group.add(apronNS);

  const apronEW = new THREE.Mesh(
    trackGeo(new THREE.BoxGeometry(apronSpan, apronThick, apronBandW)),
    bank.stoneApron
  );
  apronEW.position.y = -apronThick / 2 - 0.005;
  apronEW.receiveShadow = true;
  apronEW.castShadow = true;
  group.add(apronEW);

  // Engraved metallic bronze-gold inner bevel trim framing the 8x8 stone chessboard
  const trimInner = BOARD_SPAN + 0.12;
  const trimBarHGeo = trackGeo(new THREE.BoxGeometry(trimInner, 0.025, 0.055));
  const trimBarVGeo = trackGeo(new THREE.BoxGeometry(0.055, 0.025, trimInner));
  for (const sign of [-1, 1]) {
    const hBar = new THREE.Mesh(trimBarHGeo, bank.boardGoldTrim);
    hBar.position.set(0, 0.002, sign * (BOARD_SPAN / 2 + 0.028));
    hBar.receiveShadow = true;
    group.add(hBar);

    const vBar = new THREE.Mesh(trimBarVGeo, bank.boardGoldTrim);
    vBar.position.set(sign * (BOARD_SPAN / 2 + 0.028), 0.002, 0);
    vBar.receiveShadow = true;
    group.add(vBar);
  }

  // 4. 64 High-Contrast Limestone & Obsidian Marble Tiles + Layer 1 Hit Planes
  const tileGeo = trackGeo(new THREE.BoxGeometry(TILE_SIZE - 0.014, 0.1, TILE_SIZE - 0.014));
  const hitGeo = trackGeo(new THREE.PlaneGeometry(TILE_SIZE, TILE_SIZE));
  const hitMat = trackMat(new THREE.MeshBasicMaterial({ visible: false }));
  const tileHitMeshes: THREE.Mesh[] = [];

  for (let rank = 0; rank < 8; rank++) {
    for (let file = 0; file < 8; file++) {
      const square = `${String.fromCharCode(97 + file)}${rank + 1}`;
      const isLight = (file + rank) % 2 === 1;
      const x = (file - 3.5) * TILE_SIZE;
      const z = (3.5 - rank) * TILE_SIZE;

      const tile = new THREE.Mesh(tileGeo, isLight ? bank.lightTile : bank.darkTile);
      tile.position.set(x, -0.05, z);
      tile.receiveShadow = true;
      group.add(tile);

      const hitPlane = new THREE.Mesh(hitGeo, hitMat);
      hitPlane.rotation.x = -Math.PI / 2;
      hitPlane.position.set(x, 0.005, z);
      hitPlane.layers.set(1);
      hitPlane.userData.square = square;
      group.add(hitPlane);
      tileHitMeshes.push(hitPlane);
    }
  }

  // 5. Pale Carved Stone Coordinates along Dark Granite Apron
  const coordGroup = new THREE.Group();
  const coordGeo = trackGeo(new THREE.PlaneGeometry(0.56, 0.56));
  const edgeOffset = BOARD_SPAN / 2 + 0.56;

  for (let i = 0; i < 8; i++) {
    const fileMat = trackMat(
      new THREE.MeshBasicMaterial({
        map: bank.coordTextures.files[i],
        transparent: true,
        depthWrite: false,
      })
    );
    const x = (i - 3.5) * TILE_SIZE;
    const southFile = new THREE.Mesh(coordGeo, fileMat);
    southFile.rotation.x = -Math.PI / 2;
    southFile.position.set(x, 0.014, edgeOffset);
    coordGroup.add(southFile);

    const northFile = new THREE.Mesh(coordGeo, fileMat);
    northFile.rotation.x = -Math.PI / 2;
    northFile.rotation.z = Math.PI;
    northFile.position.set(x, 0.014, -edgeOffset);
    coordGroup.add(northFile);

    const rankMat = trackMat(
      new THREE.MeshBasicMaterial({
        map: bank.coordTextures.ranks[i],
        transparent: true,
        depthWrite: false,
      })
    );
    const z = (3.5 - i) * TILE_SIZE;
    const westRank = new THREE.Mesh(coordGeo, rankMat);
    westRank.rotation.x = -Math.PI / 2;
    westRank.position.set(-edgeOffset, 0.014, z);
    coordGroup.add(westRank);

    const eastRank = new THREE.Mesh(coordGeo, rankMat);
    eastRank.rotation.x = -Math.PI / 2;
    eastRank.rotation.z = Math.PI;
    eastRank.position.set(edgeOffset, 0.014, z);
    coordGroup.add(eastRank);
  }
  group.add(coordGroup);

  // 6. Four Corner Carved Stone Braziers with Flickering Flames & Warm Torch PointLights
  const brazierFlames: THREE.Mesh[] = [];
  const brazierLights: THREE.PointLight[] = [];

  const brazierDist = moatSize / 2 + 0.92;
  const cornerCoords: Array<[number, number]> = [
    [-brazierDist, brazierDist],
    [brazierDist, brazierDist],
    [-brazierDist, -brazierDist],
    [brazierDist, -brazierDist],
  ];
  for (const [bx, bz] of cornerCoords) {
    const brazier = createCornerBrazier(bank, trackGeo, brazierFlames, brazierLights, true);
    brazier.position.set(bx, -0.44, bz);
    group.add(brazier);
  }

  // Four outer perimeter torch braziers (flames without extra PointLights for mobile GPU efficiency)
  const outerDist = moatSize / 2 + 4.4;
  const outerCoords: Array<[number, number]> = [
    [-outerDist * 0.65, -outerDist],
    [outerDist * 0.65, -outerDist],
    [-outerDist * 0.65, outerDist],
    [outerDist * 0.65, outerDist],
  ];
  for (const [ox, oz] of outerCoords) {
    const outerTorch = createCornerBrazier(bank, trackGeo, brazierFlames, brazierLights, false);
    outerTorch.position.set(ox, -0.44, oz);
    outerTorch.scale.set(0.85, 1.35, 0.85);
    group.add(outerTorch);
  }

  // 7. Instanced Ancient Ruined Gothic Pillars & Horizon Citadel Monoliths
  const pillarSpecs: Array<[number, number, number, number, number]> = [
    [-13.5, -13.5, 4.6, 1.0, 0.04],
    [-16.2, -6.2, 3.8, 0.9, -0.05],
    [-16.4, 5.8, 5.1, 1.05, 0.03],
    [-13.2, 13.8, 4.2, 0.95, -0.04],
    [13.6, -13.6, 4.9, 1.0, -0.03],
    [16.3, -5.6, 3.5, 0.88, 0.05],
    [16.1, 6.4, 4.7, 1.0, -0.02],
    [13.8, 13.4, 3.9, 0.92, 0.04],
    [-6.2, -16.8, 5.4, 1.1, 0.02],
    [6.4, -16.6, 4.3, 0.96, -0.03],
    [-6.4, 16.6, 4.8, 1.02, 0.03],
    [6.1, 16.9, 5.2, 1.08, -0.02],
  ];

  const colGeo = trackGeo(new THREE.CylinderGeometry(0.46, 0.56, 1.0, 8));
  const capGeo = trackGeo(new THREE.BoxGeometry(1.38, 0.34, 1.38));

  const colInst = new THREE.InstancedMesh(colGeo, bank.ruinStone, pillarSpecs.length);
  colInst.castShadow = true;
  colInst.receiveShadow = true;

  const capInst = new THREE.InstancedMesh(capGeo, bank.ruinStone, pillarSpecs.length);
  capInst.castShadow = true;
  capInst.receiveShadow = true;

  const dummy = new THREE.Object3D();
  pillarSpecs.forEach(([px, pz, h, rad, tilt], idx) => {
    dummy.position.set(px, -0.44 + h * 0.5, pz);
    dummy.rotation.set(tilt, idx * 0.65, -tilt * 0.7);
    dummy.scale.set(rad, h, rad);
    dummy.updateMatrix();
    colInst.setMatrixAt(idx, dummy.matrix);

    dummy.position.set(px, -0.44 + h + 0.14, pz);
    dummy.rotation.set(tilt * 1.4, idx * 0.65 + 0.35, -tilt);
    dummy.scale.set(rad, 1, rad);
    dummy.updateMatrix();
    capInst.setMatrixAt(idx, dummy.matrix);
  });
  colInst.instanceMatrix.needsUpdate = true;
  colInst.computeBoundingSphere();
  capInst.instanceMatrix.needsUpdate = true;
  capInst.computeBoundingSphere();
  group.add(colInst);
  group.add(capInst);

  // Outer jagged dark citadel mountain spires fading into misty horizon fog
  const spireGeo = trackGeo(new THREE.ConeGeometry(3.8, 13.5, 5));
  const spireCount = 16;
  const spireInst = new THREE.InstancedMesh(spireGeo, bank.citadelGround, spireCount);
  for (let i = 0; i < spireCount; i++) {
    const ang = (i / spireCount) * Math.PI * 2 + 0.18;
    const dist = 28 + (i % 3) * 5.5;
    const sx = Math.cos(ang) * dist;
    const sz = Math.sin(ang) * dist;
    const syScale = 0.75 + (i % 4) * 0.28;
    dummy.position.set(sx, -0.5 + 5.2 * syScale, sz);
    dummy.rotation.set(0, ang * 1.7, 0);
    dummy.scale.set(1.0 + (i % 2) * 0.45, syScale, 1.0 + ((i + 1) % 2) * 0.35);
    dummy.updateMatrix();
    spireInst.setMatrixAt(i, dummy.matrix);
  }
  spireInst.instanceMatrix.needsUpdate = true;
  spireInst.computeBoundingSphere();
  group.add(spireInst);

  // 8. Drifting Warm Glowing Fire Embers & Ash Motes
  const emberCount = 90;
  const emberPositions = new Float32Array(emberCount * 3);
  const emberVelocities = new Float32Array(emberCount * 3);

  for (let i = 0; i < emberCount; i++) {
    emberPositions[i * 3] = (Math.random() - 0.5) * 18;
    emberPositions[i * 3 + 1] = 0.25 + Math.random() * 5.2;
    emberPositions[i * 3 + 2] = (Math.random() - 0.5) * 18;

    emberVelocities[i * 3] = (Math.random() - 0.5) * 0.18;
    emberVelocities[i * 3 + 1] = 0.14 + Math.random() * 0.24;
    emberVelocities[i * 3 + 2] = (Math.random() - 0.5) * 0.18;
  }

  const emberGeo = trackGeo(new THREE.BufferGeometry());
  emberGeo.setAttribute('position', new THREE.BufferAttribute(emberPositions, 3));

  const emberMat = trackMat(
    new THREE.PointsMaterial({
      size: 0.14,
      color: 0xffa84c,
      map: bank.emberTexture,
      transparent: true,
      opacity: 0.78,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    })
  );

  const embers = new THREE.Points(emberGeo, emberMat);
  embers.frustumCulled = false;
  group.add(embers);

  return {
    group,
    tileHitMeshes,
    coordGroup,
    banners: [],
    brazierFlames,
    brazierLights,
    embers,
    emberVelocities,
    dispose: () => {
      for (const g of geometries) g.dispose();
      for (const m of materials) m.dispose();
    },
  };
}
