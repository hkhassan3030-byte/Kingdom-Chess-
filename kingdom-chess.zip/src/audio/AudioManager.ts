import type { CharacterSetId, PieceType } from '../types/chess';
import {
  ACTION_PRIORITY,
  PRIORITY_VOLUME,
  getCharacterAudioProfile,
  type ArmorDefenseClass,
  type CharacterAudioProfile,
  type CombatAction,
  type SoundPriority,
  type WeaponClass,
} from './combatAudioProfiles';

interface ActiveVoice {
  source: AudioBufferSourceNode;
  gain: GainNode;
  endTime: number;
  priority: SoundPriority;
  isCombat: boolean;
}

const SWING_MIN_INTERVAL_MS = 60;
const IMPACT_MIN_INTERVAL_MS = 55;
const MOVEMENT_MIN_INTERVAL_MS = 90;
const DEATH_VOCAL_MIN_INTERVAL_MS = 180;

/**
 * Deterministic fast PRNG for coherent, crackle-free buffer synthesis.
 */
function makeRng(seed: number): () => number {
  let s = (seed | 0) || 1;
  return () => {
    s = (s * 1664525 + 1013904223) | 0;
    return ((s >>> 0) / 4294967296) * 2 - 1;
  };
}

/**
 * Soft-saturating peak normalizer that guarantees zero digital clipping.
 */
function normalizeBuffer(data: Float32Array, targetPeak = 0.88) {
  let maxAbs = 0;
  for (let i = 0; i < data.length; i++) {
    const a = Math.abs(data[i]);
    if (a > maxAbs) maxAbs = a;
  }
  if (maxAbs > 0.0001) {
    const scale = targetPeak / maxAbs;
    for (let i = 0; i < data.length; i++) {
      data[i] = Math.tanh(data[i] * scale * 1.15) * 0.92;
    }
  }
}

export class AudioManager {
  private ctx: AudioContext | null = null;
  private sfxBus: GainNode | null = null;
  private limiter: DynamicsCompressorNode | null = null;
  private preloadedSet: CharacterSetId | null = null;

  // Cached physically synthesized or decoded Foley AudioBuffers (0 allocation during combat!)
  private foleyCache = new Map<string, AudioBuffer>();
  // Optional external licensed audio asset registry (e.g. '/assets/audio/sword_hit.ogg')
  private externalAssetUrls = new Map<string, string>();
  private loadingAssets = new Set<string>();

  private enabled = true;
  private musicEnabled = true;
  private unlocked = false;

  // Cooldown, anti-repetition & active voice tracking
  private lastPlayed = new Map<string, number>();
  private lastVariation = new Map<string, number>();
  private activeVoices: ActiveVoice[] = [];
  private readonly maxConcurrentVoices = 12;

  // Ambient music state
  private musicGain: GainNode | null = null;
  private droneOscA: OscillatorNode | null = null;
  private droneOscB: OscillatorNode | null = null;
  private droneFilter: BiquadFilterNode | null = null;
  private musicTimerId = 0;
  private musicStep = 0;
  private musicRunning = false;

  private readonly musicNotes = [
    146.83, 220.0, 261.63, 293.66, 261.63, 220.0, 174.61, 196.0,
    146.83, 220.0, 329.63, 293.66, 220.0, 174.61, 164.81, 220.0,
  ];

  /**
   * Optional hook to register real licensed audio files (.ogg/.wav/.mp3) by cue key
   * (e.g., 'death:human:k:0' or 'impact:human:heavySword:shield:hit:0').
   * Falls back safely to procedural physical Foley if not present or still loading.
   */
  public registerExternalAsset(cueKey: string, url: string) {
    this.externalAssetUrls.set(cueKey, url);
    if (this.ctx && this.enabled) {
      this.fetchAndDecodeExternalAsset(this.ctx, cueKey, url);
    }
  }

  private fetchAndDecodeExternalAsset(ctx: AudioContext, cueKey: string, url: string) {
    if (this.loadingAssets.has(cueKey)) return;
    this.loadingAssets.add(cueKey);
    void fetch(url)
      .then((res) => {
        if (!res.ok) throw new Error('Audio fetch failed');
        return res.arrayBuffer();
      })
      .then((arr) => ctx.decodeAudioData(arr))
      .then((decoded) => {
        this.foleyCache.set(cueKey, decoded);
      })
      .catch(() => {
        // Keep procedural fallback intact on missing/unusable external file
      })
      .finally(() => {
        this.loadingAssets.delete(cueKey);
      });
  }

  public setEnabled(val: boolean) {
    this.enabled = val;
    if (!val) {
      this.stopAllCombatSfx();
      this.stopMusic();
    } else if (this.musicEnabled && this.unlocked && !document.hidden) {
      this.startMusic();
    }
  }

  public setMusicEnabled(val: boolean) {
    this.musicEnabled = val;
    if (!val || !this.enabled) {
      this.stopMusic();
    } else if (this.unlocked && !document.hidden) {
      this.startMusic();
    }
  }

  public unlock(activeSet: CharacterSetId = 'human') {
    this.unlocked = true;
    this.preload(activeSet);
    if (this.enabled && this.musicEnabled && !document.hidden) {
      this.startMusic();
    }
  }

  public preload(activeSet: CharacterSetId = 'human') {
    if (!this.enabled || typeof window === 'undefined') return;
    const ctx = this.getContext();
    if (!ctx) return;
    this.getSfxOutput(ctx);
    this.warmCoreFoleyCache(ctx, activeSet);
    this.preloadedSet = activeSet;
  }

  /**
   * Asynchronously warms Foley + death vocal buffers for a newly selected Kingdom set
   * without stalling UI transitions or active gameplay frames.
   */
  public preloadSetAsync(setId: CharacterSetId) {
    if (!this.enabled || typeof window === 'undefined') return;
    if (this.preloadedSet === setId) return;
    const run = () => {
      if (!this.enabled) return;
      const ctx = this.getContext();
      if (!ctx) return;
      this.warmSetFoleyCache(ctx, setId);
      this.preloadedSet = setId;
    };
    const w = window as unknown as { requestIdleCallback?: (cb: () => void) => number };
    if (typeof w.requestIdleCallback === 'function') {
      w.requestIdleCallback(run);
    } else {
      window.setTimeout(run, 16);
    }
  }

  public handleVisibilityChange(hidden: boolean) {
    if (hidden) {
      this.stopAllCombatSfx();
      this.stopMusic();
      if (this.ctx && this.ctx.state === 'running') {
        void this.ctx.suspend().catch(() => {});
      }
    } else {
      if (this.ctx && this.ctx.state === 'suspended' && this.enabled) {
        void this.ctx.resume().catch(() => {});
      }
      if (this.enabled && this.musicEnabled && this.unlocked) {
        this.startMusic();
      }
    }
  }

  /**
   * Immediately halts any currently ringing combat swings, impacts, or death vocals
   * (called on rematch, restart, abort, or character removal).
   */
  public stopAllCombatSfx() {
    const now = this.ctx?.currentTime ?? 0;
    let write = 0;
    for (let i = 0; i < this.activeVoices.length; i++) {
      const v = this.activeVoices[i];
      if (v.isCombat) {
        try {
          v.gain.gain.cancelScheduledValues(now);
          v.gain.gain.setTargetAtTime(0.0001, now, 0.015);
          v.source.stop(now + 0.045);
        } catch {
          // Ignore already-stopped nodes
        }
      } else {
        this.activeVoices[write++] = v;
      }
    }
    this.activeVoices.length = write;
  }

  private getContext(): AudioContext | null {
    if (!this.enabled || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      void this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private getSfxOutput(ctx: AudioContext): AudioNode {
    if (!this.sfxBus || this.sfxBus.context !== ctx) {
      this.limiter = ctx.createDynamicsCompressor();
      this.limiter.threshold.setValueAtTime(-10, ctx.currentTime);
      this.limiter.knee.setValueAtTime(8, ctx.currentTime);
      this.limiter.ratio.setValueAtTime(5.5, ctx.currentTime);
      this.limiter.attack.setValueAtTime(0.002, ctx.currentTime);
      this.limiter.release.setValueAtTime(0.11, ctx.currentTime);
      this.limiter.connect(ctx.destination);

      this.sfxBus = ctx.createGain();
      this.sfxBus.gain.setValueAtTime(1.0, ctx.currentTime);
      this.sfxBus.connect(this.limiter);
    }
    return this.sfxBus;
  }

  private warmCoreFoleyCache(ctx: AudioContext, activeSet: CharacterSetId) {
    for (let v = 0; v < 3; v++) {
      this.getOrCreateBuffer(ctx, `ui:click:${v}`, () => this.bakeUiClickBuffer(ctx, false, v));
      this.getOrCreateBuffer(ctx, `ui:select:${v}`, () => this.bakeUiClickBuffer(ctx, true, v));
      this.getOrCreateBuffer(ctx, `move:stone:light:${v}`, () => this.bakeStoneMoveBuffer(ctx, 0.85, v));
      this.getOrCreateBuffer(ctx, `move:stone:medium:${v}`, () => this.bakeStoneMoveBuffer(ctx, 1.0, v));
      this.getOrCreateBuffer(ctx, `move:stone:heavy:${v}`, () => this.bakeStoneMoveBuffer(ctx, 1.25, v));
      this.getOrCreateBuffer(ctx, `hoof:${activeSet}:${v}`, () => this.bakeHoofBuffer(ctx, activeSet, v));
    }
    this.getOrCreateBuffer(ctx, 'stinger:check', () => this.bakeCheckHornBuffer(ctx));
    this.getOrCreateBuffer(ctx, 'stinger:victory', () => this.bakeGameOverChordBuffer(ctx, true));
    this.getOrCreateBuffer(ctx, 'stinger:defeat', () => this.bakeGameOverChordBuffer(ctx, false));
    this.warmSetFoleyCache(ctx, activeSet);
  }

  private warmSetFoleyCache(ctx: AudioContext, setId: CharacterSetId) {
    const pieces: PieceType[] = ['k', 'q', 'r', 'b', 'n', 'p'];
    for (let pIdx = 0; pIdx < pieces.length; pIdx++) {
      const piece = pieces[pIdx];
      const profile = getCharacterAudioProfile(setId, piece);
      const v = 0; // Pre-bake variation 0 immediately; variations 1-2 cache on first play
      if (profile.usesMagic) {
        this.getOrCreateBuffer(ctx, `magic:charge:${setId}:${v}`, () =>
          this.bakeArcaneStaffBuffer(ctx, 'charge', setId, v)
        );
        this.getOrCreateBuffer(ctx, `magic:release:${setId}:${v}`, () =>
          this.bakeArcaneStaffBuffer(ctx, 'release', setId, v)
        );
        this.getOrCreateBuffer(ctx, `magic:impact:${setId}:${v}`, () =>
          this.bakeArcaneStaffBuffer(ctx, 'impact', setId, v)
        );
      } else {
        this.getOrCreateBuffer(ctx, `swing:${setId}:${profile.weaponClass}:p:${v}`, () =>
          this.bakeWeaponSwingBuffer(ctx, setId, profile.weaponClass, false, v)
        );
        this.getOrCreateBuffer(ctx, `impact:${setId}:${profile.weaponClass}:heavyArmor:fin:${v}`, () =>
          this.bakeWeaponImpactBuffer(ctx, setId, profile.weaponClass, 'heavyArmor', true, v)
        );
      }
      this.getOrCreateBuffer(ctx, `death:${setId}:${piece}:${v}`, () =>
        this.bakeDeathVocalBuffer(ctx, profile, v)
      );
    }
  }

  private getOrCreateBuffer(
    ctx: AudioContext,
    key: string,
    factory: () => AudioBuffer
  ): AudioBuffer {
    const externalUrl = this.externalAssetUrls.get(key);
    if (externalUrl && !this.foleyCache.has(key)) {
      this.fetchAndDecodeExternalAsset(ctx, key, externalUrl);
    }
    const existing = this.foleyCache.get(key);
    if (existing && existing.sampleRate === ctx.sampleRate) {
      return existing;
    }
    const created = factory();
    this.foleyCache.set(key, created);
    return created;
  }

  private playCachedBuffer(
    ctx: AudioContext,
    buffer: AudioBuffer,
    gainLevel: number,
    playbackRate = 1.0,
    priority: SoundPriority = 3,
    isCombat = true,
    delaySec = 0
  ) {
    const src = ctx.createBufferSource();
    src.buffer = buffer;
    const startAt = ctx.currentTime + delaySec;
    if (playbackRate !== 1.0) {
      src.playbackRate.setValueAtTime(playbackRate, startAt);
    }
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(gainLevel, startAt);
    src.connect(gain);
    gain.connect(this.getSfxOutput(ctx));
    src.start(startAt);

    const voice: ActiveVoice = {
      source: src,
      gain,
      endTime: startAt + buffer.duration / Math.max(0.5, playbackRate) + 0.02,
      priority,
      isCombat,
    };
    this.activeVoices.push(voice);

    src.onended = () => {
      const idx = this.activeVoices.indexOf(voice);
      if (idx !== -1) {
        this.activeVoices.splice(idx, 1);
      }
      try {
        src.disconnect();
        gain.disconnect();
      } catch {
        // Ignore teardown
      }
    };
  }

  private pruneVoices(ctx: AudioContext | null): number {
    if (!ctx) return this.activeVoices.length;
    const now = ctx.currentTime;
    let write = 0;
    for (let i = 0; i < this.activeVoices.length; i++) {
      if (this.activeVoices[i].endTime > now) {
        this.activeVoices[write++] = this.activeVoices[i];
      }
    }
    this.activeVoices.length = write;
    return write;
  }

  private canPlayWithPriority(
    cueKey: string,
    minIntervalMs: number,
    priority: SoundPriority
  ): boolean {
    if (!this.enabled) return false;
    const activeCount = this.pruneVoices(this.ctx);

    if (activeCount >= this.maxConcurrentVoices && priority > 2) {
      return false;
    }
    if (activeCount >= this.maxConcurrentVoices + 4) {
      return false;
    }

    const nowMs = performance.now();
    const prev = this.lastPlayed.get(cueKey) ?? 0;
    if (nowMs - prev < minIntervalMs) {
      return false;
    }
    this.lastPlayed.set(cueKey, nowMs);
    return true;
  }

  private pickVariation(key: string): number {
    const prev = this.lastVariation.get(key) ?? -1;
    let next = Math.floor(Math.random() * 3);
    if (next === prev) {
      next = (next + 1 + Math.floor(Math.random() * 2)) % 3;
    }
    this.lastVariation.set(key, next);
    return next;
  }

  /**
   * Centralized physical weapon-based combat audio dispatcher.
   * Uses pre-baked modal + filtered transient Foley AudioBuffers matched to:
   * - Active character set (Human, Titan, Inferno, Shadow, Celestial)
   * - Attacker's equipped weapon (heavySword, sword, axe, hammer, spear, dagger, glaive, staff, magicStaff, bow)
   * - Defender's physical defense material (shield, heavyArmor, lightArmor, robes, wood)
   * - Defender's class & set vocal tone on lethal defeat ('deathVocal')
   */
  public playCombatSound(
    characterSet: CharacterSetId,
    characterClass: PieceType,
    action: CombatAction,
    options?: { defenderClass?: PieceType; targetMaterial?: ArmorDefenseClass }
  ) {
    if (!this.enabled) return;
    if (this.preloadedSet !== characterSet) {
      this.preload(characterSet);
    }
    const ctx = this.getContext();
    if (!ctx) return;

    const attacker = getCharacterAudioProfile(characterSet, characterClass);
    const defenderPiece: PieceType = options?.defenderClass ?? characterClass;
    const defender = getCharacterAudioProfile(characterSet, defenderPiece);

    const priority = ACTION_PRIORITY[action];
    const minInterval =
      action === 'deathVocal'
        ? DEATH_VOCAL_MIN_INTERVAL_MS
        : priority === 1
        ? IMPACT_MIN_INTERVAL_MS
        : priority === 2
        ? SWING_MIN_INTERVAL_MS
        : MOVEMENT_MIN_INTERVAL_MS;

    const cueKey =
      action === 'deathVocal'
        ? `${characterSet}:${defenderPiece}:${action}`
        : `${characterSet}:${characterClass}:${action}`;
    if (!this.canPlayWithPriority(cueKey, minInterval, priority)) return;

    const vIdx = this.pickVariation(cueKey);
    const vol = PRIORITY_VOLUME[priority] * attacker.classGain;
    const rateJitter = [0.95, 1.0, 1.06][vIdx];
    const rate = attacker.pitchScale * rateJitter;

    switch (action) {
      case 'swing':
      case 'swingSecondary': {
        const secondary = action === 'swingSecondary';
        const key = `swing:${characterSet}:${attacker.weaponClass}:${secondary ? 's' : 'p'}:${vIdx}`;
        const buf = this.getOrCreateBuffer(ctx, key, () =>
          this.bakeWeaponSwingBuffer(ctx, characterSet, attacker.weaponClass, secondary, vIdx)
        );
        this.playCachedBuffer(ctx, buf, 0.35 * vol, rate, priority, true);
        break;
      }

      case 'weaponImpact':
      case 'finisherImpact': {
        const isFinisher = action === 'finisherImpact';
        const defArmor: ArmorDefenseClass = options?.targetMaterial ?? defender.defenseClass;
        const key = `impact:${characterSet}:${attacker.weaponClass}:${defArmor}:${
          isFinisher ? 'fin' : 'hit'
        }:${vIdx}`;
        const buf = this.getOrCreateBuffer(ctx, key, () =>
          this.bakeWeaponImpactBuffer(
            ctx,
            characterSet,
            attacker.weaponClass,
            defArmor,
            isFinisher,
            vIdx
          )
        );
        this.playCachedBuffer(ctx, buf, (isFinisher ? 0.56 : 0.45) * vol, rate, priority, true);
        break;
      }

      case 'armorBlock': {
        const blockClass: ArmorDefenseClass =
          options?.targetMaterial ??
          (defender.defenseClass === 'robes' ? 'lightArmor' : defender.defenseClass);
        const key = `block:${characterSet}:${blockClass}:${attacker.weaponClass}:${vIdx}`;
        const buf = this.getOrCreateBuffer(ctx, key, () =>
          this.bakeShieldBlockBuffer(
            ctx,
            characterSet,
            defender.weight,
            vIdx,
            attacker.weaponClass,
            blockClass
          )
        );
        this.playCachedBuffer(ctx, buf, 0.48 * vol, rate, priority, true);
        break;
      }

      case 'magicCharge': {
        if (!attacker.usesMagic) return;
        const key = `magic:charge:${characterSet}:${vIdx}`;
        const buf = this.getOrCreateBuffer(ctx, key, () =>
          this.bakeArcaneStaffBuffer(ctx, 'charge', characterSet, vIdx)
        );
        this.playCachedBuffer(ctx, buf, 0.29 * vol, rate, priority, true);
        break;
      }

      case 'magicRelease': {
        if (!attacker.usesMagic) return;
        const key = `magic:release:${characterSet}:${vIdx}`;
        const buf = this.getOrCreateBuffer(ctx, key, () =>
          this.bakeArcaneStaffBuffer(ctx, 'release', characterSet, vIdx)
        );
        this.playCachedBuffer(ctx, buf, 0.35 * vol, rate, priority, true);
        break;
      }

      case 'magicImpact': {
        if (!attacker.usesMagic) return;
        const key = `magic:impact:${characterSet}:${vIdx}`;
        const buf = this.getOrCreateBuffer(ctx, key, () =>
          this.bakeArcaneStaffBuffer(ctx, 'impact', characterSet, vIdx)
        );
        this.playCachedBuffer(ctx, buf, 0.5 * vol, rate, priority, true);
        break;
      }

      case 'horseMove': {
        if (!attacker.isMounted) return;
        const key = `hoof:${characterSet}:${vIdx}`;
        const buf = this.getOrCreateBuffer(ctx, key, () =>
          this.bakeHoofBuffer(ctx, characterSet, vIdx)
        );
        this.playCachedBuffer(ctx, buf, 0.35 * vol, rateJitter, priority, true);
        break;
      }

      case 'movement': {
        const key = `move:armor:${characterSet}:${attacker.movementTimbre}:${vIdx}`;
        const buf = this.getOrCreateBuffer(ctx, key, () =>
          this.bakeArmorMoveBuffer(ctx, attacker, vIdx)
        );
        this.playCachedBuffer(ctx, buf, 0.27 * vol, rateJitter, priority, true);
        break;
      }

      case 'deathVocal': {
        const defVol = PRIORITY_VOLUME[priority] * defender.classGain;
        const key = `death:${characterSet}:${defenderPiece}:${vIdx}`;
        const buf = this.getOrCreateBuffer(ctx, key, () =>
          this.bakeDeathVocalBuffer(ctx, defender, vIdx)
        );
        this.playCachedBuffer(ctx, buf, 0.44 * defVol, rateJitter, priority, true);
        break;
      }

      case 'defenderReaction': {
        const key = `defend:fall:${characterSet}:${defender.defenseClass}:${vIdx}`;
        const buf = this.getOrCreateBuffer(ctx, key, () =>
          this.bakeBodyFallBuffer(ctx, characterSet, defender.defenseClass, vIdx)
        );
        this.playCachedBuffer(ctx, buf, 0.32 * PRIORITY_VOLUME[priority], 1.0, priority, true);
        break;
      }
    }
  }

  // ---------------------------------------------------------------------------
  // Physical Foley Synthesis Builders (Run once per buffer key, cached in RAM)
  // ---------------------------------------------------------------------------

  private bakeWeaponSwingBuffer(
    ctx: AudioContext,
    setId: CharacterSetId,
    weapon: WeaponClass,
    secondary: boolean,
    vIdx: number
  ): AudioBuffer {
    const sr = ctx.sampleRate;
    const rng = makeRng(
      1009 +
        setId.charCodeAt(0) * 149 +
        weapon.charCodeAt(0) * 97 +
        vIdx * 31 +
        (secondary ? 7 : 0)
    );

    const dur =
      weapon === 'hammer' || weapon === 'axe'
        ? 0.31
        : weapon === 'heavySword'
        ? 0.28
        : weapon === 'glaive'
        ? 0.27
        : weapon === 'dagger'
        ? 0.14
        : weapon === 'bow'
        ? 0.25
        : weapon === 'spear'
        ? 0.19
        : 0.21;

    const len = Math.floor(sr * dur);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);

    let lp1 = 0;
    let bp1 = 0;
    let hpPrev = 0;
    let xPrev = 0;
    let fireLp = 0;

    const setPitch =
      setId === 'shadow'
        ? 0.84
        : setId === 'inferno'
        ? 0.88
        : setId === 'celestial'
        ? 1.12
        : setId === 'titan'
        ? 1.08
        : 1.0;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const p = i / len;
      const env = Math.sin(Math.pow(p, 0.65) * Math.PI);

      let fSweep = 550;
      let q = 0.28;
      if (weapon === 'heavySword') {
        fSweep = (310 + Math.sin(p * Math.PI) * 980) * setPitch;
        q = 0.29;
      } else if (weapon === 'sword') {
        fSweep = (520 + Math.sin(p * Math.PI) * 1480) * setPitch;
        q = 0.24;
      } else if (weapon === 'dagger') {
        fSweep = (1380 + Math.sin(p * Math.PI) * 2650) * setPitch;
        q = 0.2;
      } else if (weapon === 'axe') {
        fSweep = (195 + Math.sin(p * Math.PI) * 510) * setPitch;
        q = 0.36;
      } else if (weapon === 'hammer') {
        fSweep = (130 + Math.sin(p * Math.PI) * 320) * setPitch;
        q = 0.42;
      } else if (weapon === 'spear') {
        fSweep = (740 + p * 1880) * setPitch;
        q = 0.22;
      } else if (weapon === 'glaive') {
        fSweep = (350 + Math.sin(p * Math.PI) * 1180) * setPitch;
        q = 0.25;
      } else if (weapon === 'bow') {
        fSweep = (1150 + (1 - p) * 2150) * setPitch;
        q = 0.17;
      } else if (weapon === 'staff' || weapon === 'magicStaff') {
        fSweep = (260 + Math.sin(p * Math.PI) * 640) * setPitch;
        q = 0.32;
      }

      const noise = rng();
      const fCoef = Math.min(0.85, 2 * Math.sin((Math.PI * fSweep) / sr));
      lp1 += fCoef * bp1;
      const hp1 = noise - lp1 - q * bp1;
      bp1 += fCoef * hp1;

      const diff = noise - xPrev;
      xPrev = noise;
      hpPrev = hpPrev * 0.72 + diff * 0.28;

      let signatureLayer = 0;
      if (weapon === 'heavySword' || weapon === 'sword' || weapon === 'dagger' || weapon === 'glaive') {
        const edgeEnv = Math.exp(-t * (weapon === 'dagger' ? 28 : 16)) * Math.min(1, t / 0.015);
        const fBase =
          (weapon === 'dagger'
            ? 3180
            : weapon === 'heavySword'
            ? 1720
            : weapon === 'glaive'
            ? 2050
            : 2480) * setPitch;
        signatureLayer =
          (Math.sin(2 * Math.PI * fBase * t) * 0.48 +
            Math.sin(2 * Math.PI * (fBase * 1.43) * t) * 0.32) *
          edgeEnv *
          (setId === 'titan' ? 0.3 : 0.22);
      } else if (weapon === 'bow') {
        // Bowstring release snap + arrow shaft whistle
        const strEnv = Math.exp(-t * 40);
        const fStr = 172 * (1 + Math.exp(-t * 95) * 0.32);
        const whistle = Math.sin(2 * Math.PI * 1950 * t) * Math.sin(p * Math.PI) * 0.14;
        signatureLayer =
          (Math.sin(2 * Math.PI * fStr * t) + 0.45 * Math.sin(2 * Math.PI * fStr * 2.02 * t)) *
            strEnv *
            0.55 +
          whistle;
      } else if (weapon === 'staff' || weapon === 'magicStaff') {
        // Wooden oak staff resonance + subtle air whoosh
        signatureLayer = Math.sin(2 * Math.PI * 295 * t) * Math.exp(-t * 22) * 0.24;
      }

      // Kingdom set atmospheric layer on swings
      let setTexture = 0;
      if (setId === 'inferno') {
        fireLp = fireLp * 0.78 + noise * 0.22;
        const crackle = Math.abs(noise) > 0.86 ? noise * 0.42 : 0;
        setTexture = (fireLp * 0.16 + crackle) * env;
      } else if (setId === 'shadow') {
        setTexture = Math.sin(2 * Math.PI * 66 * t) * env * 0.22;
      } else if (setId === 'celestial') {
        setTexture =
          (Math.sin(2 * Math.PI * 1580 * t) * 0.09 + Math.sin(2 * Math.PI * 2370 * t) * 0.06) *
          env;
      }

      data[i] = (bp1 * 0.85 + hpPrev * 0.32) * env + signatureLayer + setTexture;
    }

    normalizeBuffer(data, 0.84);
    return buf;
  }

  private bakeWeaponImpactBuffer(
    ctx: AudioContext,
    setId: CharacterSetId,
    weapon: WeaponClass,
    defense: ArmorDefenseClass,
    isFinisher: boolean,
    vIdx: number
  ): AudioBuffer {
    const sr = ctx.sampleRate;
    const rng = makeRng(
      3037 +
        setId.charCodeAt(0) * 167 +
        weapon.charCodeAt(0) * 131 +
        defense.charCodeAt(0) * 53 +
        (isFinisher ? 19 : 0) +
        vIdx * 17
    );

    const dur = isFinisher ? 0.58 : 0.42;
    const len = Math.floor(sr * dur);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);

    const setFreq =
      setId === 'shadow'
        ? 0.86
        : setId === 'inferno'
        ? 0.88
        : setId === 'celestial'
        ? 1.12
        : setId === 'titan'
        ? 1.07
        : 1.0;

    const modes: Array<{ freq: number; amp: number; decay: number }> = [];

    if (weapon === 'heavySword') {
      modes.push(
        { freq: (1280 + vIdx * 42) * setFreq, amp: 0.34, decay: 13.5 },
        { freq: (2120 + vIdx * 55) * setFreq, amp: 0.25, decay: 18 },
        { freq: 3340 * setFreq, amp: 0.14, decay: 25 }
      );
    } else if (weapon === 'sword') {
      modes.push(
        { freq: (1840 + vIdx * 55) * setFreq, amp: 0.32, decay: 16 },
        { freq: (2790 + vIdx * 70) * setFreq, amp: 0.24, decay: 21 },
        { freq: 4120 * setFreq, amp: 0.14, decay: 29 }
      );
    } else if (weapon === 'dagger') {
      modes.push(
        { freq: (2950 + vIdx * 90) * setFreq, amp: 0.36, decay: 25 },
        { freq: 4460 * setFreq, amp: 0.28, decay: 33 },
        { freq: 6180 * setFreq, amp: 0.14, decay: 44 }
      );
    } else if (weapon === 'axe') {
      modes.push(
        { freq: (1020 + vIdx * 38) * setFreq, amp: 0.3, decay: 18 },
        { freq: 1840 * setFreq, amp: 0.18, decay: 23 },
        { freq: 360 * setFreq, amp: 0.28, decay: 14 }
      );
    } else if (weapon === 'hammer') {
      modes.push(
        { freq: (220 + vIdx * 16) * setFreq, amp: 0.44, decay: 10.5 },
        { freq: (580 + vIdx * 24) * setFreq, amp: 0.3, decay: 13.5 },
        { freq: 1220 * setFreq, amp: 0.15, decay: 19 }
      );
    } else if (weapon === 'spear') {
      modes.push(
        { freq: (1560 + vIdx * 50) * setFreq, amp: 0.26, decay: 22 },
        { freq: 2480 * setFreq, amp: 0.2, decay: 28 },
        { freq: 520 * setFreq, amp: 0.22, decay: 18 }
      );
    } else if (weapon === 'glaive') {
      modes.push(
        { freq: (1640 + vIdx * 48) * setFreq, amp: 0.3, decay: 17 },
        { freq: 2620 * setFreq, amp: 0.22, decay: 22 },
        { freq: 3920 * setFreq, amp: 0.12, decay: 30 }
      );
    } else if (weapon === 'bow') {
      modes.push(
        { freq: (440 + vIdx * 25) * setFreq, amp: 0.24, decay: 25 },
        { freq: 1460 * setFreq, amp: 0.18, decay: 34 }
      );
    } else if (weapon === 'staff' || weapon === 'magicStaff') {
      modes.push(
        { freq: (340 + vIdx * 22) * setFreq, amp: 0.32, decay: 21 },
        { freq: 740 * setFreq, amp: 0.2, decay: 27 }
      );
    }

    // Target-specific defense material resonance
    if (defense === 'shield') {
      modes.push(
        { freq: (485 + vIdx * 22) * setFreq, amp: 0.36, decay: 12.5 },
        { freq: (890 + vIdx * 35) * setFreq, amp: 0.28, decay: 16 },
        { freq: 1520 * setFreq, amp: 0.22, decay: 20 }
      );
    } else if (defense === 'heavyArmor') {
      modes.push(
        { freq: (330 + vIdx * 18) * setFreq, amp: 0.38, decay: 13.5 },
        { freq: (760 + vIdx * 28) * setFreq, amp: 0.28, decay: 17 },
        { freq: 1410 * setFreq, amp: 0.18, decay: 23 }
      );
    } else if (defense === 'lightArmor') {
      modes.push({ freq: 215 * setFreq, amp: 0.25, decay: 24 });
    } else if (defense === 'wood') {
      modes.push(
        { freq: 290 + vIdx * 18, amp: 0.38, decay: 25 },
        { freq: 640, amp: 0.22, decay: 32 }
      );
    }

    const bodyFund =
      weapon === 'hammer'
        ? 72
        : weapon === 'heavySword'
        ? 84
        : weapon === 'axe'
        ? 88
        : weapon === 'spear'
        ? 110
        : weapon === 'dagger'
        ? 135
        : weapon === 'staff' || weapon === 'magicStaff'
        ? 105
        : 98;
    const bodyDecay = isFinisher ? 11.0 : 17.5;
    const metallicScale =
      defense === 'shield'
        ? 1.18
        : defense === 'heavyArmor'
        ? 1.06
        : defense === 'lightArmor'
        ? 0.62
        : defense === 'wood'
        ? 0.58
        : 0.38;

    let lowNoise = 0;
    let hiPrev = 0;

    for (let i = 0; i < len; i++) {
      const t = i / sr;

      const thudEnv = Math.exp(-t * bodyDecay) * (1 - Math.exp(-t * 950));
      const thud =
        (Math.sin(2 * Math.PI * bodyFund * t) * 0.72 +
          Math.sin(2 * Math.PI * (bodyFund * 1.48) * t) * 0.28) *
        thudEnv *
        (isFinisher ? 0.96 : 0.75);

      const n = rng();
      lowNoise = lowNoise * 0.78 + n * 0.22;
      const hiCrunch = n - hiPrev;
      hiPrev = hiPrev * 0.35 + n * 0.65;

      const transientEnv = Math.exp(-t * (weapon === 'hammer' ? 24 : 42));
      const crunchEnv = Math.exp(-t * 16);
      const impactNoise =
        hiCrunch * transientEnv * (weapon === 'dagger' ? 0.65 : 0.85) +
        lowNoise *
          crunchEnv *
          (defense === 'robes' || defense === 'lightArmor' || defense === 'wood' ? 0.75 : 0.45);

      let modal = 0;
      for (let m = 0; m < modes.length; m++) {
        const mode = modes[m];
        modal +=
          Math.sin(2 * Math.PI * mode.freq * t + m * 0.7) *
          mode.amp *
          Math.exp(-t * mode.decay);
      }

      // Kingdom set sonic fingerprint
      let setFlavor = 0;
      if (setId === 'inferno') {
        const spark = Math.abs(n) > 0.84 ? n * 0.55 : 0;
        setFlavor = (lowNoise * 0.32 + spark) * Math.exp(-t * 12);
      } else if (setId === 'shadow') {
        setFlavor = Math.sin(2 * Math.PI * 56 * t) * Math.exp(-t * 8.5) * 0.36;
      } else if (setId === 'celestial') {
        setFlavor =
          (Math.sin(2 * Math.PI * 1960 * t) * 0.14 + Math.sin(2 * Math.PI * 2940 * t) * 0.09) *
          Math.exp(-t * 11.5);
      }

      let followThrough = 0;
      if (isFinisher && t > 0.028) {
        const t2 = t - 0.028;
        followThrough =
          (Math.sin(2 * Math.PI * (bodyFund * 0.84) * t2) * 0.42 + lowNoise * 0.55) *
          Math.exp(-t2 * 13);
      }

      data[i] = thud + impactNoise + modal * metallicScale + setFlavor + followThrough * 0.65;
    }

    normalizeBuffer(data, 0.9);
    return buf;
  }

  private bakeShieldBlockBuffer(
    ctx: AudioContext,
    setId: CharacterSetId,
    defenderWeight: number,
    vIdx: number,
    attackerWeapon: WeaponClass = 'sword',
    blockClass: ArmorDefenseClass = 'shield'
  ): AudioBuffer {
    const sr = ctx.sampleRate;
    const rng = makeRng(
      5011 + setId.charCodeAt(0) * 83 + vIdx * 43 + attackerWeapon.charCodeAt(0) * 19
    );
    const dur = 0.38;
    const len = Math.floor(sr * dur);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);

    const setPitch = setId === 'shadow' ? 0.88 : setId === 'celestial' ? 1.1 : 1.0;
    const pitch = (1 / Math.max(0.75, defenderWeight)) * [0.95, 1.0, 1.06][vIdx] * setPitch;
    const isShield = blockClass === 'shield';
    const partials = isShield
      ? [
          { f: 470 * pitch, a: 0.45, d: 13 },
          { f: 865 * pitch, a: 0.34, d: 16 },
          { f: 1490 * pitch, a: 0.25, d: 21 },
          { f: 2480 * pitch, a: 0.16, d: 28 },
        ]
      : [
          { f: 340 * pitch, a: 0.38, d: 16 },
          { f: 710 * pitch, a: 0.26, d: 22 },
          { f: 1320 * pitch, a: 0.14, d: 30 },
        ];

    let scrapePrev = 0;
    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const braceThud = Math.sin(2 * Math.PI * 105 * t) * Math.exp(-t * 22) * 0.55;
      let metallic = 0;
      for (let m = 0; m < partials.length; m++) {
        metallic +=
          Math.sin(2 * Math.PI * partials[m].f * t) *
          partials[m].a *
          Math.exp(-t * partials[m].d);
      }
      const n = rng();
      const hp = n - scrapePrev * 0.82;
      scrapePrev = n;
      const scrapeEnv = Math.exp(-Math.max(0, t - 0.015) * 32) * (t < 0.14 ? 1 : 0.2);
      const scrape = hp * scrapeEnv * (isShield ? 0.38 : 0.24);

      data[i] = braceThud + metallic + scrape;
    }

    normalizeBuffer(data, 0.86);
    return buf;
  }

  private bakeArcaneStaffBuffer(
    ctx: AudioContext,
    phase: 'charge' | 'release' | 'impact',
    setId: CharacterSetId,
    vIdx: number
  ): AudioBuffer {
    const sr = ctx.sampleRate;
    const rng = makeRng(7001 + setId.charCodeAt(0) * 61 + phase.charCodeAt(0) * 13 + vIdx);

    const dur = phase === 'charge' ? 0.34 : phase === 'release' ? 0.28 : 0.52;
    const len = Math.floor(sr * dur);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);

    const rootFreq =
      setId === 'inferno' ? 142 : setId === 'shadow' ? 118 : setId === 'celestial' ? 216 : 180;

    let lp = 0;
    let bp = 0;
    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const p = i / len;
      const n = rng();

      if (phase === 'charge') {
        const env = Math.sin(p * Math.PI) * (0.35 + p * 0.65);
        const f = rootFreq * (0.9 + p * 0.42);
        const harmonics =
          Math.sin(2 * Math.PI * f * t) * 0.38 +
          Math.sin(2 * Math.PI * f * 2.01 * t) * 0.22 +
          Math.sin(2 * Math.PI * f * 3.03 * t) * 0.14;
        const woodStaff = Math.sin(2 * Math.PI * 280 * t) * Math.exp(-t * 18) * 0.22;
        const fCut = 320 + p * 1800;
        const fc = Math.min(0.8, (2 * Math.PI * fCut) / sr);
        lp += fc * (n - lp);
        data[i] = (harmonics + (n - lp) * 0.35) * env + woodStaff;
      } else if (phase === 'release') {
        const env = Math.exp(-t * 13) * (1 - Math.exp(-t * 420));
        const fCut = 2400 * Math.exp(-t * 8.5) + 300;
        const fc = Math.min(0.82, 2 * Math.sin((Math.PI * fCut) / sr));
        lp += fc * bp;
        bp += fc * (n - lp - 0.25 * bp);
        const snap = Math.sin(2 * Math.PI * (rootFreq * 2.4) * t) * Math.exp(-t * 26) * 0.44;
        data[i] = (bp * 0.9 + snap) * env;
      } else {
        // Arcane blast + resonant shockwave + subtle staff wood thump
        const sub = Math.sin(2 * Math.PI * 68 * t) * Math.exp(-t * 9.5) * 0.85;
        const crack = (n - lp) * Math.exp(-t * 28) * 0.65;
        lp = lp * 0.65 + n * 0.35;
        const bodyNoise = lp * Math.exp(-t * 10.5) * 0.74;
        const chime =
          (Math.sin(2 * Math.PI * (rootFreq * 4.5) * t) * 0.22 +
            Math.sin(2 * Math.PI * (rootFreq * 6.75) * t) * 0.14) *
          Math.exp(-t * 13.5);
        data[i] = sub + crack + bodyNoise + chime;
      }
    }

    normalizeBuffer(data, 0.88);
    return buf;
  }

  /**
   * Formant-filtered realistic dark-fantasy death gasp / painful warrior grunt.
   * Grounded and short (~0.32-0.44s), customized to defender class and Kingdom set.
   */
  private bakeDeathVocalBuffer(
    ctx: AudioContext,
    defender: CharacterAudioProfile,
    vIdx: number
  ): AudioBuffer {
    const sr = ctx.sampleRate;
    const rng = makeRng(
      8821 +
        defender.setId.charCodeAt(0) * 193 +
        defender.pieceType.charCodeAt(0) * 71 +
        vIdx * 37
    );

    const dur = defender.pieceType === 'k' || defender.pieceType === 'r' ? 0.42 : 0.34;
    const len = Math.floor(sr * dur);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);

    const f0Start = defender.vocalBaseHz * [0.97, 1.0, 1.04][vIdx];
    const f0End = f0Start * (defender.pieceType === 'q' ? 0.68 : 0.62);

    // Vocal tract formants (chest/throat resonance for dark-fantasy "ugh"/"gah" exhale)
    const isFemale = defender.pieceType === 'q';
    const formants = isFemale
      ? [
          { f: 680, bw: 95, amp: 0.9 },
          { f: 1320, bw: 130, amp: 0.62 },
          { f: 2550, bw: 190, amp: 0.28 },
        ]
      : defender.vocalTone === 'elderRaspy'
      ? [
          { f: 490, bw: 85, amp: 0.85 },
          { f: 1080, bw: 120, amp: 0.52 },
          { f: 2150, bw: 180, amp: 0.22 },
        ]
      : [
          { f: 520, bw: 80, amp: 0.95 },
          { f: 1140, bw: 115, amp: 0.58 },
          { f: 2280, bw: 175, amp: 0.24 },
        ];

    // 2-pole resonator states per formant
    const y1 = new Float32Array(formants.length);
    const y2 = new Float32Array(formants.length);

    let phase = 0;
    let breathLp = 0;

    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const p = i / len;

      // Natural pain gasp envelope: fast vocal onset (18ms) -> decaying breath tail
      const attack = Math.min(1, t / 0.018);
      const decay = Math.exp(-p * (defender.setId === 'titan' ? 4.4 : 3.4));
      const voiceAmp = attack * decay;

      // Falling fundamental pitch with slight natural micro-flutter
      const jitter = 1 + Math.sin(t * 48) * 0.015;
      const f0 = (f0Start + (f0End - f0Start) * Math.pow(p, 0.72)) * jitter;
      phase = (phase + f0 / sr) % 1;

      // Soft glottal pulse (bandlimited warm sawtooth approximation -> realistic chest tone)
      const glottal =
        Math.sin(2 * Math.PI * phase) * 0.55 +
        Math.sin(4 * Math.PI * phase) * 0.28 +
        Math.sin(6 * Math.PI * phase) * 0.14 +
        Math.sin(8 * Math.PI * phase) * 0.06;

      // Turbulent vocal cord breathiness & rasp
      const n = rng();
      breathLp = breathLp * 0.62 + n * 0.38;
      const raspAmount =
        defender.setId === 'inferno'
          ? 0.62
          : defender.vocalTone === 'elderRaspy'
          ? 0.55
          : 0.36;
      const excitation =
        (glottal * (1 - p * 0.45) + (n - breathLp) * (raspAmount + p * 0.45)) * voiceAmp;

      // Run vocal tract formant resonators
      let voiced = 0;
      for (let fIdx = 0; fIdx < formants.length; fIdx++) {
        const fm = formants[fIdx];
        // Slight closing of mouth/throat as breath drops
        const fc = fm.f * (1 - p * 0.16);
        const r = Math.exp((-Math.PI * fm.bw) / sr);
        const w = (2 * Math.PI * fc) / sr;
        const a1 = -2 * r * Math.cos(w);
        const a2 = r * r;
        const out = excitation - a1 * y1[fIdx] - a2 * y2[fIdx];
        y2[fIdx] = y1[fIdx];
        y1[fIdx] = out;
        voiced += out * fm.amp * 0.085;
      }

      // Subtle Kingdom sonic mood on death breath
      let mood = 0;
      if (defender.setId === 'shadow') {
        mood = Math.sin(2 * Math.PI * (f0Start * 0.5) * t) * voiceAmp * 0.22;
      } else if (defender.setId === 'inferno') {
        mood = (n - breathLp) * voiceAmp * 0.16;
      } else if (defender.setId === 'celestial') {
        mood = Math.sin(2 * Math.PI * (f0Start * 1.5) * t) * Math.exp(-t * 6.5) * 0.1;
      }

      data[i] = voiced + mood;
    }

    normalizeBuffer(data, 0.84);
    return buf;
  }

  private bakeHoofBuffer(
    ctx: AudioContext,
    setId: CharacterSetId,
    vIdx: number
  ): AudioBuffer {
    const sr = ctx.sampleRate;
    const rng = makeRng(8101 + setId.charCodeAt(0) * 41 + vIdx * 29);
    const dur = 0.24;
    const len = Math.floor(sr * dur);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);

    const taps = [0.005, 0.088 + vIdx * 0.008];
    const pitchScale = setId === 'inferno' ? 0.9 : setId === 'celestial' ? 1.08 : 1.0;
    const tapFreqs = [(390 + vIdx * 24) * pitchScale, (330 + vIdx * 18) * pitchScale];

    let lp = 0;
    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const n = rng();
      lp = lp * 0.72 + n * 0.28;
      let sample = 0;

      for (let k = 0; k < taps.length; k++) {
        const dt = t - taps[k];
        if (dt >= 0) {
          const env = Math.exp(-dt * 46);
          const f1 = tapFreqs[k];
          const clop =
            (Math.sin(2 * Math.PI * f1 * dt) * 0.55 +
              Math.sin(2 * Math.PI * (f1 * 1.92) * dt) * 0.32) *
            env;
          const grit = (n * 0.55 + lp * 0.45) * Math.exp(-dt * 34) * 0.52;
          sample += (clop + grit) * (k === 0 ? 1.0 : 0.82);
        }
      }
      data[i] = sample;
    }

    normalizeBuffer(data, 0.84);
    return buf;
  }

  private bakeArmorMoveBuffer(
    ctx: AudioContext,
    profile: CharacterAudioProfile,
    vIdx: number
  ): AudioBuffer {
    const sr = ctx.sampleRate;
    const rng = makeRng(
      9103 + profile.setId.charCodeAt(0) * 59 + profile.pieceType.charCodeAt(0) * 37 + vIdx * 11
    );
    const dur = 0.2;
    const len = Math.floor(sr * dur);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);

    const heavy = profile.movementTimbre === 'heavyPlate' || profile.weight >= 1.15;
    const isTitanGear = profile.movementTimbre === 'titanGear';
    let lp = 0;
    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const n = rng();
      lp = lp * (heavy ? 0.85 : 0.55) + n * (heavy ? 0.15 : 0.45);
      const stepEnv = Math.exp(-t * (heavy ? 24 : 34)) * Math.min(1, t / 0.008);
      const chink = heavy
        ? Math.sin(2 * Math.PI * (640 + vIdx * 35) * t) * Math.exp(-t * 28) * 0.25 +
          Math.sin(2 * Math.PI * 1240 * t) * Math.exp(-t * 36) * 0.14
        : isTitanGear
        ? Math.sin(2 * Math.PI * (1420 + vIdx * 40) * t) * Math.exp(-t * 42) * 0.22
        : 0;
      const thump = heavy ? Math.sin(2 * Math.PI * 88 * t) * Math.exp(-t * 22) * 0.45 : 0;
      data[i] = (heavy ? lp * 0.6 : (n - lp) * 0.45) * stepEnv + chink + thump;
    }

    normalizeBuffer(data, 0.74);
    return buf;
  }

  private bakeBodyFallBuffer(
    ctx: AudioContext,
    setId: CharacterSetId,
    defense: ArmorDefenseClass,
    vIdx: number
  ): AudioBuffer {
    const sr = ctx.sampleRate;
    const rng = makeRng(9601 + setId.charCodeAt(0) * 31 + defense.charCodeAt(0) * 23 + vIdx);
    const dur = 0.3;
    const len = Math.floor(sr * dur);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);

    const hasMetal = defense === 'shield' || defense === 'heavyArmor';
    let lp = 0;
    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const n = rng();
      lp = lp * 0.86 + n * 0.14;
      const thud = Math.sin(2 * Math.PI * 70 * t) * Math.exp(-t * 15) * 0.72;
      const grit = lp * Math.exp(-t * 14) * 0.5;
      const clatter =
        hasMetal && t > 0.025
          ? (Math.sin(2 * Math.PI * 520 * (t - 0.025)) * 0.28 +
              Math.sin(2 * Math.PI * 1080 * (t - 0.025)) * 0.16) *
            Math.exp(-(t - 0.025) * 19)
          : 0;
      data[i] = thud + grit + clatter;
    }

    normalizeBuffer(data, 0.8);
    return buf;
  }

  private bakeStoneMoveBuffer(
    ctx: AudioContext,
    weight: number,
    vIdx: number
  ): AudioBuffer {
    const sr = ctx.sampleRate;
    const rng = makeRng(4409 + Math.round(weight * 100) + vIdx * 17);
    const dur = 0.14;
    const len = Math.floor(sr * dur);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);

    const clackFreq = (520 / Math.max(0.75, weight)) * [0.96, 1.0, 1.05][vIdx];
    const thudFreq = (118 / Math.max(0.75, weight)) * [0.95, 1.0, 1.04][vIdx];

    let lp = 0;
    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const n = rng();
      lp = lp * 0.76 + n * 0.24;
      const clack =
        (Math.sin(2 * Math.PI * clackFreq * t) * 0.45 +
          Math.sin(2 * Math.PI * (clackFreq * 2.18) * t) * 0.22) *
        Math.exp(-t * 62);
      const thump = Math.sin(2 * Math.PI * thudFreq * t) * Math.exp(-t * 28) * 0.65;
      const stoneGrit = (n - lp) * Math.exp(-t * 48) * 0.38;
      data[i] = clack + thump + stoneGrit;
    }

    normalizeBuffer(data, 0.76);
    return buf;
  }

  private bakeUiClickBuffer(ctx: AudioContext, select: boolean, vIdx: number): AudioBuffer {
    const sr = ctx.sampleRate;
    const rng = makeRng(2111 + (select ? 97 : 13) + vIdx);
    const dur = 0.045;
    const len = Math.floor(sr * dur);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);

    const f = (select ? 920 : 680) * [0.95, 1.0, 1.06][vIdx];
    let prev = 0;
    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const n = rng();
      const hp = n - prev * 0.75;
      prev = n;
      const tap = Math.sin(2 * Math.PI * f * t) * Math.exp(-t * 145) * 0.55;
      const crisp = hp * Math.exp(-t * 180) * 0.45;
      data[i] = tap + crisp;
    }

    normalizeBuffer(data, 0.62);
    return buf;
  }

  private bakeCheckHornBuffer(ctx: AudioContext): AudioBuffer {
    const sr = ctx.sampleRate;
    const dur = 0.58;
    const len = Math.floor(sr * dur);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);

    // Deep medieval war-horn & dark iron bell toll (serious dark-fantasy check alert)
    for (let i = 0; i < len; i++) {
      const t = i / sr;
      const env = Math.min(1, t / 0.045) * Math.exp(-t * 4.2);
      const horn =
        (Math.sin(2 * Math.PI * 146.83 * t) * 0.55 +
          Math.sin(2 * Math.PI * 220.0 * t) * 0.28 +
          Math.sin(2 * Math.PI * 293.66 * t) * 0.18 +
          Math.sin(2 * Math.PI * 440.0 * t) * 0.08) *
        env;
      const bell =
        (Math.sin(2 * Math.PI * 587.33 * t) * 0.2 +
          Math.sin(2 * Math.PI * 880.0 * t) * 0.1) *
        Math.exp(-t * 8.5);
      data[i] = horn + bell;
    }

    normalizeBuffer(data, 0.78);
    return buf;
  }

  private bakeGameOverChordBuffer(ctx: AudioContext, victory: boolean): AudioBuffer {
    const sr = ctx.sampleRate;
    const dur = 1.25;
    const len = Math.floor(sr * dur);
    const buf = ctx.createBuffer(1, len, sr);
    const data = buf.getChannelData(0);

    // Somber cinematic brass/bell cadence (D major heroic for victory, D minor solemn for defeat)
    const freqs = victory ? [146.83, 220.0, 293.66, 369.99] : [146.83, 174.61, 220.0, 277.18];
    for (let i = 0; i < len; i++) {
      const t = i / sr;
      let s = 0;
      for (let k = 0; k < freqs.length; k++) {
        const onset = k * 0.075;
        if (t >= onset) {
          const dt = t - onset;
          const env = Math.min(1, dt / 0.06) * Math.exp(-dt * 2.25);
          const f = freqs[k];
          s +=
            (Math.sin(2 * Math.PI * f * dt) * 0.58 +
              Math.sin(2 * Math.PI * f * 2 * dt) * 0.24 +
              Math.sin(2 * Math.PI * f * 3 * dt) * 0.1) *
            env;
        }
      }
      data[i] = s;
    }

    normalizeBuffer(data, 0.8);
    return buf;
  }

  // ---------------------------------------------------------------------------
  // Ambient Music & Non-Combat Board/UI Calls
  // ---------------------------------------------------------------------------

  public startMusic() {
    if (this.musicRunning || !this.enabled || !this.musicEnabled || document.hidden) return;
    const ctx = this.getContext();
    if (!ctx) return;

    this.musicRunning = true;
    const now = ctx.currentTime;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(0.04, now + 1.8);
    gain.connect(ctx.destination);
    this.musicGain = gain;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(250, now);
    filter.connect(gain);
    this.droneFilter = filter;

    const oscA = ctx.createOscillator();
    oscA.type = 'sine';
    oscA.frequency.setValueAtTime(73.42, now);
    oscA.connect(filter);
    oscA.start(now);
    this.droneOscA = oscA;

    const oscB = ctx.createOscillator();
    oscB.type = 'triangle';
    oscB.frequency.setValueAtTime(110.0, now);
    const fifthGain = ctx.createGain();
    fifthGain.gain.setValueAtTime(0.35, now);
    oscB.connect(fifthGain);
    fifthGain.connect(filter);
    oscB.start(now);
    this.droneOscB = oscB;

    this.musicTimerId = window.setInterval(() => {
      if (!this.musicRunning || !this.enabled || !this.musicEnabled || document.hidden) return;
      const c = this.ctx;
      const master = this.musicGain;
      if (!c || !master || c.state !== 'running') return;

      const t = c.currentTime;
      const freq = this.musicNotes[this.musicStep % this.musicNotes.length];
      this.musicStep++;

      const pluck = c.createOscillator();
      const pluckGain = c.createGain();
      const pluckFilter = c.createBiquadFilter();
      pluck.type = 'triangle';
      pluck.frequency.setValueAtTime(freq, t);

      pluckFilter.type = 'lowpass';
      pluckFilter.frequency.setValueAtTime(freq * 3.1, t);
      pluckFilter.frequency.exponentialRampToValueAtTime(freq * 1.1, t + 1.3);

      pluckGain.gain.setValueAtTime(0.0001, t);
      pluckGain.gain.linearRampToValueAtTime(0.26, t + 0.04);
      pluckGain.gain.exponentialRampToValueAtTime(0.0008, t + 1.45);

      pluck.connect(pluckFilter);
      pluckFilter.connect(pluckGain);
      pluckGain.connect(master);
      pluck.start(t);
      pluck.stop(t + 1.5);
    }, 1150);
  }

  public stopMusic() {
    this.musicRunning = false;
    if (this.musicTimerId) {
      window.clearInterval(this.musicTimerId);
      this.musicTimerId = 0;
    }
    const ctx = this.ctx;
    if (this.musicGain && ctx) {
      try {
        const now = ctx.currentTime;
        this.musicGain.gain.cancelScheduledValues(now);
        this.musicGain.gain.setValueAtTime(Math.max(0.0001, this.musicGain.gain.value), now);
        this.musicGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);
      } catch {
        // Ignore teardown edge cases
      }
    }
    const oscA = this.droneOscA;
    const oscB = this.droneOscB;
    this.droneOscA = null;
    this.droneOscB = null;
    this.droneFilter = null;
    this.musicGain = null;

    if (oscA || oscB) {
      window.setTimeout(() => {
        try {
          oscA?.stop();
          oscA?.disconnect();
        } catch {
          // ignore
        }
        try {
          oscB?.stop();
          oscB?.disconnect();
        } catch {
          // ignore
        }
      }, 220);
    }
  }

  public playButtonClick() {
    if (!this.canPlayWithPriority('ui:button', 65, 5)) return;
    if (!this.preloadedSet) this.preload();
    const ctx = this.getContext();
    if (!ctx) return;
    const vIdx = this.pickVariation('ui:click');
    const buf = this.getOrCreateBuffer(ctx, `ui:click:${vIdx}`, () =>
      this.bakeUiClickBuffer(ctx, false, vIdx)
    );
    this.playCachedBuffer(ctx, buf, 0.16, 1.0, 5, false);
  }

  public playSelect() {
    if (!this.canPlayWithPriority('ui:select', 70, 5)) return;
    if (!this.preloadedSet) this.preload();
    const ctx = this.getContext();
    if (!ctx) return;
    const vIdx = this.pickVariation('ui:select');
    const buf = this.getOrCreateBuffer(ctx, `ui:select:${vIdx}`, () =>
      this.bakeUiClickBuffer(ctx, true, vIdx)
    );
    this.playCachedBuffer(ctx, buf, 0.2, 1.0, 5, false);
  }

  /**
   * Non-capture chess piece placement / stride matched to active Kingdom & piece weight.
   */
  public playPieceMove(characterSet: CharacterSetId, pieceType: PieceType) {
    const profile = getCharacterAudioProfile(characterSet, pieceType);
    if (profile.isMounted) {
      this.playCombatSound(characterSet, pieceType, 'horseMove');
      return;
    }
    if (!this.canPlayWithPriority('chess:move', 85, 4)) return;
    if (this.preloadedSet !== characterSet) this.preload(characterSet);
    const ctx = this.getContext();
    if (!ctx) return;

    const bucket = profile.weight >= 1.15 ? 'heavy' : profile.weight <= 0.88 ? 'light' : 'medium';
    const targetWeight = bucket === 'heavy' ? 1.25 : bucket === 'light' ? 0.85 : 1.0;
    const vIdx = this.pickVariation(`move:${bucket}`);
    const buf = this.getOrCreateBuffer(ctx, `move:stone:${bucket}:${vIdx}`, () =>
      this.bakeStoneMoveBuffer(ctx, targetWeight, vIdx)
    );
    this.playCachedBuffer(ctx, buf, 0.3, 1.0, 4, false);
  }

  public playMove() {
    this.playPieceMove('human', 'p');
  }

  public playHorseGallop() {
    this.playCombatSound('human', 'n', 'horseMove');
  }

  public playCheck() {
    if (!this.canPlayWithPriority('chess:check', 250, 2)) return;
    if (!this.preloadedSet) this.preload();
    const ctx = this.getContext();
    if (!ctx) return;
    const buf = this.getOrCreateBuffer(ctx, 'stinger:check', () => this.bakeCheckHornBuffer(ctx));
    this.playCachedBuffer(ctx, buf, 0.26, 1.0, 2, false);
  }

  public playGameOver(victory: boolean) {
    if (!this.canPlayWithPriority('chess:gameover', 400, 1)) return;
    if (!this.preloadedSet) this.preload();
    const ctx = this.getContext();
    if (!ctx) return;
    const key = victory ? 'stinger:victory' : 'stinger:defeat';
    const buf = this.getOrCreateBuffer(ctx, key, () =>
      this.bakeGameOverChordBuffer(ctx, victory)
    );
    this.playCachedBuffer(ctx, buf, 0.34, 1.0, 1, false);
  }

  public cleanup() {
    this.stopAllCombatSfx();
    this.stopMusic();
    this.lastPlayed.clear();
    this.lastVariation.clear();
    this.activeVoices.length = 0;
    this.foleyCache.clear();
    this.loadingAssets.clear();
    this.preloadedSet = null;
    if (this.ctx) {
      void this.ctx.close().catch(() => {});
      this.ctx = null;
    }
    this.sfxBus = null;
    this.limiter = null;
  }
}

export const audioManager = new AudioManager();
