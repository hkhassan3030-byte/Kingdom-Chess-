import { ArrowLeft, Check, ChevronRight, Shield, Swords } from 'lucide-react';
import { CHARACTER_SETS, CHARACTER_SET_ORDER } from '../three/characterSets';
import { KingdomPreviewCanvas } from '../three/KingdomPreviewCanvas';
import type { CharacterSetId, GraphicsQuality, PieceType } from '../types/chess';

interface KingdomSelectScreenProps {
  selectedSet: CharacterSetId;
  quality: GraphicsQuality;
  onSelectSet: (setId: CharacterSetId) => void;
  onContinue: () => void;
  onBack: () => void;
}

const ROSTER_ORDER: Array<{ type: PieceType; label: string }> = [
  { type: 'k', label: 'King' },
  { type: 'q', label: 'Queen' },
  { type: 'b', label: 'Bishop' },
  { type: 'n', label: 'Knight' },
  { type: 'r', label: 'Rook' },
  { type: 'p', label: 'Pawn' },
];

export function KingdomSelectScreen({
  selectedSet,
  quality,
  onSelectSet,
  onContinue,
  onBack,
}: KingdomSelectScreenProps) {
  const activeCfg = CHARACTER_SETS[selectedSet];

  return (
    <section className="flex h-dvh w-full max-w-full flex-col overflow-x-hidden overflow-y-auto bg-[radial-gradient(circle_at_50%_10%,#1b2438_0%,#0b0f18_75%)] px-4 py-4 sm:px-8 sm:py-6">
      <div className="mx-auto flex w-full max-w-5xl flex-1 flex-col">
        {/* Top Bar */}
        <header className="flex items-center justify-between gap-3 border-b border-amber-400/20 pb-3.5">
          <button
            type="button"
            onClick={onBack}
            className="fantasy-btn-secondary flex min-h-[44px] items-center gap-2 rounded-xl px-4 py-2 text-sm font-semibold"
          >
            <ArrowLeft className="h-4 w-4 text-amber-300" />
            <span>Back</span>
          </button>

          <div className="text-center">
            <h1 className="font-display text-base font-bold tracking-[0.1em] text-amber-100 sm:text-2xl">
              CHOOSE YOUR KINGDOM
            </h1>
            <p className="text-[11px] text-amber-200/75 sm:text-xs">
              Select a 3D Hero Character Set
            </p>
          </div>

          <div className="w-[76px] sm:w-[84px]" aria-hidden="true" />
        </header>

        {/* Main Content Grid */}
        <div className="mt-4 grid flex-1 grid-cols-1 gap-4 pb-4 lg:grid-cols-[1.05fr_1fr] lg:items-start">
          {/* Left: Single Lightweight 3D Preview + Hero Roster */}
          <div className="fantasy-panel flex flex-col overflow-hidden rounded-2xl">
            <div className="relative h-52 w-full overflow-hidden border-b border-amber-400/20 bg-[#0f1523] sm:h-64">
              <KingdomPreviewCanvas characterSet={selectedSet} quality={quality} />
              <div
                aria-hidden="true"
                className="pointer-events-none absolute inset-x-0 bottom-0 h-14 bg-gradient-to-t from-[#0f1523] to-transparent"
              />
              <div className="pointer-events-none absolute bottom-2.5 left-4 right-4 flex items-end justify-between gap-2">
                <div>
                  <div className={`text-[11px] font-bold uppercase tracking-wider ${activeCfg.badgeTextClass}`}>
                    {activeCfg.tagline}
                  </div>
                  <div className="font-display text-lg font-bold text-amber-100 sm:text-xl">
                    {activeCfg.name}
                  </div>
                </div>
                <div className="flex items-center gap-1.5 pb-1" aria-hidden="true">
                  {activeCfg.swatchColors.map((hex) => (
                    <span
                      key={hex}
                      className="h-3.5 w-3.5 rounded-sm border border-white/25"
                      style={{ backgroundColor: hex }}
                    />
                  ))}
                </div>
              </div>
            </div>

            <div className="space-y-3.5 p-4 sm:p-5">
              <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-2.5">
                <span className="flex items-center gap-1.5 text-xs font-semibold text-slate-300">
                  <Swords className="h-3.5 w-3.5 text-amber-300" />
                  Combat Style
                </span>
                <span className={`text-xs font-bold ${activeCfg.badgeTextClass}`}>
                  {activeCfg.combat.styleLabel}
                </span>
              </div>

              <p className="text-xs leading-relaxed text-slate-300 sm:text-sm">
                {activeCfg.description}
              </p>

              {/* 6-Piece Class Roster */}
              <div>
                <div className="mb-2 flex items-center gap-1.5 text-[11px] font-bold tracking-wider text-amber-200/80 uppercase">
                  <Shield className="h-3.5 w-3.5 text-amber-300" />
                  <span>Full 6-Piece Hero Roster</span>
                </div>
                <div className="grid grid-cols-2 gap-1.5 sm:grid-cols-3">
                  {ROSTER_ORDER.map(({ type, label }) => {
                    const hero = activeCfg.pieces[type];
                    return (
                      <div
                        key={type}
                        className="rounded-xl border border-white/8 bg-white/4 px-2.5 py-2"
                      >
                        <div className="text-[10px] font-bold tracking-wider text-slate-400 uppercase">
                          {label}
                        </div>
                        <div className="truncate text-xs font-semibold text-slate-100">
                          {hero.roleTitle}
                        </div>
                        <div className="truncate text-[10px] text-slate-400">
                          {hero.weaponLabel}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>

          {/* Right: 5 Selectable Character Sets */}
          <div className="flex flex-col gap-2.5">
            {CHARACTER_SET_ORDER.map((id) => {
              const cfg = CHARACTER_SETS[id];
              const isSelected = selectedSet === id;
              return (
                <button
                  key={id}
                  type="button"
                  onClick={() => onSelectSet(id)}
                  className={`flex min-h-[68px] w-full items-center justify-between gap-3 rounded-2xl border bg-gradient-to-r px-4 py-3 text-left transition-all active:scale-[0.99] ${
                    isSelected
                      ? `${cfg.borderActiveClass} ${cfg.cardBgClass} shadow-[0_0_24px_rgba(245,180,65,0.18)]`
                      : 'border-white/10 from-[#121826]/90 to-[#0e131e]/90 hover:border-amber-400/40'
                  }`}
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <div
                      className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-white/15 font-display text-base font-bold text-slate-950"
                      style={{
                        background: `linear-gradient(135deg, ${cfg.swatchColors[0]} 0%, ${cfg.swatchColors[1]} 100%)`,
                      }}
                    >
                      {cfg.number}
                    </div>

                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span
                          className={`font-display truncate text-sm font-bold sm:text-base ${
                            isSelected ? 'text-amber-100' : 'text-slate-100'
                          }`}
                        >
                          {cfg.name}
                        </span>
                      </div>
                      <div className={`truncate text-xs font-medium ${cfg.badgeTextClass}`}>
                        {cfg.tagline}
                      </div>
                      <div className="truncate text-[11px] text-slate-400">
                        {cfg.combat.styleLabel}
                      </div>
                    </div>
                  </div>

                  <div className="flex shrink-0 items-center gap-2">
                    {isSelected ? (
                      <span className="flex h-8 w-8 items-center justify-center rounded-xl border border-amber-400/50 bg-amber-400/20 text-amber-200">
                        <Check className="h-4 w-4" />
                      </span>
                    ) : (
                      <ChevronRight className="h-4 w-4 text-slate-500" />
                    )}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Bottom Primary CTA */}
        <div className="sticky bottom-0 border-t border-amber-400/15 bg-[#0b0f18]/95 pt-3 pb-1">
          <button
            type="button"
            onClick={onContinue}
            className="fantasy-btn-primary flex min-h-[52px] w-full items-center justify-center gap-2 rounded-2xl px-6 text-sm font-bold tracking-[0.08em] uppercase sm:text-base"
          >
            <span className="font-display">Continue with {activeCfg.name}</span>
            <ChevronRight className="h-5 w-5" />
          </button>
        </div>
      </div>
    </section>
  );
}
