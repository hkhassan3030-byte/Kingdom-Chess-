import type { CharacterSetId, PieceType } from '../types/chess';

export type CombatAction =
  | 'swing'
  | 'swingSecondary'
  | 'weaponImpact'
  | 'finisherImpact'
  | 'armorBlock'
  | 'magicCharge'
  | 'magicRelease'
  | 'magicImpact'
  | 'horseMove'
  | 'movement'
  | 'defenderReaction';

export type SoundPriority = 1 | 2 | 3 | 4 | 5;

export type SwingTimbre =
  | 'medievalHeavy'
  | 'medievalAgile'
  | 'medievalLight'
  | 'titanBlade'
  | 'titanHeavy'
  | 'infernoHeavy'
  | 'shadowSharp'
  | 'celestialClean'
  | 'magicSweep';

export type ImpactTimbre =
  | 'medievalHeavy'
  | 'medievalSharp'
  | 'medievalSiege'
  | 'medievalLight'
  | 'titanSlice'
  | 'titanHeavy'
  | 'infernoForge'
  | 'shadowDark'
  | 'celestialDivine'
  | 'magicArcane';

export type MovementTimbre =
  | 'none'
  | 'horseHoof'
  | 'heavyPlate'
  | 'lightCloth'
  | 'titanGear';

export interface CharacterAudioProfile {
  setId: CharacterSetId;
  pieceType: PieceType;
  label: string;
  swingTimbre: SwingTimbre;
  impactTimbre: ImpactTimbre;
  movementTimbre: MovementTimbre;
  /** Scales pitch/brightness: lower = heavier/slower (<1.0), higher = faster/sharper (>1.0) */
  pitchScale: number;
  /** Scales low-end body & metallic ring duration (0.75 - 1.35) */
  weight: number;
  /** Volume trim relative to action priority hierarchy (0.75 - 1.15) */
  classGain: number;
  /** True only when character visually casts magic spells */
  usesMagic: boolean;
  /** True only when character visually uses an actual melee blade/weapon */
  usesWeapon: boolean;
  /** True only when character is riding a horse */
  isMounted: boolean;
}

export const ACTION_PRIORITY: Record<CombatAction, SoundPriority> = {
  // 1. Weapon impact (highest)
  finisherImpact: 1,
  weaponImpact: 1,
  magicImpact: 1,
  // 2. Weapon swing
  swing: 2,
  swingSecondary: 2,
  // 3. Character-specific attack sound
  magicRelease: 3,
  armorBlock: 3,
  // 4. Horse / magic / ability sound
  magicCharge: 4,
  horseMove: 4,
  // 5. Minor movement / defender reaction sound
  movement: 5,
  defenderReaction: 5,
};

/**
 * Sound volume hierarchy multipliers (Priority 1 loudest -> Priority 5 subtlest).
 */
export const PRIORITY_VOLUME: Record<SoundPriority, number> = {
  1: 1.0,
  2: 0.72,
  3: 0.64,
  4: 0.52,
  5: 0.34,
};

export const CHARACTER_AUDIO_PROFILES: Record<
  CharacterSetId,
  Record<PieceType, CharacterAudioProfile>
> = {
  human: {
    k: {
      setId: 'human',
      pieceType: 'k',
      label: 'Human Sovereign King',
      swingTimbre: 'medievalHeavy',
      impactTimbre: 'medievalHeavy',
      movementTimbre: 'heavyPlate',
      pitchScale: 0.84,
      weight: 1.25,
      classGain: 1.06,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    q: {
      setId: 'human',
      pieceType: 'q',
      label: 'Human Sovereign Queen',
      swingTimbre: 'medievalAgile',
      impactTimbre: 'medievalSharp',
      movementTimbre: 'lightCloth',
      pitchScale: 1.2,
      weight: 0.92,
      classGain: 0.98,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    r: {
      setId: 'human',
      pieceType: 'r',
      label: 'Human Siege Warden',
      swingTimbre: 'medievalHeavy',
      impactTimbre: 'medievalSiege',
      movementTimbre: 'heavyPlate',
      pitchScale: 0.72,
      weight: 1.35,
      classGain: 1.08,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    b: {
      setId: 'human',
      pieceType: 'b',
      label: 'Human High Prelate',
      swingTimbre: 'magicSweep',
      impactTimbre: 'magicArcane',
      movementTimbre: 'lightCloth',
      pitchScale: 1.0,
      weight: 0.95,
      classGain: 0.96,
      usesMagic: true,
      usesWeapon: false,
      isMounted: false,
    },
    n: {
      setId: 'human',
      pieceType: 'n',
      label: 'Human Centaur Lancer',
      swingTimbre: 'medievalAgile',
      impactTimbre: 'medievalHeavy',
      movementTimbre: 'horseHoof',
      pitchScale: 0.96,
      weight: 1.12,
      classGain: 1.0,
      usesMagic: false,
      usesWeapon: true,
      isMounted: true,
    },
    p: {
      setId: 'human',
      pieceType: 'p',
      label: 'Human Vanguard Footman',
      swingTimbre: 'medievalLight',
      impactTimbre: 'medievalLight',
      movementTimbre: 'lightCloth',
      pitchScale: 1.08,
      weight: 0.78,
      classGain: 0.86,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
  },
  titan: {
    k: {
      setId: 'titan',
      pieceType: 'k',
      label: 'Titan Garrison Commander',
      swingTimbre: 'titanHeavy',
      impactTimbre: 'titanHeavy',
      movementTimbre: 'titanGear',
      pitchScale: 0.92,
      weight: 1.15,
      classGain: 1.04,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    q: {
      setId: 'titan',
      pieceType: 'q',
      label: 'Titan Elite Scout Captain',
      swingTimbre: 'titanBlade',
      impactTimbre: 'titanSlice',
      movementTimbre: 'titanGear',
      pitchScale: 1.28,
      weight: 0.9,
      classGain: 1.0,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    r: {
      setId: 'titan',
      pieceType: 'r',
      label: 'Titan Bastion Sentinel',
      swingTimbre: 'titanHeavy',
      impactTimbre: 'titanHeavy',
      movementTimbre: 'heavyPlate',
      pitchScale: 0.78,
      weight: 1.28,
      classGain: 1.06,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    b: {
      setId: 'titan',
      pieceType: 'b',
      label: 'Titan Tactical Officer',
      swingTimbre: 'titanBlade',
      impactTimbre: 'titanSlice',
      movementTimbre: 'titanGear',
      pitchScale: 1.12,
      weight: 0.88,
      classGain: 0.94,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    n: {
      setId: 'titan',
      pieceType: 'n',
      label: 'Titan Aerial Vanguard',
      swingTimbre: 'titanBlade',
      impactTimbre: 'titanSlice',
      movementTimbre: 'titanGear',
      pitchScale: 1.24,
      weight: 0.96,
      classGain: 1.0,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    p: {
      setId: 'titan',
      pieceType: 'p',
      label: 'Titan Wall Recruit',
      swingTimbre: 'titanBlade',
      impactTimbre: 'titanSlice',
      movementTimbre: 'titanGear',
      pitchScale: 1.12,
      weight: 0.76,
      classGain: 0.85,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
  },
  inferno: {
    k: {
      setId: 'inferno',
      pieceType: 'k',
      label: 'Inferno Fire Emperor',
      swingTimbre: 'infernoHeavy',
      impactTimbre: 'infernoForge',
      movementTimbre: 'heavyPlate',
      pitchScale: 0.78,
      weight: 1.32,
      classGain: 1.08,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    q: {
      setId: 'inferno',
      pieceType: 'q',
      label: 'Inferno Empress',
      swingTimbre: 'infernoHeavy',
      impactTimbre: 'infernoForge',
      movementTimbre: 'lightCloth',
      pitchScale: 1.1,
      weight: 1.0,
      classGain: 1.0,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    r: {
      setId: 'inferno',
      pieceType: 'r',
      label: 'Inferno Magma Juggernaut',
      swingTimbre: 'infernoHeavy',
      impactTimbre: 'infernoForge',
      movementTimbre: 'heavyPlate',
      pitchScale: 0.68,
      weight: 1.38,
      classGain: 1.1,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    b: {
      setId: 'inferno',
      pieceType: 'b',
      label: 'Inferno Pyromancer Magus',
      swingTimbre: 'magicSweep',
      impactTimbre: 'infernoForge',
      movementTimbre: 'lightCloth',
      pitchScale: 0.88,
      weight: 1.12,
      classGain: 0.98,
      usesMagic: true,
      usesWeapon: false,
      isMounted: false,
    },
    n: {
      setId: 'inferno',
      pieceType: 'n',
      label: 'Inferno Ashen Outrider',
      swingTimbre: 'infernoHeavy',
      impactTimbre: 'infernoForge',
      movementTimbre: 'horseHoof',
      pitchScale: 0.9,
      weight: 1.18,
      classGain: 1.02,
      usesMagic: false,
      usesWeapon: true,
      isMounted: true,
    },
    p: {
      setId: 'inferno',
      pieceType: 'p',
      label: 'Inferno Cinder Legionnaire',
      swingTimbre: 'infernoHeavy',
      impactTimbre: 'infernoForge',
      movementTimbre: 'lightCloth',
      pitchScale: 1.04,
      weight: 0.82,
      classGain: 0.88,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
  },
  shadow: {
    k: {
      setId: 'shadow',
      pieceType: 'k',
      label: 'Shadow Dread Sovereign',
      swingTimbre: 'shadowSharp',
      impactTimbre: 'shadowDark',
      movementTimbre: 'heavyPlate',
      pitchScale: 0.82,
      weight: 1.24,
      classGain: 1.06,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    q: {
      setId: 'shadow',
      pieceType: 'q',
      label: 'Shadow Queen',
      swingTimbre: 'shadowSharp',
      impactTimbre: 'shadowDark',
      movementTimbre: 'lightCloth',
      pitchScale: 1.26,
      weight: 0.92,
      classGain: 1.0,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    r: {
      setId: 'shadow',
      pieceType: 'r',
      label: 'Shadow Crypt Guardian',
      swingTimbre: 'shadowSharp',
      impactTimbre: 'shadowDark',
      movementTimbre: 'heavyPlate',
      pitchScale: 0.72,
      weight: 1.34,
      classGain: 1.08,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    b: {
      setId: 'shadow',
      pieceType: 'b',
      label: 'Shadow Void Necromancer',
      swingTimbre: 'magicSweep',
      impactTimbre: 'shadowDark',
      movementTimbre: 'lightCloth',
      pitchScale: 0.84,
      weight: 1.05,
      classGain: 0.98,
      usesMagic: true,
      usesWeapon: false,
      isMounted: false,
    },
    n: {
      setId: 'shadow',
      pieceType: 'n',
      label: 'Shadow Nightfall Rider',
      swingTimbre: 'shadowSharp',
      impactTimbre: 'shadowDark',
      movementTimbre: 'horseHoof',
      pitchScale: 0.94,
      weight: 1.12,
      classGain: 1.0,
      usesMagic: false,
      usesWeapon: true,
      isMounted: true,
    },
    p: {
      setId: 'shadow',
      pieceType: 'p',
      label: 'Shadow Shade Footman',
      swingTimbre: 'shadowSharp',
      impactTimbre: 'shadowDark',
      movementTimbre: 'lightCloth',
      pitchScale: 1.12,
      weight: 0.78,
      classGain: 0.86,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
  },
  celestial: {
    k: {
      setId: 'celestial',
      pieceType: 'k',
      label: 'Celestial King',
      swingTimbre: 'celestialClean',
      impactTimbre: 'celestialDivine',
      movementTimbre: 'heavyPlate',
      pitchScale: 0.88,
      weight: 1.22,
      classGain: 1.06,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    q: {
      setId: 'celestial',
      pieceType: 'q',
      label: 'Celestial Seraphic Queen',
      swingTimbre: 'celestialClean',
      impactTimbre: 'celestialDivine',
      movementTimbre: 'lightCloth',
      pitchScale: 1.22,
      weight: 0.94,
      classGain: 1.0,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    r: {
      setId: 'celestial',
      pieceType: 'r',
      label: 'Celestial Aegis Guardian',
      swingTimbre: 'celestialClean',
      impactTimbre: 'celestialDivine',
      movementTimbre: 'heavyPlate',
      pitchScale: 0.76,
      weight: 1.32,
      classGain: 1.06,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
    b: {
      setId: 'celestial',
      pieceType: 'b',
      label: 'Celestial High Cleric',
      swingTimbre: 'magicSweep',
      impactTimbre: 'celestialDivine',
      movementTimbre: 'lightCloth',
      pitchScale: 1.1,
      weight: 0.96,
      classGain: 0.98,
      usesMagic: true,
      usesWeapon: false,
      isMounted: false,
    },
    n: {
      setId: 'celestial',
      pieceType: 'n',
      label: 'Celestial Astral Paladin',
      swingTimbre: 'celestialClean',
      impactTimbre: 'celestialDivine',
      movementTimbre: 'horseHoof',
      pitchScale: 0.98,
      weight: 1.12,
      classGain: 1.02,
      usesMagic: false,
      usesWeapon: true,
      isMounted: true,
    },
    p: {
      setId: 'celestial',
      pieceType: 'p',
      label: 'Celestial Dawn Squire',
      swingTimbre: 'celestialClean',
      impactTimbre: 'celestialDivine',
      movementTimbre: 'lightCloth',
      pitchScale: 1.1,
      weight: 0.78,
      classGain: 0.86,
      usesMagic: false,
      usesWeapon: true,
      isMounted: false,
    },
  },
};

export function getCharacterAudioProfile(
  characterSet: CharacterSetId,
  pieceType: PieceType
): CharacterAudioProfile {
  return CHARACTER_AUDIO_PROFILES[characterSet]?.[pieceType] ?? CHARACTER_AUDIO_PROFILES.human[pieceType];
}
