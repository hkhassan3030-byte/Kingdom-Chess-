import type { CharacterSetId, PieceType } from '../types/chess';
import {
  ACTION_PRIORITY,
  PRIORITY_VOLUME,
  getCharacterAudioProfile,
  type CharacterAudioProfile,
  type CombatAction,
  type SoundPriority,
} from './combatAudioProfiles';

interface ActiveVoice {
  endTime: number;
  priority: SoundPriority;
}

const VARIATION_DETUNE = [0.93, 1.0, 1.075] as const;
const VARIATION_FILTER = [0.91, 1.0, 1.11] as const;
const VARIATION_DECAY = [0.94, 1.0, 1.07] as const;

const CHECK_NOTES = [440, 554.37, 659.25];
const VICTORY_CHORD = [392, 493.88, 587.33, 783.99];
const DEFEAT_CHORD = [349.23, 415.3, 523.25];

const SWING_MIN_INTERVAL_MS = 65;
const IMPACT_MIN_INTERVAL_MS = 60;
const MOVEMENT_MIN_INTERVAL_MS = 95;

export class AudioManager {
  private ctx: AudioContext | null = null;
  private sfxBus: GainNode | null = null;
  private limiter: DynamicsCompressorNode | null = null;
  private preloaded = false;

  // Cached reusable AudioBuffers (3 distinct noise colors so variations never re-allocate during combat)
  private noiseCache: AudioBuffer[] = [];
  private softImpactCache: AudioBuffer | null = null;

  private enabled = true;
  private musicEnabled = true;
  private unlocked = false;

  // Cooldown & variation state
  private lastPlayed = new Map<string, number>();
  private lastVariation = new Map<string, number>();
  private activeVoices: ActiveVoice[] = [];
  private readonly maxConcurrentVoices = 10;

  // Ambient music state (kept lightweight)
  private musicGain: GainNode | null = null;
  private droneOscA: OscillatorNode | null = null;
  private droneOscB: OscillatorNode | null = null;
  private droneFilter: BiquadFilterNode | null = null;
  private musicTimerId = 0;
  private musicStep = 0;
  private musicRunning = false;

  private readonly musicNotes = [
    146.83, 220.0, 261.63, 293.66, 261.63, 220.0, 174.61, 196.0,
    146.83, 220.0, 329.63, 293.66, 220.0, 174.61, 164.81, 220.0,
  ];

  public setEnabled(val: boolean) {
    this.enabled = val;
    if (!val) {
      this.stopMusic();
    } else if (this.musicEnabled && this.unlocked && !document.hidden) {
      this.startMusic();
    }
  }

  public setMusicEnabled(val: boolean) {
    this.musicEnabled = val;
    if (!val || !this.enabled) {
      this.stopMusic();
    } else if (this.unlocked && !document.hidden) {
      this.startMusic();
    }
  }

  public unlock() {
    this.unlocked = true;
    this.preload();
    if (this.enabled && this.musicEnabled && !document.hidden) {
      this.startMusic();
    }
  }

  /**
   * Preloads & caches AudioContext bus and noise/transient AudioBuffers once so combat triggers zero buffer allocations.
   */
  public preload() {
    if (!this.enabled || typeof window === 'undefined') return;
    const ctx = this.getContext();
    if (!ctx) return;
    this.getSfxOutput(ctx);
    this.ensureBuffersCached(ctx);
    this.preloaded = true;
  }

  public handleVisibilityChange(hidden: boolean) {
    if (hidden) {
      this.stopMusic();
      if (this.ctx && this.ctx.state === 'running') {
        void this.ctx.suspend().catch(() => {});
      }
    } else {
      if (this.ctx && this.ctx.state === 'suspended' && this.enabled) {
        void this.ctx.resume().catch(() => {});
      }
      if (this.enabled && this.musicEnabled && this.unlocked) {
        this.startMusic();
      }
    }
  }

  private getContext(): AudioContext | null {
    if (!this.enabled || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      void this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  private getSfxOutput(ctx: AudioContext): AudioNode {
    if (!this.sfxBus || this.sfxBus.context !== ctx) {
      this.limiter = ctx.createDynamicsCompressor();
      this.limiter.threshold.setValueAtTime(-12, ctx.currentTime);
      this.limiter.knee.setValueAtTime(10, ctx.currentTime);
      this.limiter.ratio.setValueAtTime(6, ctx.currentTime);
      this.limiter.attack.setValueAtTime(0.002, ctx.currentTime);
      this.limiter.release.setValueAtTime(0.12, ctx.currentTime);
      this.limiter.connect(ctx.destination);

      this.sfxBus = ctx.createGain();
      this.sfxBus.gain.setValueAtTime(1.0, ctx.currentTime);
      this.sfxBus.connect(this.limiter);
    }
    return this.sfxBus;
  }

  private ensureBuffersCached(ctx: AudioContext) {
    if (
      this.noiseCache.length === 3 &&
      this.noiseCache[0].sampleRate === ctx.sampleRate &&
      this.softImpactCache
    ) {
      return;
    }

    this.noiseCache.length = 0;
    const len = Math.floor(ctx.sampleRate * 0.42);
    for (let v = 0; v < 3; v++) {
      const buf = ctx.createBuffer(1, len, ctx.sampleRate);
      const data = buf.getChannelData(0);
      let prev = 0;
      const smooth = v === 0 ? 0.15 : v === 1 ? 0.35 : 0.0;
      for (let i = 0; i < len; i++) {
        const white = Math.random() * 2 - 1;
        prev = prev * smooth + white * (1 - smooth);
        data[i] = prev;
      }
      this.noiseCache.push(buf);
    }

    // Short punch transient buffer reused for hoof/armor/blade click
    const impLen = Math.floor(ctx.sampleRate * 0.12);
    const impBuf = ctx.createBuffer(1, impLen, ctx.sampleRate);
    const impData = impBuf.getChannelData(0);
    for (let i = 0; i < impLen; i++) {
      const env = Math.exp((-i / impLen) * 8);
      impData[i] = (Math.random() * 2 - 1) * env;
    }
    this.softImpactCache = impBuf;
  }

  private pruneVoices(ctx: AudioContext | null): number {
    if (!ctx) return this.activeVoices.length;
    const now = ctx.currentTime;
    let write = 0;
    for (let i = 0; i < this.activeVoices.length; i++) {
      if (this.activeVoices[i].endTime > now) {
        this.activeVoices[write++] = this.activeVoices[i];
      }
    }
    this.activeVoices.length = write;
    return write;
  }

  private canPlayWithPriority(
    cueKey: string,
    minIntervalMs: number,
    priority: SoundPriority
  ): boolean {
    if (!this.enabled) return false;
    const activeCount = this.pruneVoices(this.ctx);

    // Reserve polyphony slots for high-priority impacts & swings (priorities 1-2)
    if (activeCount >= this.maxConcurrentVoices && priority > 2) {
      return false;
    }
    if (activeCount >= this.maxConcurrentVoices + 3) {
      return false;
    }

    const nowMs = performance.now();
    const prev = this.lastPlayed.get(cueKey) ?? 0;
    if (nowMs - prev < minIntervalMs) {
      return false;
    }
    this.lastPlayed.set(cueKey, nowMs);
    return true;
  }

  private trackVoice(ctx: AudioContext, durationSec: number, priority: SoundPriority) {
    this.activeVoices.push({
      endTime: ctx.currentTime + durationSec + 0.02,
      priority,
    });
  }

  /**
   * Selects a non-repeating variation index [0..2] for the given key (never fires multiple variations together).
   */
  private pickVariation(key: string): number {
    const prev = this.lastVariation.get(key) ?? -1;
    let next = Math.floor(Math.random() * 3);
    if (next === prev) {
      next = (next + 1 + Math.floor(Math.random() * 2)) % 3;
    }
    this.lastVariation.set(key, next);
    return next;
  }

  /**
   * Centralized combat audio dispatcher.
   * All character/set identity, variation, priority volume, and resource caching live here.
   */
  public playCombatSound(
    characterSet: CharacterSetId,
    characterClass: PieceType,
    action: CombatAction,
    options?: { defenderClass?: PieceType }
  ) {
    if (!this.enabled) return;
    if (!this.preloaded) this.preload();
    const ctx = this.getContext();
    if (!ctx) return;

    this.ensureBuffersCached(ctx);
    const profile = getCharacterAudioProfile(characterSet, characterClass);
    const priority = ACTION_PRIORITY[action];
    const minInterval =
      priority === 1
        ? IMPACT_MIN_INTERVAL_MS
        : priority === 2
        ? SWING_MIN_INTERVAL_MS
        : MOVEMENT_MIN_INTERVAL_MS;

    const cueKey = `${characterSet}:${characterClass}:${action}`;
    if (!this.canPlayWithPriority(cueKey, minInterval, priority)) return;

    const vIdx = this.pickVariation(`${characterClass}:${action}`);
    const detune = VARIATION_DETUNE[vIdx];
    const filterMul = VARIATION_FILTER[vIdx];
    const decayMul = VARIATION_DECAY[vIdx];
    const out = this.getSfxOutput(ctx);
    const vol = PRIORITY_VOLUME[priority] * profile.classGain;

    switch (action) {
      case 'swing':
      case 'swingSecondary':
        this.synthSwing(ctx, out, profile, action === 'swingSecondary', vol, detune, filterMul, decayMul, vIdx, priority);
        break;
      case 'weaponImpact':
      case 'finisherImpact':
        this.synthImpact(ctx, out, profile, action === 'finisherImpact', vol, detune, filterMul, decayMul, vIdx, priority);
        break;
      case 'armorBlock':
        this.synthArmorBlock(ctx, out, profile, vol, detune, decayMul, vIdx, priority);
        break;
      case 'magicCharge':
        if (!profile.usesMagic) return;
        this.synthMagicCharge(ctx, out, profile, vol, detune, decayMul, priority);
        break;
      case 'magicRelease':
        if (!profile.usesMagic) return;
        this.synthMagicRelease(ctx, out, profile, vol, detune, filterMul, decayMul, vIdx, priority);
        break;
      case 'magicImpact':
        if (!profile.usesMagic) return;
        this.synthMagicImpact(ctx, out, profile, vol, detune, decayMul, priority);
        break;
      case 'horseMove':
        if (!profile.isMounted) return;
        this.synthHorseMove(ctx, out, profile, vol, detune, vIdx, priority);
        break;
      case 'movement':
        this.synthMovement(ctx, out, profile, vol, detune, vIdx, priority);
        break;
      case 'defenderReaction': {
        const defProfile = options?.defenderClass
          ? getCharacterAudioProfile(characterSet, options.defenderClass)
          : profile;
        this.synthDefenderReaction(ctx, out, defProfile, vol, detune, vIdx, priority);
        break;
      }
    }
  }

  private synthSwing(
    ctx: AudioContext,
    out: AudioNode,
    profile: CharacterAudioProfile,
    isSecondary: boolean,
    vol: number,
    detune: number,
    filterMul: number,
    decayMul: number,
    vIdx: number,
    priority: SoundPriority
  ) {
    const now = ctx.currentTime;
    const pitch = profile.pitchScale * detune * (isSecondary ? 1.08 : 1.0);
    const dur = (profile.weight > 1.15 ? 0.22 : 0.145) * decayMul;

    // 1. Air-cutting blade whoosh from cached noise buffer
    const noise = ctx.createBufferSource();
    noise.buffer = this.noiseCache[vIdx];

    const filter = ctx.createBiquadFilter();
    filter.type = 'bandpass';
    const qVal =
      profile.swingTimbre === 'titanBlade' || profile.swingTimbre === 'shadowSharp'
        ? 4.2
        : profile.swingTimbre === 'celestialClean'
        ? 3.1
        : 2.3;
    filter.Q.setValueAtTime(qVal, now);

    const baseFreq = 580 * pitch * filterMul;
    const peakFreq =
      profile.swingTimbre === 'titanBlade' || profile.swingTimbre === 'shadowSharp'
        ? 2400 * pitch * filterMul
        : 1650 * pitch * filterMul;
    filter.frequency.setValueAtTime(baseFreq, now);
    filter.frequency.exponentialRampToValueAtTime(peakFreq, now + dur * 0.36);
    filter.frequency.exponentialRampToValueAtTime(Math.max(220, baseFreq * 0.65), now + dur);

    const nGain = ctx.createGain();
    nGain.gain.setValueAtTime(0.001, now);
    nGain.gain.linearRampToValueAtTime(0.16 * vol, now + dur * 0.28);
    nGain.gain.exponentialRampToValueAtTime(0.001, now + dur);

    noise.connect(filter);
    filter.connect(nGain);
    nGain.connect(out);
    noise.start(now);
    noise.stop(now + dur + 0.01);

    // 2. Subtle steel edge whistle / character signature air resonance
    if (profile.swingTimbre === 'titanBlade' || profile.swingTimbre === 'shadowSharp' || profile.swingTimbre === 'celestialClean') {
      const edge = ctx.createOscillator();
      const eGain = ctx.createGain();
      edge.type = profile.swingTimbre === 'shadowSharp' ? 'sawtooth' : 'sine';
      const edgeStart = (profile.swingTimbre === 'celestialClean' ? 920 : 1240) * pitch;
      edge.frequency.setValueAtTime(edgeStart, now);
      edge.frequency.exponentialRampToValueAtTime(edgeStart * 0.56, now + dur * 0.85);
      eGain.gain.setValueAtTime(0.001, now);
      eGain.gain.linearRampToValueAtTime(0.028 * vol, now + dur * 0.2);
      eGain.gain.exponentialRampToValueAtTime(0.001, now + dur * 0.9);
      edge.connect(eGain);
      eGain.connect(out);
      edge.start(now);
      edge.stop(now + dur);
    } else if (profile.swingTimbre === 'infernoHeavy') {
      // Subtle ember roar inside heavy Inferno swing
      const roar = ctx.createOscillator();
      const rGain = ctx.createGain();
      roar.type = 'triangle';
      roar.frequency.setValueAtTime(165 * pitch, now);
      roar.frequency.exponentialRampToValueAtTime(72 * pitch, now + dur);
      rGain.gain.setValueAtTime(0.001, now);
      rGain.gain.linearRampToValueAtTime(0.08 * vol, now + dur * 0.28);
      rGain.gain.exponentialRampToValueAtTime(0.001, now + dur);
      roar.connect(rGain);
      rGain.connect(out);
      roar.start(now);
      roar.stop(now + dur);
    }

    this.trackVoice(ctx, dur, priority);
  }

  private synthImpact(
    ctx: AudioContext,
    out: AudioNode,
    profile: CharacterAudioProfile,
    isFinisher: boolean,
    vol: number,
    detune: number,
    filterMul: number,
    decayMul: number,
    vIdx: number,
    priority: SoundPriority
  ) {
    const now = ctx.currentTime;
    const finisherScale = isFinisher ? 1.18 : 0.86;
    const pitch = profile.pitchScale * detune;
    const ringDur = (0.18 + profile.weight * 0.09) * decayMul * (isFinisher ? 1.15 : 0.85);

    // Layer A: Crisp initial contact transient (cached buffer)
    if (this.softImpactCache) {
      const click = ctx.createBufferSource();
      click.buffer = this.softImpactCache;
      const bp = ctx.createBiquadFilter();
      bp.type = 'bandpass';
      bp.Q.setValueAtTime(1.8, now);
      bp.frequency.setValueAtTime(1850 * pitch * filterMul, now);
      const cGain = ctx.createGain();
      cGain.gain.setValueAtTime(0.24 * vol * finisherScale, now);
      cGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      click.connect(bp);
      bp.connect(cGain);
      cGain.connect(out);
      click.start(now);
      click.stop(now + 0.09);
    }

    // Layer B: Low kinetic body thud scaled by class weight (Rook/King deep, Queen/Pawn lighter)
    const body = ctx.createOscillator();
    const bGain = ctx.createGain();
    body.type = 'triangle';
    const startLow = (profile.weight > 1.2 ? 132 : 178) * pitch;
    const endLow = profile.weight > 1.2 ? 36 : 54;
    const bodyDur = (0.13 + profile.weight * 0.06) * decayMul;
    body.frequency.setValueAtTime(startLow, now);
    body.frequency.exponentialRampToValueAtTime(endLow, now + bodyDur);
    bGain.gain.setValueAtTime(0.22 * vol * profile.weight * finisherScale, now);
    bGain.gain.exponentialRampToValueAtTime(0.001, now + bodyDur + 0.02);
    body.connect(bGain);
    bGain.connect(out);
    body.start(now);
    body.stop(now + bodyDur + 0.03);

    // Layer C: Set-specific metallic / elemental signature (cohesive, zero random extra FX)
    if (profile.impactTimbre === 'magicArcane') {
      const orb = ctx.createOscillator();
      const oGain = ctx.createGain();
      orb.type = 'sine';
      orb.frequency.setValueAtTime(1040 * pitch, now);
      orb.frequency.exponentialRampToValueAtTime(290 * pitch, now + ringDur);
      oGain.gain.setValueAtTime(0.14 * vol * finisherScale, now);
      oGain.gain.exponentialRampToValueAtTime(0.001, now + ringDur);
      orb.connect(oGain);
      oGain.connect(out);
      orb.start(now);
      orb.stop(now + ringDur + 0.01);
    } else if (profile.impactTimbre === 'titanSlice' || profile.impactTimbre === 'titanHeavy') {
      // Crisp high-tension steel slice ring
      const freqs = profile.impactTimbre === 'titanHeavy' ? [740, 1380] : [1320, 2240];
      for (let i = 0; i < freqs.length; i++) {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = i === 0 ? 'sawtooth' : 'sine';
        osc.frequency.setValueAtTime(freqs[i] * pitch, now);
        osc.frequency.exponentialRampToValueAtTime(freqs[i] * pitch * 0.84, now + ringDur * 0.9);
        g.gain.setValueAtTime((0.065 * vol * finisherScale) / (i + 1), now);
        g.gain.exponentialRampToValueAtTime(0.001, now + ringDur * 0.9);
        osc.connect(g);
        g.connect(out);
        osc.start(now);
        osc.stop(now + ringDur);
      }
    } else if (profile.impactTimbre === 'infernoForge') {
      // Heavy forged anvil strike + controlled volcanic ember burst
      const anvil = ctx.createOscillator();
      const aGain = ctx.createGain();
      anvil.type = 'sawtooth';
      anvil.frequency.setValueAtTime(520 * pitch, now);
      anvil.frequency.exponentialRampToValueAtTime(240 * pitch, now + ringDur);
      aGain.gain.setValueAtTime(0.07 * vol * finisherScale, now);
      aGain.gain.exponentialRampToValueAtTime(0.001, now + ringDur);
      anvil.connect(aGain);
      aGain.connect(out);
      anvil.start(now);
      anvil.stop(now + ringDur + 0.01);

      const fireSrc = ctx.createBufferSource();
      fireSrc.buffer = this.noiseCache[vIdx];
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.setValueAtTime(980 * filterMul, now);
      lp.frequency.exponentialRampToValueAtTime(190, now + ringDur);
      const fGain = ctx.createGain();
      fGain.gain.setValueAtTime(0.11 * vol * finisherScale, now);
      fGain.gain.exponentialRampToValueAtTime(0.001, now + ringDur);
      fireSrc.connect(lp);
      lp.connect(fGain);
      fGain.connect(out);
      fireSrc.start(now);
      fireSrc.stop(now + ringDur + 0.01);
    } else if (profile.impactTimbre === 'shadowDark') {
      // Dark cold razor steel + dissonant minor second shadow sting
      const blade = ctx.createOscillator();
      const bG = ctx.createGain();
      blade.type = 'sawtooth';
      blade.frequency.setValueAtTime(960 * pitch, now);
      blade.frequency.exponentialRampToValueAtTime(410 * pitch, now + ringDur);
      bG.gain.setValueAtTime(0.062 * vol * finisherScale, now);
      bG.gain.exponentialRampToValueAtTime(0.001, now + ringDur);
      blade.connect(bG);
      bG.connect(out);
      blade.start(now);
      blade.stop(now + ringDur + 0.01);

      const dark = ctx.createOscillator();
      const dG = ctx.createGain();
      dark.type = 'sine';
      dark.frequency.setValueAtTime(320 * pitch, now);
      dark.frequency.exponentialRampToValueAtTime(145 * pitch, now + ringDur);
      dG.gain.setValueAtTime(0.075 * vol * finisherScale, now);
      dG.gain.exponentialRampToValueAtTime(0.001, now + ringDur);
      dark.connect(dG);
      dG.connect(out);
      dark.start(now);
      dark.stop(now + ringDur + 0.01);
    } else if (profile.impactTimbre === 'celestialDivine') {
      // Clean steel ring + radiant fifth bell resonance
      const harm = [880 * pitch, 1320 * pitch];
      for (let i = 0; i < harm.length; i++) {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = i === 0 ? 'triangle' : 'sine';
        osc.frequency.setValueAtTime(harm[i], now);
        osc.frequency.exponentialRampToValueAtTime(harm[i] * 0.94, now + ringDur * 1.15);
        g.gain.setValueAtTime((0.068 * vol * finisherScale) / (i + 1), now);
        g.gain.exponentialRampToValueAtTime(0.001, now + ringDur * 1.15);
        osc.connect(g);
        g.connect(out);
        osc.start(now);
        osc.stop(now + ringDur * 1.16);
      }
    } else {
      // Realistic medieval sword & heavy plate impact harmonics
      const freqs =
        profile.impactTimbre === 'medievalSiege'
          ? [490, 880, 1420]
          : profile.impactTimbre === 'medievalHeavy'
          ? [640, 1120, 1740]
          : profile.impactTimbre === 'medievalSharp'
          ? [980, 1620]
          : [840, 1380];
      for (let i = 0; i < freqs.length; i++) {
        const osc = ctx.createOscillator();
        const g = ctx.createGain();
        osc.type = i === 0 ? 'sawtooth' : 'sine';
        osc.frequency.setValueAtTime(freqs[i] * pitch, now);
        osc.frequency.exponentialRampToValueAtTime(freqs[i] * pitch * 0.76, now + ringDur);
        g.gain.setValueAtTime((0.056 * vol * finisherScale) / (i + 1), now);
        g.gain.exponentialRampToValueAtTime(0.001, now + ringDur);
        osc.connect(g);
        g.connect(out);
        osc.start(now);
        osc.stop(now + ringDur + 0.01);
      }
    }

    this.trackVoice(ctx, ringDur + 0.02, priority);
  }

  private synthArmorBlock(
    ctx: AudioContext,
    out: AudioNode,
    profile: CharacterAudioProfile,
    vol: number,
    detune: number,
    decayMul: number,
    vIdx: number,
    priority: SoundPriority
  ) {
    const now = ctx.currentTime;
    const pitch = profile.pitchScale * detune;
    const dur = 0.16 * decayMul;

    const thud = ctx.createOscillator();
    const tGain = ctx.createGain();
    thud.type = 'sine';
    thud.frequency.setValueAtTime(195 * pitch, now);
    thud.frequency.exponentialRampToValueAtTime(54, now + dur);
    tGain.gain.setValueAtTime(0.22 * vol, now);
    tGain.gain.exponentialRampToValueAtTime(0.001, now + dur);
    thud.connect(tGain);
    tGain.connect(out);
    thud.start(now);
    thud.stop(now + dur + 0.01);

    const clang = ctx.createOscillator();
    const cGain = ctx.createGain();
    clang.type = 'triangle';
    clang.frequency.setValueAtTime((profile.setId === 'titan' ? 920 : 640) * pitch, now);
    clang.frequency.exponentialRampToValueAtTime(420 * pitch, now + dur * 0.85);
    cGain.gain.setValueAtTime(0.065 * vol, now);
    cGain.gain.exponentialRampToValueAtTime(0.001, now + dur * 0.85);
    clang.connect(cGain);
    cGain.connect(out);
    clang.start(now);
    clang.stop(now + dur);

    // Brief metal scrape
    const scrape = ctx.createBufferSource();
    scrape.buffer = this.noiseCache[vIdx];
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.setValueAtTime(3.2, now);
    bp.frequency.setValueAtTime(1450 * pitch, now);
    const sGain = ctx.createGain();
    sGain.gain.setValueAtTime(0.06 * vol, now);
    sGain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
    scrape.connect(bp);
    bp.connect(sGain);
    sGain.connect(out);
    scrape.start(now);
    scrape.stop(now + 0.09);

    this.trackVoice(ctx, dur + 0.01, priority);
  }

  private synthMagicCharge(
    ctx: AudioContext,
    out: AudioNode,
    profile: CharacterAudioProfile,
    vol: number,
    detune: number,
    decayMul: number,
    priority: SoundPriority
  ) {
    const now = ctx.currentTime;
    const pitch = profile.pitchScale * detune;
    const dur = 0.34 * decayMul;

    const baseFreqs =
      profile.setId === 'shadow'
        ? [290, 435, 580]
        : profile.setId === 'inferno'
        ? [240, 360, 520]
        : profile.setId === 'celestial'
        ? [520, 780, 1040]
        : [420, 630, 840];

    for (let i = 0; i < baseFreqs.length; i++) {
      const f = baseFreqs[i] * pitch;
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = profile.setId === 'shadow' && i === 0 ? 'triangle' : 'sine';
      osc.frequency.setValueAtTime(f * 0.82, now);
      osc.frequency.exponentialRampToValueAtTime(f * 1.32, now + dur);
      g.gain.setValueAtTime(0.001, now);
      g.gain.linearRampToValueAtTime((0.062 * vol) / (i + 1), now + dur * 0.45);
      g.gain.exponentialRampToValueAtTime(0.001, now + dur);
      osc.connect(g);
      g.connect(out);
      osc.start(now);
      osc.stop(now + dur + 0.01);
    }

    this.trackVoice(ctx, dur + 0.01, priority);
  }

  private synthMagicRelease(
    ctx: AudioContext,
    out: AudioNode,
    profile: CharacterAudioProfile,
    vol: number,
    detune: number,
    filterMul: number,
    decayMul: number,
    vIdx: number,
    priority: SoundPriority
  ) {
    const now = ctx.currentTime;
    const pitch = profile.pitchScale * detune;
    const dur = 0.16 * decayMul;

    const osc = ctx.createOscillator();
    const g = ctx.createGain();
    osc.type = profile.setId === 'celestial' ? 'sine' : 'triangle';
    const startF = (profile.setId === 'celestial' ? 960 : 720) * pitch;
    osc.frequency.setValueAtTime(startF, now);
    osc.frequency.exponentialRampToValueAtTime(startF * 0.42, now + dur);
    g.gain.setValueAtTime(0.095 * vol, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + dur);
    osc.connect(g);
    g.connect(out);
    osc.start(now);
    osc.stop(now + dur + 0.01);

    // Pure energy air release (never a steel blade clang)
    const src = ctx.createBufferSource();
    src.buffer = this.noiseCache[vIdx];
    const bp = ctx.createBiquadFilter();
    bp.type = 'bandpass';
    bp.Q.setValueAtTime(3.0, now);
    bp.frequency.setValueAtTime(1200 * pitch * filterMul, now);
    bp.frequency.exponentialRampToValueAtTime(480 * pitch, now + dur);
    const nG = ctx.createGain();
    nG.gain.setValueAtTime(0.075 * vol, now);
    nG.gain.exponentialRampToValueAtTime(0.001, now + dur);
    src.connect(bp);
    bp.connect(nG);
    nG.connect(out);
    src.start(now);
    src.stop(now + dur + 0.01);

    this.trackVoice(ctx, dur + 0.01, priority);
  }

  private synthMagicImpact(
    ctx: AudioContext,
    out: AudioNode,
    profile: CharacterAudioProfile,
    vol: number,
    detune: number,
    decayMul: number,
    priority: SoundPriority
  ) {
    const now = ctx.currentTime;
    const pitch = profile.pitchScale * detune;
    const dur = 0.28 * decayMul;

    const pulse = ctx.createOscillator();
    const pGain = ctx.createGain();
    pulse.type = 'triangle';
    pulse.frequency.setValueAtTime((profile.setId === 'inferno' ? 165 : 220) * pitch, now);
    pulse.frequency.exponentialRampToValueAtTime(52, now + dur * 0.85);
    pGain.gain.setValueAtTime(0.2 * vol, now);
    pGain.gain.exponentialRampToValueAtTime(0.001, now + dur * 0.85);
    pulse.connect(pGain);
    pGain.connect(out);
    pulse.start(now);
    pulse.stop(now + dur);

    const shimmer = ctx.createOscillator();
    const sGain = ctx.createGain();
    shimmer.type = 'sine';
    const topF =
      profile.setId === 'celestial'
        ? 1420
        : profile.setId === 'shadow'
        ? 780
        : 1120;
    shimmer.frequency.setValueAtTime(topF * pitch, now);
    shimmer.frequency.exponentialRampToValueAtTime(topF * 0.34 * pitch, now + dur);
    sGain.gain.setValueAtTime(0.11 * vol, now);
    sGain.gain.exponentialRampToValueAtTime(0.001, now + dur);
    shimmer.connect(sGain);
    sGain.connect(out);
    shimmer.start(now);
    shimmer.stop(now + dur + 0.01);

    this.trackVoice(ctx, dur + 0.01, priority);
  }

  private synthHorseMove(
    ctx: AudioContext,
    out: AudioNode,
    profile: CharacterAudioProfile,
    vol: number,
    detune: number,
    vIdx: number,
    priority: SoundPriority
  ) {
    const now = ctx.currentTime;
    const pitch = profile.pitchScale * detune;
    const offsets = [0, 0.085, 0.195];

    for (let i = 0; i < offsets.length; i++) {
      const t = now + offsets[i];
      const osc = ctx.createOscillator();
      const g = ctx.createGain();
      osc.type = 'triangle';
      const base = (i % 2 === 0 ? 158 : 132) * pitch;
      osc.frequency.setValueAtTime(base, t);
      osc.frequency.exponentialRampToValueAtTime(48, t + 0.065);
      g.gain.setValueAtTime(0.16 * vol, t);
      g.gain.exponentialRampToValueAtTime(0.001, t + 0.075);
      osc.connect(g);
      g.connect(out);
      osc.start(t);
      osc.stop(t + 0.08);
    }

    // Ground dirt hoof crunch on lead stride
    if (this.softImpactCache) {
      const hoof = ctx.createBufferSource();
      hoof.buffer = this.softImpactCache;
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.setValueAtTime(620 + vIdx * 90, now);
      const hGain = ctx.createGain();
      hGain.gain.setValueAtTime(0.12 * vol, now);
      hGain.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
      hoof.connect(lp);
      lp.connect(hGain);
      hGain.connect(out);
      hoof.start(now);
      hoof.stop(now + 0.1);
    }

    this.trackVoice(ctx, 0.28, priority);
  }

  private synthMovement(
    ctx: AudioContext,
    out: AudioNode,
    profile: CharacterAudioProfile,
    vol: number,
    detune: number,
    vIdx: number,
    priority: SoundPriority
  ) {
    const now = ctx.currentTime;
    const pitch = profile.pitchScale * detune;

    if (profile.movementTimbre === 'titanGear') {
      // Compact original pneumatic zip / taut steel line snap
      const src = ctx.createBufferSource();
      src.buffer = this.noiseCache[vIdx];
      const hp = ctx.createBiquadFilter();
      hp.type = 'bandpass';
      hp.Q.setValueAtTime(4.8, now);
      hp.frequency.setValueAtTime(1600 * pitch, now);
      hp.frequency.exponentialRampToValueAtTime(3100 * pitch, now + 0.11);
      const g = ctx.createGain();
      g.gain.setValueAtTime(0.12 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.12);
      src.connect(hp);
      hp.connect(g);
      g.connect(out);
      src.start(now);
      src.stop(now + 0.13);
      this.trackVoice(ctx, 0.13, priority);
      return;
    }

    if (profile.movementTimbre === 'heavyPlate') {
      const thump = ctx.createOscillator();
      const g = ctx.createGain();
      thump.type = 'triangle';
      thump.frequency.setValueAtTime(110 * pitch, now);
      thump.frequency.exponentialRampToValueAtTime(42, now + 0.12);
      g.gain.setValueAtTime(0.18 * vol, now);
      g.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
      thump.connect(g);
      g.connect(out);
      thump.start(now);
      thump.stop(now + 0.14);
      this.trackVoice(ctx, 0.14, priority);
      return;
    }

    // Light agile cloth/footstep movement
    const src = ctx.createBufferSource();
    src.buffer = this.noiseCache[vIdx];
    const lp = ctx.createBiquadFilter();
    lp.type = 'bandpass';
    lp.Q.setValueAtTime(1.4, now);
    lp.frequency.setValueAtTime(920 * pitch, now);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.09 * vol, now);
    g.gain.exponentialRampToValueAtTime(0.001, now + 0.09);
    src.connect(lp);
    lp.connect(g);
    g.connect(out);
    src.start(now);
    src.stop(now + 0.1);
    this.trackVoice(ctx, 0.1, priority);
  }

  private synthDefenderReaction(
    ctx: AudioContext,
    out: AudioNode,
    defProfile: CharacterAudioProfile,
    vol: number,
    detune: number,
    vIdx: number,
    priority: SoundPriority
  ) {
    const now = ctx.currentTime;
    const pitch = defProfile.pitchScale * detune;

    // Subtle armor/body impact thud as defeated piece collapses
    const thud = ctx.createOscillator();
    const tG = ctx.createGain();
    thud.type = 'triangle';
    thud.frequency.setValueAtTime(102 * pitch, now);
    thud.frequency.exponentialRampToValueAtTime(34, now + 0.22);
    tG.gain.setValueAtTime(0.24 * vol * defProfile.weight, now);
    tG.gain.exponentialRampToValueAtTime(0.001, now + 0.24);
    thud.connect(tG);
    tG.connect(out);
    thud.start(now);
    thud.stop(now + 0.25);

    if (defProfile.movementTimbre === 'heavyPlate') {
      const clatter = ctx.createOscillator();
      const cG = ctx.createGain();
      clatter.type = 'sine';
      clatter.frequency.setValueAtTime(420 * pitch, now + 0.02);
      clatter.frequency.exponentialRampToValueAtTime(210 * pitch, now + 0.18);
      cG.gain.setValueAtTime(0.08 * vol, now + 0.02);
      cG.gain.exponentialRampToValueAtTime(0.001, now + 0.19);
      clatter.connect(cG);
      cG.connect(out);
      clatter.start(now + 0.02);
      clatter.stop(now + 0.2);
    } else if (this.noiseCache[vIdx]) {
      const brush = ctx.createBufferSource();
      brush.buffer = this.noiseCache[vIdx];
      const lp = ctx.createBiquadFilter();
      lp.type = 'lowpass';
      lp.frequency.setValueAtTime(640, now);
      const bG = ctx.createGain();
      bG.gain.setValueAtTime(0.07 * vol, now);
      bG.gain.exponentialRampToValueAtTime(0.001, now + 0.15);
      brush.connect(lp);
      lp.connect(bG);
      bG.connect(out);
      brush.start(now);
      brush.stop(now + 0.16);
    }

    this.trackVoice(ctx, 0.25, priority);
  }

  public startMusic() {
    if (this.musicRunning || !this.enabled || !this.musicEnabled || document.hidden) return;
    const ctx = this.getContext();
    if (!ctx) return;

    this.musicRunning = true;
    const now = ctx.currentTime;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(0.04, now + 1.8);
    gain.connect(ctx.destination);
    this.musicGain = gain;

    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(250, now);
    filter.connect(gain);
    this.droneFilter = filter;

    const oscA = ctx.createOscillator();
    oscA.type = 'sine';
    oscA.frequency.setValueAtTime(73.42, now);
    oscA.connect(filter);
    oscA.start(now);
    this.droneOscA = oscA;

    const oscB = ctx.createOscillator();
    oscB.type = 'triangle';
    oscB.frequency.setValueAtTime(110.0, now);
    const fifthGain = ctx.createGain();
    fifthGain.gain.setValueAtTime(0.35, now);
    oscB.connect(fifthGain);
    fifthGain.connect(filter);
    oscB.start(now);
    this.droneOscB = oscB;

    this.musicTimerId = window.setInterval(() => {
      if (!this.musicRunning || !this.enabled || !this.musicEnabled || document.hidden) return;
      const c = this.ctx;
      const master = this.musicGain;
      if (!c || !master || c.state !== 'running') return;

      const t = c.currentTime;
      const freq = this.musicNotes[this.musicStep % this.musicNotes.length];
      this.musicStep++;

      const pluck = c.createOscillator();
      const pluckGain = c.createGain();
      const pluckFilter = c.createBiquadFilter();
      pluck.type = 'triangle';
      pluck.frequency.setValueAtTime(freq, t);

      pluckFilter.type = 'lowpass';
      pluckFilter.frequency.setValueAtTime(freq * 3.1, t);
      pluckFilter.frequency.exponentialRampToValueAtTime(freq * 1.1, t + 1.3);

      pluckGain.gain.setValueAtTime(0.0001, t);
      pluckGain.gain.linearRampToValueAtTime(0.26, t + 0.04);
      pluckGain.gain.exponentialRampToValueAtTime(0.0008, t + 1.45);

      pluck.connect(pluckFilter);
      pluckFilter.connect(pluckGain);
      pluckGain.connect(master);
      pluck.start(t);
      pluck.stop(t + 1.5);
    }, 1150);
  }

  public stopMusic() {
    this.musicRunning = false;
    if (this.musicTimerId) {
      window.clearInterval(this.musicTimerId);
      this.musicTimerId = 0;
    }
    const ctx = this.ctx;
    if (this.musicGain && ctx) {
      try {
        const now = ctx.currentTime;
        this.musicGain.gain.cancelScheduledValues(now);
        this.musicGain.gain.setValueAtTime(Math.max(0.0001, this.musicGain.gain.value), now);
        this.musicGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.2);
      } catch {
        // Ignore teardown edge cases
      }
    }
    const oscA = this.droneOscA;
    const oscB = this.droneOscB;
    this.droneOscA = null;
    this.droneOscB = null;
    this.droneFilter = null;
    this.musicGain = null;

    if (oscA || oscB) {
      window.setTimeout(() => {
        try {
          oscA?.stop();
          oscA?.disconnect();
        } catch {
          // ignore
        }
        try {
          oscB?.stop();
          oscB?.disconnect();
        } catch {
          // ignore
        }
      }, 220);
    }
  }

  public playButtonClick() {
    if (!this.canPlayWithPriority('ui:button', 65, 5)) return;
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(420, now);
    osc.frequency.exponentialRampToValueAtTime(240, now + 0.045);
    gain.gain.setValueAtTime(0.045, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.055);
    osc.connect(gain);
    gain.connect(this.getSfxOutput(ctx));
    osc.start(now);
    osc.stop(now + 0.06);
    this.trackVoice(ctx, 0.06, 5);
  }

  public playSelect() {
    if (!this.canPlayWithPriority('ui:select', 70, 5)) return;
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(540, now);
    osc.frequency.exponentialRampToValueAtTime(810, now + 0.075);
    gain.gain.setValueAtTime(0.06, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.1);
    osc.connect(gain);
    gain.connect(this.getSfxOutput(ctx));
    osc.start(now);
    osc.stop(now + 0.11);
    this.trackVoice(ctx, 0.11, 5);
  }

  /**
   * Non-capture chess piece movement matched to the active Kingdom & piece class.
   */
  public playPieceMove(characterSet: CharacterSetId, pieceType: PieceType) {
    const profile = getCharacterAudioProfile(characterSet, pieceType);
    if (profile.isMounted) {
      this.playCombatSound(characterSet, pieceType, 'horseMove');
      return;
    }
    if (!this.canPlayWithPriority('chess:move', 85, 4)) return;
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(175 * profile.pitchScale, now);
    osc.frequency.exponentialRampToValueAtTime(64, now + 0.11);
    gain.gain.setValueAtTime(0.14, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.13);
    osc.connect(gain);
    gain.connect(this.getSfxOutput(ctx));
    osc.start(now);
    osc.stop(now + 0.14);
    this.trackVoice(ctx, 0.14, 4);
  }

  public playMove() {
    this.playPieceMove('human', 'p');
  }

  public playHorseGallop() {
    this.playCombatSound('human', 'n', 'horseMove');
  }

  public playCheck() {
    if (!this.canPlayWithPriority('chess:check', 250, 2)) return;
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const out = this.getSfxOutput(ctx);
    for (let i = 0; i < CHECK_NOTES.length; i++) {
      const freq = CHECK_NOTES[i];
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.05);
      gain.gain.setValueAtTime(0.07, now + i * 0.05);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.05 + 0.32);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now + i * 0.05);
      osc.stop(now + i * 0.05 + 0.33);
    }
    this.trackVoice(ctx, 0.45, 2);
  }

  public playGameOver(victory: boolean) {
    if (!this.canPlayWithPriority('chess:gameover', 400, 1)) return;
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const out = this.getSfxOutput(ctx);
    const chord = victory ? VICTORY_CHORD : DEFEAT_CHORD;
    for (let i = 0; i < chord.length; i++) {
      const freq = chord[i];
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + i * 0.085);
      gain.gain.setValueAtTime(0.085, now + i * 0.085);
      gain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.085 + 0.7);
      osc.connect(gain);
      gain.connect(out);
      osc.start(now + i * 0.085);
      osc.stop(now + i * 0.085 + 0.72);
    }
    this.trackVoice(ctx, 1.0, 1);
  }

  public cleanup() {
    this.stopMusic();
    this.lastPlayed.clear();
    this.lastVariation.clear();
    this.activeVoices.length = 0;
    this.noiseCache.length = 0;
    this.softImpactCache = null;
    this.preloaded = false;
    if (this.ctx) {
      void this.ctx.close().catch(() => {});
      this.ctx = null;
    }
    this.sfxBus = null;
    this.limiter = null;
  }
}

export const audioManager = new AudioManager();
